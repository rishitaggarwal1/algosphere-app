// AlgoSphere v4.6.0. Copyright 2026 Rishit Aggarwal (https://github.com/rishitaggarwal1). Apache-2.0: see LICENSE and NOTICE.
(() => {
if (window.__lcHintLadderBridge) return;
window.__lcHintLadderBridge = true;
function readMonaco() {
const m = window.monaco;
if (!m || !m.editor) return null;
const editors = (m.editor.getEditors && m.editor.getEditors()) || [];
let editor = editors.find((e) => e.hasTextFocus && e.hasTextFocus());
if (!editor && editors.length) {
editor = editors
.map((e) => ({ e, len: (e.getModel && e.getModel() && e.getModel().getValueLength()) || 0 }))
.sort((a, b) => b.len - a.len)[0].e;
}
const model = (editor && editor.getModel && editor.getModel()) || (m.editor.getModels && m.editor.getModels()[0]);
if (!model) return null;
return { code: model.getValue(), lang: model.getLanguageId ? model.getLanguageId() : "" };
}
function readAce() {
if (!window.ace) return null;
const editors = [...document.querySelectorAll(".ace_editor")]
.map((el) => (el.env && el.env.editor) || (window.ace.edit ? window.ace.edit(el) : null))
.filter(Boolean)
.sort((a, b) => b.getValue().length - a.getValue().length);
const ed = editors[0];
if (!ed) return null;
const mode = (ed.session && ed.session.getMode && ed.session.getMode().$id) || "";
return { code: ed.getValue(), lang: mode.split("/").pop() };
}
window.addEventListener("message", (e) => {
if (e.source !== window || !e.data || e.data.type !== "LCHL_GET_CODE") return;
let result = null;
for (const read of [readMonaco, readAce]) {
try {
result = read();
} catch (_) {
result = null;
}
if (result && result.code) break;
}
window.postMessage(
{ type: "LCHL_CODE", id: e.data.id, code: result ? result.code : "", lang: result ? result.lang : "" },
window.location.origin
);
});
const SUBMIT_RE = /\/problems\/([^/]+)\/submit\/?(?:\?|$)/;
const CHECK_RE = /\/submissions\/detail\/(\d+)\/check\/?(?:\?|$)/;
const submissions = new Map();
const reported = new Set();
function onSubmitSent(url, body) {
const m = String(url).match(SUBMIT_RE);
if (!m) return null;
try {
const data = typeof body === "string" ? JSON.parse(body) : null;
if (data && typeof data.typed_code === "string") return { slug: m[1], lang: data.lang || "", code: data.typed_code };
} catch (_) {
}
return { slug: m[1], lang: "", code: "" };
}
function onResponse(url, data, pending) {
if (!data || typeof data !== "object") return;
if (pending && data.submission_id != null) {
submissions.set(String(data.submission_id), pending);
return;
}
const m = String(url).match(CHECK_RE);
if (!m || data.state !== "SUCCESS" || reported.has(m[1])) return;
reported.add(m[1]);
const sent = submissions.get(m[1]) || {};
let code = sent.code;
if (!code) {
try {
code = (readMonaco() || {}).code || "";
} catch (_) {
code = "";
}
}
window.postMessage(
{
type: "LCHL_SUBMISSION",
result: {
id: m[1],
slug: sent.slug || "",
lang: data.lang || sent.lang || "",
code,
statusMsg: data.status_msg || "",
accepted: data.status_msg === "Accepted" || data.status_code === 10,
runtime: data.status_runtime || "",
memory: data.status_memory || "",
runtimePercentile: data.runtime_percentile ?? null,
memoryPercentile: data.memory_percentile ?? null,
totalCorrect: data.total_correct ?? null,
totalTestcases: data.total_testcases ?? null,
},
},
window.location.origin
);
}
const GFG_NET_RE = /\/compile-sub-id\/|\/submission\/compile-run\/result\/|\/submission\/compile-output/;
let gfgListener = null;
let gfgSaved = null;
const pause = (ms) => new Promise((r) => setTimeout(r, ms));
const isShown = (el) => !!el && el.getClientRects().length > 0 && getComputedStyle(el).visibility !== "hidden";
const labelKey = (s) => String(s || "").replace(/=/g, "").replace(/\[\s*\]/g, "").replace(/\s+/g, "").toLowerCase();
async function waitFor(fn, ms) {
const end = Date.now() + ms;
let v = fn();
while (!v && Date.now() < end) {
await pause(100);
v = fn();
}
return v;
}
function gfgFields() {
return [...document.querySelectorAll('[class*="custom_separate_input_textarea"]')]
.filter((f) => !/readonly/.test(f.className) && isShown(f))
.map((f) => ({ label: (f.querySelector("label")?.textContent || "").replace(/=\s*$/, "").trim(), ta: f.querySelector("textarea") }))
.filter((f) => f.ta && !f.ta.readOnly && !f.ta.disabled);
}
function openCustomInput() {
const tab = [...document.querySelectorAll("a, strong, button")].find((el) => el.textContent.trim() === "Custom Input" && isShown(el));
if (tab) tab.click();
}
function setValue(ta, value) {
const setter = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set;
setter.call(ta, value);
ta.dispatchEvent(new Event("input", { bubbles: true }));
ta.dispatchEvent(new Event("change", { bubbles: true }));
}
function matchFields(fields, args) {
const out = new Map();
const left = [];
for (const a of args) {
const i = fields.findIndex((f, k) => !out.has(k) && labelKey(f.label) === labelKey(a.name));
if (i >= 0) out.set(i, a.value);
else left.push(a);
}
const free = fields.map((_, k) => k).filter((k) => !out.has(k));
if (left.length !== free.length) return null;
left.forEach((a, n) => out.set(free[n], a.value));
return out;
}
function gfgValue(value, sample) {
const v = String(value ?? "").trim();
const sampleQuoted = /^["']/.test(String(sample || "").trim());
return !sampleQuoted && /^"[^"]*"$|^'[^']*'$/.test(v) ? v.slice(1, -1) : v;
}
const loginShown = () => [...document.querySelectorAll('input[type="password"]')].some(isShown);
const compileButton = () =>
[...document.querySelectorAll("button")].find((b) => isShown(b) && (/compile_button/.test(b.className) || b.textContent.trim() === "Compile & Run"));
const buttonReady = (b) => b && !b.disabled && !/\b(disabled|loading)\b/.test(b.className);
function activeCaseIndex() {
const tabs = [...document.querySelectorAll('[class*="mtcPaneButton"]')].filter(isShown);
const i = tabs.findIndex((t) => /activeTab/.test(t.className));
return i > 0 ? i : 0;
}
function messageText(m) {
if (m == null) return "";
if (typeof m === "string") return m;
return String(m.error || m.message || JSON.stringify(m));
}
async function gfgRun(args) {
let fields = gfgFields();
if (!fields.length) {
openCustomInput();
fields = (await waitFor(() => (gfgFields().length ? gfgFields() : null), 4000)) || [];
}
if (!fields.length) return { ok: false, code: loginShown() ? "LOGIN" : "NO_FIELDS" };
if (!gfgSaved) gfgSaved = fields.map((f) => ({ label: f.label, value: f.ta.value }));
const map = matchFields(fields, args);
if (!map) return { ok: false, code: "FIELDS", fields: fields.map((f) => f.label), args: args.map((a) => a.name) };
fields.forEach((f, i) => setValue(f.ta, gfgValue(map.get(i), gfgSaved.find((s) => s.label === f.label)?.value)));
await pause(250);
const btn = await waitFor(() => (buttonReady(compileButton()) ? compileButton() : null), 15000);
if (!btn) return { ok: false, code: compileButton() ? "BUSY_BUTTON" : "NO_BUTTON" };
const caseIndex = activeCaseIndex();
return new Promise((resolve) => {
let ts = null;
let eo = null;
let started = false;
let settled = false;
let lateTimer = null;
const timers = [];
const finish = (r) => {
if (settled) return;
settled = true;
gfgListener = null;
timers.forEach(clearTimeout);
clearTimeout(lateTimer);
resolve({ caseIndex, ...r });
};
const ready = (x) => !!x && (x.status === "SUCCESS" || x.status === "calculated");
const busy = (x) => /temporarily busy/i.test(messageText(x && x.message));
gfgListener = (url, data) => {
if (!data || typeof data !== "object") return;
started = true;
if (/compile-sub-id/.test(url)) {
if (data.errorMessage) finish({ ok: false, code: "GFG_ERROR", error: String(data.errorMessage) });
return;
}
const r = data.results || data;
if (r.testSolution || r.expectedOutput) {
if (r.testSolution) ts = r.testSolution;
if (r.expectedOutput) eo = r.expectedOutput;
} else if (r.status) {
ts = r;
}
if (busy(ts) || busy(eo)) return finish({ ok: false, code: "BUSY" });
if (ts?.status === "FAILED" || eo?.status === "FAILED") {
return finish({ ok: false, code: "FAILED", error: messageText((ts?.status === "FAILED" ? ts : eo).message) });
}
if (ready(ts) && (ready(eo) || ts.view_mode === "compilation")) return finish({ ok: true, testSolution: ts, expectedOutput: eo });
if (ready(ts) && !lateTimer) lateTimer = setTimeout(() => finish({ ok: true, testSolution: ts, expectedOutput: eo }), 8000);
};
btn.click();
pause(1500).then(() => {
if (!started && loginShown()) finish({ ok: false, code: "LOGIN" });
});
timers.push(setTimeout(() => !started && finish({ ok: false, code: loginShown() ? "LOGIN" : "NO_START" }), 12000));
timers.push(setTimeout(() => finish({ ok: false, code: "TIMEOUT" }), 60000));
});
}
function gfgRestore() {
const saved = gfgSaved;
gfgSaved = null;
if (!saved) return;
for (const f of gfgFields()) {
const s = saved.find((x) => x.label === f.label);
if (s && f.ta.value !== s.value) setValue(f.ta, s.value);
}
}
window.addEventListener("message", (e) => {
if (e.source !== window || !e.data) return;
if (e.data.type === "LCHL_GFG_RUN") {
const id = e.data.id;
gfgRun(Array.isArray(e.data.args) ? e.data.args : [])
.catch((err) => ({ ok: false, code: "BRIDGE", error: String((err && err.message) || err) }))
.then((r) => window.postMessage({ type: "LCHL_GFG_RUN_DONE", id, ...r }, window.location.origin));
} else if (e.data.type === "LCHL_GFG_RESTORE") {
gfgRestore();
}
});
function readJson(text) {
try {
return JSON.parse(text);
} catch (_) {
return null;
}
}
const watchLeetcode = (url) => SUBMIT_RE.test(String(url)) || CHECK_RE.test(String(url));
const watchGfg = (url) => GFG_NET_RE.test(String(url));
function onGfgResponse(url, data) {
try {
if (gfgListener) gfgListener(String(url), data);
} catch (_) {
}
}
const origFetch = window.fetch;
if (typeof origFetch === "function") {
window.fetch = function (input, init) {
const url = typeof input === "string" ? input : (input && input.url) || "";
const lc = watchLeetcode(url);
const gfg = watchGfg(url);
const pending = lc ? onSubmitSent(url, init && init.body) : null;
const p = origFetch.apply(this, arguments);
if (lc || gfg) {
p.then((res) =>
res
.clone()
.text()
.then((t) => (lc ? onResponse(url, readJson(t), pending) : onGfgResponse(url, readJson(t))))
).catch(() => {});
}
return p;
};
}
const XHR = window.XMLHttpRequest && window.XMLHttpRequest.prototype;
if (XHR) {
const open = XHR.open;
const send = XHR.send;
XHR.open = function (method, url) {
this.__lchlUrl = url;
return open.apply(this, arguments);
};
XHR.send = function (body) {
const url = String(this.__lchlUrl || "");
if (watchLeetcode(url)) {
const pending = onSubmitSent(url, body);
this.addEventListener("load", () => {
try {
onResponse(url, readJson(this.responseText), pending);
} catch (_) {
}
});
} else if (watchGfg(url)) {
this.addEventListener("load", () => {
let data = null;
try {
data = typeof this.response === "object" && this.response ? this.response : readJson(this.responseText);
} catch (_) {
data = null;
}
onGfgResponse(url, data);
});
}
return send.apply(this, arguments);
};
}
})();
