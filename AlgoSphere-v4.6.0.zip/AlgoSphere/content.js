// AlgoSphere v4.6.0. Copyright 2026 Rishit Aggarwal (https://github.com/rishitaggarwal1). Apache-2.0: see LICENSE and NOTICE.
(() => {
if (window.__lcHintLadder) return;
window.__lcHintLadder = true;
const EMBED = window.__LCHL_EMBED || null;
const TOTAL = 8;
const LABELS = [
"Restate",
"Observation",
"Constraints",
"Pattern",
"Key insight",
"What to track",
"Approach",
"Edge cases & complexity",
];
const TABS = [
{ id: "hints", label: "Hints" },
{ id: "tests", label: "Tests" },
{ id: "approach", label: "Intuition" },
{ id: "review", label: "Review" },
];
const KINDS = TABS.map((t) => t.id);
const LANG_NAMES = {
cpp: "C++", c_cpp: "C++", "c++": "C++", c: "C", java: "Java", python: "Python3", python3: "Python3", javascript: "JavaScript",
typescript: "TypeScript", csharp: "C#", go: "Go", golang: "Go", rust: "Rust", kotlin: "Kotlin",
swift: "Swift", ruby: "Ruby", scala: "Scala", php: "PHP", dart: "Dart", elixir: "Elixir",
erlang: "Erlang", racket: "Racket", sql: "MySQL", mysql: "MySQL", pythondata: "Pandas",
};
const VERDICT_INFO = {
correct: { label: "Looks correct", tone: "good" },
wrong_answer: { label: "Wrong answer", tone: "bad" },
too_slow: { label: "Too slow", tone: "warn" },
partially_correct: { label: "Partly right", tone: "warn" },
incomplete: { label: "Incomplete", tone: "muted" },
wont_compile: { label: "Won't compile", tone: "bad" },
};
const PLAN_VERDICTS = {
will_work: { label: "Will work", tone: "good" },
too_slow: { label: "Too slow", tone: "warn" },
wont_work: { label: "Won't work", tone: "bad" },
incomplete: { label: "Needs more detail", tone: "muted" },
};
const LC_LANG_SLUGS = {
"C++": "cpp", Java: "java", Python: "python", Python3: "python3", C: "c", "C#": "csharp",
JavaScript: "javascript", TypeScript: "typescript", PHP: "php", Swift: "swift", Kotlin: "kotlin",
Dart: "dart", Go: "golang", Ruby: "ruby", Scala: "scala", Rust: "rust", Racket: "racket",
Erlang: "erlang", Elixir: "elixir",
};
const LC_LANG_NAMES = Object.fromEntries(Object.entries(LC_LANG_SLUGS).map(([name, slug]) => [slug, name]));
const THEME_LABELS = { auto: "Auto (match the site)", light: "Light", dark: "Dark" };
const THEME_ICONS = { auto: "◐", light: "☀", dark: "☾" };
const blank = () => ({ hints: false, tests: false, approach: false, review: false });
const state = {
slug: null,
open: !!EMBED,
wide: false,
themePref: "auto",
syncEnabled: false,
sync: { status: "", detail: "" },
syncedSections: {},
inflightSections: {},
pull: null,
pullDone: true,
pullFailed: false,
syncRetry: { attempt: 0, timer: null, at: 0, run: null, permanent: false },
localUpdatedAt: 0,
contentAt: 0,
baseline: {},
includeSolutions: true,
jobs: {},
progress: {},
cancelers: {},
prefetchHints: true,
prefetchTests: true,
full: !!EMBED?.full,
playerFull: -1,
revealPending: false,
tab: "hints",
hints: null,
revealed: 0,
tests: null,
customTests: null,
customForm: null,
approach: null,
review: null,
reviewFor: null,
code: "",
codeLang: "",
codeSource: "",
codeFetching: false,
note: "",
expanded: new Set(),
view: {},
step: {},
codeMode: {},
speed: 1,
thinkOpen: new Set(),
showCorrect: false,
reviewMode: "plan",
planText: "",
planCheck: null,
planCheckFor: null,
runResults: null,
runState: { running: false, message: "", error: null },
mySolutions: null,
attempts: 0,
usageToday: null,
usageSettings: {},
shortcutsOn: true,
showKeys: false,
showAbout: false,
loading: blank(),
error: {},
fresh: -1,
};
const SITES = {
leetcode: {
id: "leetcode",
name: "LeetCode",
slugRe: /^\/problems\/([^/]+)/,
keyPrefix: "hints:",
title: () => {
const t = document.title.replace(/\s*[-|]\s*LeetCode.*$/i, "").trim();
return t && !/^leetcode$/i.test(t) ? t : "";
},
descriptionEls: () => [...document.querySelectorAll('[data-track-load="description_content"]')].slice(0, 1),
difficulty: () => document.querySelector('[class*="text-difficulty-"]')?.textContent.trim() || "",
dark: () => document.documentElement.classList.contains("dark"),
themeWatch: () => [document.documentElement, ["class"]],
languageLabel: () => {
const names = new Set(Object.values(LANG_NAMES).concat(["Python", "C#"]));
const btn = [...document.querySelectorAll("button")].find((b) => names.has(b.textContent.trim()));
return btn ? btn.textContent.trim() : "";
},
visibleLines: () =>
[...document.querySelectorAll(".monaco-editor .view-lines .view-line")].map((l) => ({
top: parseFloat(l.style.top) || 0,
text: l.textContent || "",
})),
testcaseHint: "Paste an input into LeetCode's <strong>Testcase</strong> tab (one value per line).",
editorName: "LeetCode's editor",
runHint: "Running tests works on leetcode.com.",
},
gfg: {
id: "gfg",
name: "GeeksforGeeks",
slugRe: /\/problems\/([^/]+)/,
keyPrefix: "hints:gfg:",
title: () =>
document.querySelector('[class*="problems_header_content"] h3, h3.g-m-0')?.innerText.trim() ||
document.title.replace(/\s*\|.*$/, "").trim(),
descriptionEls: () => [...document.querySelectorAll('[class*="problems_problem_content"]')],
difficulty: () =>
(document.querySelector('[class*="problems_header_description"]')?.innerText.match(/Difficulty:\s*(School|Basic|Easy|Medium|Hard)/i) || [])[1] || "",
dark: () => document.body?.getAttribute("data-theme") === "dark",
themeWatch: () => [document.body, ["data-theme"]],
languageLabel: () =>
(document.querySelector('[class*="problems_language_dropdown"]')?.innerText || "").replace(/\s*\(.*\)\s*$/, "").trim(),
visibleLines: () =>
[...document.querySelectorAll(".ace_editor .ace_text-layer .ace_line")].map((l) => ({
top: parseFloat(l.style.top) || l.offsetTop || 0,
text: l.textContent || "",
})),
testcaseHint: "To try a case by hand, copy its values into GeeksforGeeks' <strong>Custom Input</strong> boxes (one per parameter).",
editorName: "the GeeksforGeeks editor",
runHint: "Sign in to GeeksforGeeks to run the cases with Compile & Run.",
},
};
const SITE =
SITES[window.__LCHL_SITE] ||
(/(^|\.)geeksforgeeks\.org$/.test(location.hostname) ? SITES.gfg : SITES.leetcode);
function currentSlug() {
const m = location.pathname.match(SITE.slugRe);
return m ? m[1] : null;
}
function slugToTitle(slug) {
return (slug || "")
.replace(/\d+$/, "")
.split("-")
.filter(Boolean)
.map((w) => w.charAt(0).toUpperCase() + w.slice(1))
.join(" ");
}
function pageTitle() {
return SITE.title() || slugToTitle(state.slug);
}
function sleep(ms) {
return new Promise((r) => setTimeout(r, ms));
}
const BLOCK_TAGS = new Set(["P", "DIV", "PRE", "LI", "UL", "OL", "H1", "H2", "H3", "H4", "H5", "H6", "TABLE", "TR", "BLOCKQUOTE", "SECTION"]);
function statementText(root) {
let out = "";
const walk = (node) => {
if (node.nodeType === Node.TEXT_NODE) {
out += node.nodeValue;
return;
}
if (node.nodeType !== Node.ELEMENT_NODE) return;
const tag = node.tagName;
if (tag === "SCRIPT" || tag === "STYLE" || tag === "BUTTON") return;
if (tag === "BR") {
out += "\n";
return;
}
if (tag === "SUP") out += "^";
if (tag === "SUB") out += "_";
if (tag === "LI") out += "\n- ";
else if (BLOCK_TAGS.has(tag)) out += "\n";
if (tag === "IMG" && node.alt) out += `[image: ${node.alt}]`;
node.childNodes.forEach(walk);
if (BLOCK_TAGS.has(tag)) out += "\n";
if (tag === "TD" || tag === "TH") out += "\t";
};
walk(root);
return out
.replace(/ /g, " ")
.replace(/[ \t]+\n/g, "\n")
.replace(/\n{3,}/g, "\n\n")
.trim();
}
async function extractProblem() {
const fromPage = () => SITE.descriptionEls().map(statementText).filter(Boolean).join("\n\n");
let description = "";
for (let i = 0; i < 8 && !description; i++) {
description = fromPage();
if (!description) await sleep(250);
}
let difficulty = SITE.difficulty();
let source = description ? "page" : "";
if (!description && SITE.id === "leetcode") {
const q = await leetcodeQuestion(state.slug).catch(() => null);
if (q?.content) {
description = statementText(new DOMParser().parseFromString(q.content, "text/html").body);
difficulty = difficulty || q.difficulty || "";
source = "api";
}
}
for (let i = 0; i < 12 && !description; i++) {
await sleep(400);
description = fromPage();
if (description) source = "page";
}
if (!description) {
description = document.querySelector('meta[name="description"]')?.content?.trim() || "";
source = description ? "meta" : "";
}
return {
slug: state.slug,
platform: SITE.name,
title: pageTitle(),
difficulty,
description: description.slice(0, 10000),
source,
};
}
function askBridge() {
return new Promise((resolve) => {
const id = Math.random().toString(36).slice(2);
const onMsg = (e) => {
if (e.source !== window || !e.data || e.data.type !== "LCHL_CODE" || e.data.id !== id) return;
window.removeEventListener("message", onMsg);
clearTimeout(timer);
resolve({ code: e.data.code || "", lang: e.data.lang || "" });
};
const timer = setTimeout(() => {
window.removeEventListener("message", onMsg);
resolve(null);
}, 1200);
window.addEventListener("message", onMsg);
window.postMessage({ type: "LCHL_GET_CODE", id }, location.origin);
});
}
function toolbarLanguage() {
const label = SITE.languageLabel();
return LANG_NAMES[label.toLowerCase()] || label;
}
async function readEditorCode() {
const res = await askBridge();
if (res && res.code.trim()) {
return { code: res.code, lang: LANG_NAMES[res.lang] || toolbarLanguage() || res.lang, source: "editor" };
}
const lines = SITE.visibleLines();
if (lines.length) {
const text = lines
.sort((a, b) => a.top - b.top)
.map((l) => l.text.replace(/ /g, " "))
.join("\n");
return { code: text, lang: toolbarLanguage(), source: "page" };
}
return null;
}
const storageKey = (slug) => `${SITE.keyPrefix}${slug}`;
async function loadFor(slug) {
clearTimeout(state.syncRetry.timer);
Object.assign(state, {
slug,
hints: null,
revealed: 0,
tests: null,
customTests: null,
customForm: null,
approach: null,
review: null,
reviewFor: null,
code: "",
codeLang: "",
codeSource: "",
note: "",
expanded: new Set(),
view: {},
step: {},
codeMode: {},
thinkOpen: new Set(),
showCorrect: false,
error: {},
loading: blank(),
fresh: -1,
sync: { status: "", detail: "" },
syncedSections: {},
inflightSections: {},
pull: null,
pullDone: false,
pullFailed: false,
syncRetry: { attempt: 0, timer: null, at: 0, run: null, permanent: false },
localUpdatedAt: 0,
contentAt: 0,
baseline: {},
reviewMode: "plan",
planText: "",
planCheck: null,
planCheckFor: null,
runResults: null,
runState: { running: false, message: "", error: null },
mySolutions: null,
attempts: 0,
showKeys: false,
jobs: {},
progress: {},
cancelers: {},
revealPending: false,
});
stopPlayer();
if (!slug) return;
try {
const data = await chrome.storage.local.get([storageKey(slug), "ui"]);
state.wide = EMBED ? true : !!data.ui?.wide;
const saved = data[storageKey(slug)];
if (state.slug !== slug) return;
if (saved) {
applySaved(saved, { preferIncoming: true });
state.revealed = state.hints ? Math.min(saved.revealed || 0, TOTAL) : 0;
state.localUpdatedAt = Number(saved.updatedAt) || 0;
state.contentAt = Number(saved.contentAt) || state.localUpdatedAt;
state.attempts = Number(saved.attempts) || 0;
state.planText = saved.planText || "";
state.planCheck = saved.planCheck || null;
state.planCheckFor = saved.planCheckFor || null;
if (saved.runResults) {
const same = (k) => JSON.stringify(saved[k] ?? null) === JSON.stringify(state[k] ?? null);
const kept = Object.entries(saved.runResults).filter(([key]) => (key.startsWith("custom:") ? same("customTests") : same("tests")));
state.runResults = kept.length ? Object.fromEntries(kept) : null;
}
}
state.baseline = snapshot();
} catch (_) {
}
state.pull = pullFromGithub(slug);
}
function applySaved(saved, { preferIncoming }) {
const taken = [];
const take = (section, valid, apply) => {
if (valid && (preferIncoming || state[section] == null)) {
apply();
taken.push(section);
}
};
take("hints", Array.isArray(saved.hints) && saved.hints.length === TOTAL, () => (state.hints = saved.hints));
take("tests", !!(saved.tests && Array.isArray(saved.tests.normal)), () => {
if (JSON.stringify(state.tests) !== JSON.stringify(saved.tests)) dropResults("generated");
state.tests = saved.tests;
});
take("customTests", Array.isArray(saved.customTests), () => {
if (JSON.stringify(state.customTests) !== JSON.stringify(saved.customTests)) dropResults("custom");
state.customTests = saved.customTests;
});
take("approach", !!(saved.approach && saved.approach.version === 3), () => (state.approach = saved.approach));
take("review", !!(saved.review && saved.review.summary), () => {
state.review = saved.review;
state.reviewFor = saved.reviewFor || null;
});
take("mySolutions", Array.isArray(saved.mySolutions) && saved.mySolutions.length > 0, () => (state.mySolutions = saved.mySolutions));
return taken;
}
function localRecord(updatedAt) {
return {
title: pageTitle(),
hints: state.hints,
revealed: state.revealed,
tests: state.tests,
customTests: state.customTests,
approach: state.approach,
review: state.review,
reviewFor: state.reviewFor,
mySolutions: state.mySolutions,
attempts: state.attempts,
planText: state.planText,
planCheck: state.planCheck,
planCheckFor: state.planCheckFor,
runResults: state.runResults,
updatedAt,
};
}
const FIELDS = ["hints", "revealed", "tests", "customTests", "approach", "review", "reviewFor", "mySolutions", "attempts", "planText", "planCheck", "planCheckFor", "runResults"];
const EMPTY = { revealed: 0, attempts: 0, planText: "" };
const fieldJson = (f) => JSON.stringify(state[f] ?? null);
const snapshot = () => Object.fromEntries(FIELDS.map((f) => [f, fieldJson(f)]));
const changedFields = () => FIELDS.filter((f) => fieldJson(f) !== state.baseline[f]);
function mergeApproach(mine, theirs) {
const shape = (a) => JSON.stringify((a?.approaches || []).map((x) => [x.level, x.name, x.idea, x.time, x.space]));
if (!mine || !theirs || shape(mine) !== shape(theirs)) return mine;
return { ...mine, approaches: mine.approaches.map((x, i) => (x.deep || !theirs.approaches[i]?.deep ? x : { ...x, deep: theirs.approaches[i].deep })) };
}
function adoptOtherTab(stored, mine) {
const adopted = [];
for (const f of FIELDS) {
if (mine.includes(f)) continue;
if (JSON.stringify(stored[f] ?? null) !== state.baseline[f]) {
state[f] = stored[f] ?? EMPTY[f] ?? null;
adopted.push(f);
}
}
if (mine.includes("approach") && stored.approach) state.approach = mergeApproach(state.approach, stored.approach);
if (!state.hints) state.revealed = 0;
if (adopted.includes("approach")) state.expanded = new Set(state.expanded.size ? state.expanded : [0]);
return adopted;
}
async function save({ fromRemote = false } = {}) {
const slug = state.slug;
if (!slug) return;
const key = storageKey(slug);
let stored = null;
try {
stored = (await chrome.storage.local.get(key))[key] || null;
} catch (_) {
return;
}
if (state.slug !== slug) return;
const mine = changedFields();
const adopted = stored ? adoptOtherTab(stored, mine) : [];
if (!fromRemote && mine.some((f) => SYNCED.includes(f) || f === "reviewFor")) state.contentAt = Date.now();
state.contentAt = Math.max(state.contentAt, Number(stored?.contentAt) || 0);
const record = { ...(stored || {}), ...localRecord(Date.now()), contentAt: state.contentAt };
const meaningful = FIELDS.some((f) => record[f] && !(Array.isArray(record[f]) && !record[f].length));
if (meaningful || stored) {
try {
await chrome.storage.local.set({ [key]: record });
state.localUpdatedAt = record.updatedAt;
} catch (err) {
toast(`Couldn't save on this computer: ${err?.message || err}`, "warn", 9000);
}
}
state.baseline = snapshot();
if (adopted.length && state.open) render();
scheduleSync();
}
const SYNCED = ["hints", "tests", "customTests", "approach", "review", "mySolutions"];
const sectionJson = (k) => JSON.stringify(k === "review" ? [state.review, state.reviewFor] : state[k] ?? null);
function setSync(status, detail = "", url = "") {
state.sync = { status, detail, url };
if (state.open) renderFooter();
}
function githubUrl(r, kind, path) {
if (!r?.repo || !r.branch || !path) return "";
const enc = (p) => String(p).split("/").map(encodeURIComponent).join("/");
return `https://github.com/${enc(r.repo)}/${kind}/${enc(r.branch)}/${enc(path)}`;
}
const SYNC_PERMANENT = new Set(["BAD_TOKEN", "NO_ACCESS", "NO_REPO", "NO_BRANCH", "NOT_SET_UP", "RELOAD"]);
const SYNC_RETRY_MS = [5000, 20000, 60000, 180000];
async function syncMessage(msg) {
try {
return await chrome.runtime.sendMessage(msg);
} catch (_) {
if (!chrome.runtime?.id) return { ok: false, error: RELOAD_MSG, code: "RELOAD" };
return { ok: false, error: "Lost contact with the extension's background worker for a moment.", code: "CHANNEL" };
}
}
function clearSyncRetry() {
clearTimeout(state.syncRetry.timer);
state.syncRetry = { attempt: 0, timer: null, at: 0, run: null, permanent: false };
}
function syncFailed(slug, res, run) {
if (state.slug !== slug) return;
const permanent = SYNC_PERMANENT.has(res?.code);
const delays = window.__LCHL_SYNC_RETRY_MS || SYNC_RETRY_MS;
const n = state.syncRetry.attempt;
clearTimeout(state.syncRetry.timer);
const wait = permanent || n >= delays.length ? null : Math.max(delays[n], Math.min(Number(res?.retryAfter) || 0, 30 * 60000));
state.syncRetry = { attempt: n + 1, timer: null, at: wait == null ? 0 : Date.now() + wait, run, permanent };
if (wait != null) {
state.syncRetry.timer = setTimeout(() => {
if (state.slug === slug) run();
}, wait);
}
const message = res?.error || "Couldn't reach GitHub.";
setSync("error", message);
if (permanent || wait == null) toast(`GitHub sync: ${message}`, "warn", 10000);
}
function retrySyncNow() {
const run = state.syncRetry.run;
if (!run) return openSettings();
clearTimeout(state.syncRetry.timer);
state.syncRetry.timer = null;
state.syncRetry.at = 0;
run();
}
const retryPull = (slug) => () => {
setSync("checking");
state.pull = pullFromGithub(slug);
};
async function warnTokenExpiry(expires) {
const at = Date.parse(String(expires || "").replace(" UTC", "Z").replace(" ", "T"));
const days = (at - Date.now()) / 86400000;
if (!(days <= 5)) return;
const today = new Date().toLocaleDateString("en-CA");
try {
const { ghExpiryWarned } = await chrome.storage.local.get("ghExpiryWarned");
if (ghExpiryWarned === today) return;
await chrome.storage.local.set({ ghExpiryWarned: today });
} catch (_) {
return;
}
toast(
days <= 0
? "Your GitHub token has expired. Create a new one and paste it in Settings so saving works again."
: `Your GitHub token expires in ${Math.ceil(days)} day${Math.ceil(days) === 1 ? "" : "s"}. Create a new one in Settings so saving keeps working.`,
"warn",
10000
);
}
async function pullFromGithub(slug) {
try {
await readGithub(slug);
} finally {
if (state.slug === slug) state.pullDone = true;
}
}
async function readGithub(slug) {
const res = await syncMessage({ type: "SYNC_LOAD", site: SITE.id, slug });
if (state.slug !== slug) return;
if (res?.ok && res.result?.disabled) {
state.syncEnabled = false;
clearSyncRetry();
return;
}
if (res?.code === "CHANNEL" || res?.code === "RELOAD") {
const on = await chrome.storage.local.get("settings").then((d) => !!d.settings?.github?.enabled, () => false);
if (!on || state.slug !== slug) return;
}
state.syncEnabled = true;
if (!res?.ok) {
state.pullFailed = true;
return syncFailed(slug, { ...res, error: res?.error || "Couldn't read from GitHub." }, retryPull(slug));
}
state.pullFailed = false;
clearSyncRetry();
warnTokenExpiry(res.result.tokenExpires);
if (!res.result.found) {
setSync("missing");
scheduleSync();
return;
}
const remote = res.result.data || {};
const remoteTime = Date.parse(remote.updatedAt) || 0;
const remoteNewer = remoteTime > state.contentAt;
const taken = applySaved(remote, { preferIncoming: remoteNewer });
for (const k of SYNCED) {
state.syncedSections[k] = JSON.stringify(k === "review" ? [remote.review ?? null, remote.reviewFor ?? null] : remote[k] ?? null);
}
if (taken.length) {
if (taken.includes("approach")) {
state.expanded = new Set([0]);
state.view = {};
state.step = {};
}
if (remoteNewer) state.contentAt = remoteTime;
await save({ fromRemote: true });
}
setSync("loaded", remote.updatedAt ? `Saved on GitHub ${new Date(remote.updatedAt).toLocaleString()}` : "", githubUrl(res.result, "tree", res.result.dir));
if (state.open) render();
scheduleSync();
}
const pendingSync = new Map();
function scheduleSync() {
if (!state.syncEnabled || !state.slug || state.pullFailed) return;
const known = { ...state.syncedSections, ...state.inflightSections };
const changed = SYNCED.filter((k) => state[k] != null && sectionJson(k) !== known[k]);
if (!changed.length) return;
const slug = state.slug;
const record = { title: pageTitle(), url: location.origin + location.pathname };
for (const k of changed) {
record[k] = state[k];
if (k === "review") record.reviewFor = state.reviewFor;
}
const sent = Object.fromEntries(changed.map((k) => [k, sectionJson(k)]));
clearTimeout(pendingSync.get(slug));
pendingSync.set(
slug,
setTimeout(() => {
pendingSync.delete(slug);
pushToGithub(slug, record, changed, sent);
}, 1500)
);
}
async function pushToGithub(slug, record, changed, sent) {
if (state.slug === slug) {
setSync("saving");
Object.assign(state.inflightSections, sent);
}
if (state.slug === slug) {
try {
const p = await extractProblem();
if (p.description && p.source !== "meta") record.problem = { difficulty: p.difficulty, description: p.description };
} catch (_) {
}
}
const names = { mySolutions: "my solution", customTests: "my test cases" };
const label = changed.map((k) => names[k] || k).join(", ");
const res = await syncMessage({ type: "SYNC_SAVE", site: SITE.id, slug, record, label });
if (state.slug !== slug) return;
for (const k of Object.keys(sent)) if (state.inflightSections[k] === sent[k]) delete state.inflightSections[k];
if (!res?.ok) return syncFailed(slug, { ...res, error: res?.error || "Couldn't save to GitHub." }, () => scheduleSync());
if (res.result?.disabled) return;
clearSyncRetry();
Object.assign(state.syncedSections, sent);
setSync("saved", res.result?.path ? `Saved to ${res.result.path}` : "", githubUrl(res.result, "tree", res.result?.path));
if (sent.mySolutions && res.result?.mine) {
const file = `${res.result.path}/${res.result.mine}`;
toast(`Your solution is on GitHub: ${file}`, "good", 10000, { href: githubUrl(res.result, "blob", file), label: "Open ↗" });
}
}
function syncStatusHtml() {
if (!state.syncEnabled || !state.sync.status) return "";
const { status, detail } = state.sync;
const label = {
checking: "Checking GitHub…",
loaded: "Loaded from GitHub",
missing: "Not on GitHub yet",
saving: "Saving to GitHub…",
saved: "Saved to GitHub",
error: "GitHub sync failed",
}[status];
if (!label) return "";
const icon = { loaded: "✓", saved: "✓", missing: "○", saving: "⟳", checking: "⟳", error: "⚠" }[status];
const title = escapeHtml(detail || label);
const r = state.syncRetry;
if (status === "error" && r.run && !r.permanent) {
const when = r.at ? ` Trying again by itself at ${new Date(r.at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit", second: "2-digit" })}.` : "";
return `<button class="sync-status error" data-action="sync-retry" title="${escapeHtml(`${detail}${when} Click to try now.`)}">⚠ GitHub sync failed · Retry</button>`;
}
if (status === "error") return `<button class="sync-status error" data-action="settings" title="${title}">${icon} ${label}</button>`;
if (state.sync.url && (status === "saved" || status === "loaded")) {
return `<a class="sync-status ${status}" href="${escapeHtml(state.sync.url)}" target="_blank" rel="noopener noreferrer" title="${title}. Open on GitHub.">${icon} ${label} ↗</a>`;
}
return `<span class="sync-status ${status}" title="${title}" role="status">${icon} ${label}</span>`;
}
function renderFooter() {
const footer = root.querySelector(".panel footer");
if (footer) footer.innerHTML = footerHtml();
}
const RELOAD_MSG = "The extension was updated. Refresh this page to keep using it.";
function runGeneration(key, kind, problem, extra) {
return new Promise((resolve) => {
let port;
let settled = false;
const finish = (res) => {
if (settled) return;
settled = true;
delete state.cancelers[key];
resolve(res);
};
try {
port = chrome.runtime.connect({ name: "generate" });
} catch (err) {
return finish({ ok: false, error: RELOAD_MSG, code: "RELOAD" });
}
state.cancelers[key] = () => {
try {
port.disconnect();
} catch (_) {
}
finish({ ok: false, code: "CANCELLED" });
};
if (state.open) render();
port.onMessage.addListener((m) => {
if (m?.type === "progress" && m.event) onProgress(key, m.event);
else if (m?.type === "done") {
finish(m);
try {
port.disconnect();
} catch (_) {
}
}
});
port.onDisconnect.addListener(() => finish({ ok: false, error: RELOAD_MSG, code: "RELOAD" }));
port.postMessage({ type: "GENERATE", kind, problem, extra });
});
}
async function request(kind, key, extra) {
state.loading[key] = true;
state.error[key] = null;
state.progress[key] = { started: Date.now(), note: "" };
render(kind === "hints" ? "reveal" : null);
const slugAtStart = state.slug;
try {
const problem = await extractProblem();
if (!problem.description) {
throw Object.assign(new Error("Couldn't read the problem. Open the Description tab and try again."), {
code: "NO_PROBLEM",
});
}
if (problem.source === "meta" && !request.warned?.has(state.slug)) {
(request.warned ||= new Set()).add(state.slug);
toast("Only the page's short summary of this problem could be read. Open the Description tab for better results.", "warn", 9000);
}
if (kind === "tests" && SITE.id === "gfg") extra = { ...(extra || {}), inputFields: gfgInputFields() };
const res = await runGeneration(key, kind, problem, extra);
if (state.slug !== slugAtStart) return null;
if (res?.code === "CANCELLED") return null;
if (!res || !res.ok) {
state.error[key] = { message: res?.error || "No response from the extension.", code: res?.code };
return null;
}
return res.result;
} catch (err) {
if (state.slug !== slugAtStart) return null;
const invalidated = /context invalidated|Receiving end does not exist/i.test(String(err?.message));
state.error[key] = invalidated
? { message: RELOAD_MSG, code: "RELOAD" }
: { message: err?.message || String(err), code: err?.code };
return null;
} finally {
if (state.slug === slugAtStart) {
state.loading[key] = false;
delete state.progress[key];
}
}
}
const RETRY_WHY = { 503: "is overloaded", 502: "had a server error", 500: "had a server error", 504: "timed out", 529: "is overloaded", 429: "is rate-limiting requests", 408: "timed out", NETWORK: "can't be reached", OVERLOADED: "is overloaded" };
function onProgress(key, m) {
if (!state.progress[key]) return;
let note = "";
if (m.type === "retry") {
note = `${m.provider} ${RETRY_WHY[m.status] || "had a problem"}${typeof m.status === "number" ? ` (${m.status})` : ""}. Retrying in ${Math.max(1, Math.round(m.waitMs / 1000))}s (attempt ${m.attempt} of ${m.max})…`;
} else if (m.type === "fallback") {
note = `${m.from} ${m.reason}. Trying ${m.to}…`;
} else if (m.type === "skip") {
note = `${m.from} has been failing, so using ${m.to} for now.`;
}
state.progress[key].note = note;
if (state.open) render();
}
function regeneratingHtml() {
const t = state.tab;
if (!["tests", "approach"].includes(t) || !state.loading[t] || !state[t]) return "";
return `<div class="regen-note"><span class="spinner" aria-hidden="true"></span><span>Regenerating…</span></div>${progressHtml(t)}`;
}
function progressHtml(key) {
const p = state.progress[key];
if (!state.loading[key] || !p) return "";
const secs = Math.floor((Date.now() - p.started) / 1000);
return `<div class="gen-progress" role="status">
      <span class="gen-elapsed"><span data-elapsed="${key}">${secs}</span>s</span>
      ${p.note ? `<span class="gen-note">${escapeHtml(p.note)}</span>` : ""}
      ${state.cancelers[key] ? `<button class="link gen-cancel" data-action="cancel-gen" data-key="${key}">Cancel</button>` : ""}
    </div>`;
}
setInterval(() => {
if (!state.open) return;
for (const el of root.querySelectorAll("[data-elapsed]")) {
const p = state.progress[el.dataset.elapsed];
if (p) el.textContent = Math.floor((Date.now() - p.started) / 1000);
}
}, 1000);
function generate(kind, extra, opts = {}) {
if (state.jobs[kind]) return state.jobs[kind];
const job = generateNow(kind, extra, opts).finally(() => {
if (state.jobs[kind] === job) delete state.jobs[kind];
});
state.jobs[kind] = job;
return job;
}
async function generateNow(kind, extra, { force = false } = {}) {
if (!force && kind !== "review") {
const slug = state.slug;
if (!state.pullDone) {
state.loading[kind] = true;
state.progress[kind] = { started: Date.now(), note: "Checking GitHub for saved notes…" };
render(kind === "hints" ? "reveal" : null);
try {
await state.pull;
} finally {
if (state.slug === slug) {
state.loading[kind] = false;
delete state.progress[kind];
}
}
}
if (state.slug !== slug) return false;
if (state[kind] != null) return true;
}
const result = await request(kind, kind, extra);
if (result) state[kind] = result;
return !!result;
}
async function fetchDeep(i) {
const key = `deep${i}`;
if (state.loading[key]) return;
const slug = state.slug;
if (!state.pullDone) {
state.loading[key] = true;
try {
await state.pull;
} finally {
if (state.slug === slug) state.loading[key] = false;
}
}
if (state.slug !== slug) return;
const overview = state.approach;
const a = overview?.approaches[i];
if (!a || a.deep) return render();
const ed = await readEditorCode().catch(() => null);
const template = ed && ed.lang === "C++" ? ed.code.slice(0, 4000) : "";
const result = await request("deep", key, {
approach: { level: a.level, name: a.name, idea: a.idea, steps: a.steps, time: a.time, space: a.space },
template,
});
if (result && state.approach === overview) {
a.deep = result;
state.step[i] = 0;
await save().catch(() => {});
}
render();
}
async function reveal() {
if (state.revealPending || state.revealed >= TOTAL) return;
if (!state.hints) {
state.revealPending = true;
render();
try {
const ok = await generate("hints");
if (!ok || !state.hints) return render("reveal");
} finally {
state.revealPending = false;
}
}
state.revealed += 1;
state.fresh = state.revealed - 1;
await save().catch(() => {});
render(state.revealed < TOTAL ? "reveal" : "close");
}
async function fetchSection(kind, { force = false } = {}) {
if (state.loading[kind]) return;
const ok = await generate(kind, undefined, { force });
if (ok && kind === "tests") dropResults("generated");
if (ok) {
if (kind === "approach") {
stopPlayer();
state.expanded = new Set([0]);
state.view = {};
state.step = {};
state.codeMode = {};
state.thinkOpen = new Set();
}
await save().catch(() => {});
}
render();
if (ok && kind === "approach") fetchDeep(0);
}
async function fetchCode({ quiet } = {}) {
if (state.codeFetching) return;
state.codeFetching = true;
if (!quiet) render();
const res = await readEditorCode().catch(() => null);
state.codeFetching = false;
if (res && res.code.trim()) {
state.code = res.code;
state.codeLang = res.lang || state.codeLang;
state.codeSource = res.source;
state.error.review = null;
} else if (!quiet) {
state.error.review = {
message: `Couldn't find code in ${SITE.editorName}. Open the code panel, or paste your code below.`,
code: "NO_CODE",
};
}
render();
}
async function runReview() {
if (state.loading.review) return;
if (!state.code.trim()) await fetchCode({ quiet: true });
if (!state.code.trim()) {
state.error.review = { message: "Paste your code in the box first, or click Fetch from editor.", code: "NO_CODE" };
return render();
}
const code = state.code;
const ok = await generate("review", {
code,
language: state.codeLang || toolbarLanguage() || "unknown",
note: state.note.trim(),
});
if (ok) {
state.reviewFor = code;
state.showCorrect = false;
await save().catch(() => {});
}
render();
if (ok) root.querySelector(".review-result")?.scrollIntoView({ block: "start", behavior: "smooth" });
}
async function regenerate() {
const kind = state.tab;
if (state.loading[kind]) return;
if (kind === "review") return runReview();
const what = { hints: "hints", tests: "test cases", approach: "explanation" }[kind];
const extra = kind === "hints" ? " Your progress stays on the same rung." : "";
if (!window.confirm(`Replace these ${what} with a new set?${extra}`)) return;
if (kind === "hints") {
const keep = Math.max(1, state.revealed);
const ok = await generate("hints", undefined, { force: true });
if (ok) {
state.revealed = keep;
state.fresh = -1;
await save().catch(() => {});
}
render();
} else {
await fetchSection(kind, { force: true });
}
}
async function startOver() {
state.revealed = 0;
state.fresh = -1;
state.error.hints = null;
await save().catch(() => {});
render("reveal");
}
function openSettings() {
try {
chrome.runtime.sendMessage({ type: "OPEN_OPTIONS" });
} catch (_) {
state.error[state.tab] = { message: RELOAD_MSG, code: "RELOAD" };
render();
}
}
const caseText = (c) => c.args.map((a) => a.value).join("\n");
async function copy(btn, text) {
const original = btn.textContent;
try {
await navigator.clipboard.writeText(text);
btn.textContent = "Copied";
} catch (_) {
btn.textContent = "Copy failed";
}
setTimeout(() => (btn.textContent = original), 1400);
}
function copyCases(btn) {
const { group, index } = btn.dataset;
const generated = state.tests ? [...state.tests.normal, ...state.tests.edge] : [];
const mine = state.customTests || [];
const list = group === "all" ? [...generated, ...mine] : group === "custom" ? mine : state.tests?.[group] || [];
const cases = index != null ? [list[Number(index)]] : list;
if (cases.some(Boolean)) copy(btn, cases.filter(Boolean).map(caseText).join("\n"));
}
const MAX_CUSTOM = 20;
function dropResults(which) {
if (!state.runResults) return;
const kept = Object.entries(state.runResults).filter(([key]) => key.startsWith("custom:") === (which === "generated"));
state.runResults = kept.length ? Object.fromEntries(kept) : null;
}
function splitTopLevel(text) {
const parts = [];
let depth = 0;
let quote = "";
let cur = "";
for (const ch of text) {
if (quote) {
if (ch === quote) quote = "";
} else if (ch === '"' || ch === "'") quote = ch;
else if ("([{".includes(ch)) depth++;
else if (")]}".includes(ch)) depth--;
else if (ch === "," && depth === 0) {
parts.push(cur);
cur = "";
continue;
}
cur += ch;
}
parts.push(cur);
return parts.map((p) => p.trim()).filter(Boolean);
}
function customParams() {
const sample = state.tests?.normal?.[0] || state.tests?.edge?.[0] || (state.customTests || []).find((c) => c.args.every((a) => a.name));
if (sample?.args?.length && sample.args.every((a) => a.name)) {
return sample.args.map((a) => ({ name: a.name, kind: a.kind || "", example: a.value }));
}
if (SITE.id === "gfg") {
const boxes = gfgInputFields();
if (boxes.length) return boxes.map((b) => ({ name: b.name, kind: "", example: b.sample }));
}
const text = SITE.descriptionEls().map(statementText).filter(Boolean).join("\n");
for (const m of text.matchAll(/Input\s*:\s*([^\n]*?)(?=\s*Output\s*:|\n|$)/gi)) {
const params = splitTopLevel(m[1]).map((part) => {
const eq = part.indexOf("=");
return { name: eq > 0 ? part.slice(0, eq).trim() : "", kind: "", example: part.slice(eq + 1).trim() };
});
if (params.length && params.every((p) => /^[A-Za-z_]\w*(\[\])?$/.test(p.name))) return params.slice(0, 10);
}
return [];
}
function openCustomForm(index = -1) {
const c = index >= 0 ? state.customTests?.[index] : null;
let raw;
let args;
if (c) {
raw = !c.args.every((a) => a.name);
args = raw ? [] : c.args.map((a) => ({ name: a.name, kind: a.kind || "", value: a.value, example: "" }));
} else {
const params = customParams();
raw = !params.length;
args = params.map((p) => ({ ...p, value: "" }));
}
state.customForm = {
index,
raw,
args,
rawText: c && raw ? c.args.map((a) => a.value).join("\n") : "",
output: c?.output || "",
note: c?.note || "",
error: "",
};
render();
root.querySelector(".custom-form input, .custom-form textarea")?.focus();
}
function closeCustomForm() {
const editing = state.customForm?.index ?? -1;
state.customForm = null;
render();
root.querySelector(editing >= 0 ? `[data-action="custom-edit"][data-index="${editing}"]` : '[data-action="custom-add"]')?.focus();
}
function saveCustomCase() {
const f = state.customForm;
if (!f) return;
const fail = (message) => {
f.error = message;
render();
};
let args;
if (f.raw) {
const lines = f.rawText.split("\n").map((l) => l.trim()).filter(Boolean);
if (!lines.length) return fail("Type the input first, one value per line.");
args = lines.map((value) => ({ name: "", value }));
} else {
const empty = f.args.find((a) => !a.value.trim());
if (empty) return fail(`Fill in ${empty.name}.`);
args = f.args.map((a) => ({ name: a.name, value: a.value.trim(), ...(a.kind ? { kind: a.kind } : {}) }));
}
const list = [...(state.customTests || [])];
if (f.index < 0 && list.length >= MAX_CUSTOM) return fail(`You can keep up to ${MAX_CUSTOM} cases of your own.`);
const c = { args, output: f.output.trim(), note: f.note.trim() };
if (f.index >= 0) {
list[f.index] = c;
if (state.runResults) delete state.runResults[`custom:${f.index}`];
} else list.push(c);
state.customTests = list;
const at = f.index >= 0 ? f.index : list.length - 1;
state.customForm = null;
render();
root.querySelector(`[data-action="custom-edit"][data-index="${at}"]`)?.focus();
save().catch(() => {});
}
function deleteCustomCase(i) {
const list = [...(state.customTests || [])];
if (!list[i]) return;
list.splice(i, 1);
if (state.runResults) {
const next = {};
for (const [key, r] of Object.entries(state.runResults)) {
const m = key.match(/^custom:(\d+)$/);
const k = m ? Number(m[1]) : -1;
if (!m || k < i) next[key] = r;
else if (k > i) next[`custom:${k - 1}`] = r;
}
state.runResults = Object.keys(next).length ? next : null;
}
if (state.customForm?.index === i) state.customForm = null;
else if (state.customForm?.index > i) state.customForm.index--;
state.customTests = list;
render();
root.querySelector(list.length ? `[data-action="custom-delete"][data-index="${Math.min(i, list.length - 1)}"]` : '[data-action="custom-add"]')?.focus();
save().catch(() => {});
}
async function runPlanCheck() {
if (state.loading.plan) return;
const plan = state.planText.trim();
if (plan.length < 15) {
state.error.plan = { message: "Describe your approach in a sentence or two first: the idea, the data structure, the steps.", code: "NO_PLAN" };
return render();
}
const ed = await readEditorCode().catch(() => null);
const result = await request("plan", "plan", { plan, language: (ed && ed.lang) || state.codeLang || toolbarLanguage() });
if (result) {
state.planCheck = result;
state.planCheckFor = plan;
await save().catch(() => {});
}
render();
if (result) root.querySelector(".plan-result")?.scrollIntoView({ block: "start", behavior: "smooth" });
}
const canRunTests = () => (SITE.id === "leetcode" && !/leetcode\.cn$/.test(location.hostname)) || SITE.id === "gfg";
const csrfToken = () => decodeURIComponent((document.cookie.match(/(?:^|;\s*)csrftoken=([^;]+)/) || [])[1] || "");
const sleepMs = (ms) => new Promise((r) => setTimeout(r, ms));
class RunError extends Error {}
async function leetcodeApi(path, body) {
let res;
try {
res = await fetch(location.origin + path, {
method: body ? "POST" : "GET",
credentials: "include",
headers: { "content-type": "application/json", "x-csrftoken": csrfToken(), "x-requested-with": "XMLHttpRequest" },
body: body ? JSON.stringify(body) : undefined,
});
} catch (_) {
throw new RunError("Couldn't reach LeetCode. Check your connection.");
}
if (res.status === 401 || res.status === 403) throw new RunError("Sign in to LeetCode to run tests.");
if (res.status === 429) throw new RunError("LeetCode says you're running code too often. Wait a few seconds and try again.");
let data = null;
try {
data = await res.json();
} catch (_) {
}
if (!res.ok) throw new RunError(data?.error || `LeetCode returned error ${res.status}.`);
return data;
}
const questions = new Map();
async function leetcodeQuestion(slug) {
if (questions.has(slug)) return questions.get(slug);
const data = await leetcodeApi("/graphql", {
query: "query q($titleSlug: String!) { question(titleSlug: $titleSlug) { questionId title difficulty content } }",
variables: { titleSlug: slug },
});
const q = data?.data?.question || null;
if (q) questions.set(slug, q);
return q;
}
async function questionId(slug) {
const id = (await leetcodeQuestion(slug))?.questionId;
if (!id) throw new RunError("Couldn't find this problem's id on LeetCode.");
return id;
}
const normalizeOutput = (v) => String(v ?? "").replace(/\s+/g, "").replace(/'/g, '"');
const looseOutput = (v) => String(v ?? "").replace(/[\s,"'[\]]/g, "");
const sameOutput = (a, b) => (SITE.id === "gfg" ? looseOutput(a) === looseOutput(b) : normalizeOutput(a) === normalizeOutput(b));
async function runAllTests(scope = "all") {
if (state.runState.running) return;
const mine = (state.customTests || []).map((c, i) => ({ key: `custom:${i}`, c }));
const generated = state.tests
? [...state.tests.normal.map((c, i) => ({ key: `normal:${i}`, c })), ...state.tests.edge.map((c, i) => ({ key: `edge:${i}`, c }))]
: [];
const cases = scope === "custom" ? mine : [...generated, ...mine];
if (!cases.length) return;
if (!canRunTests()) {
state.runState = { running: false, message: "", error: { title: "Not available here", detail: SITE.runHint } };
return render();
}
const slug = state.slug;
const setRun = (patch) => {
if (state.slug !== slug) return;
state.runState = { ...state.runState, ...patch };
if (state.open && state.tab === "tests") render();
};
setRun({ running: true, message: SITE.id === "gfg" ? "Opening Custom Input…" : "Reading your code…", error: null });
try {
const results = SITE.id === "gfg" ? await runOnGfg(slug, cases, setRun) : await runOnLeetcode(slug, cases, setRun);
if (!results || state.slug !== slug) return;
const all = Object.values(results);
const passed = all.filter((r) => r.status === "pass").length;
setRun({ running: false, message: `${passed} of ${all.length} passed`, error: null });
await save().catch(() => {});
} catch (err) {
setRun({ running: false, message: "", error: { title: err.message, detail: err.detail || "" } });
if (state.slug === slug) await save().catch(() => {});
}
}
async function runOnLeetcode(slug, cases, setRun) {
const ed = await readEditorCode().catch(() => null);
if (!ed || !ed.code.trim()) throw new RunError("Couldn't read your code from the editor.");
const lang = LC_LANG_SLUGS[ed.lang];
if (!lang) throw new RunError(`Running ${ed.lang || "this language"} isn't supported yet.`);
const qid = await questionId(slug);
const results = {};
const BATCH = 6;
for (let b = 0; b < cases.length; b += BATCH) {
const batch = cases.slice(b, b + BATCH);
setRun({ message: `Running cases ${b + 1}–${b + batch.length} of ${cases.length}…` });
const started = await leetcodeApi(`/problems/${slug}/interpret_solution/`, {
lang,
question_id: qid,
typed_code: ed.code,
data_input: batch.map((x) => caseText(x.c)).join("\n"),
});
const runId = started?.interpret_id;
if (!runId) throw new RunError(started?.error || "LeetCode didn't start the run.");
let d = null;
for (let tries = 0; tries < 40; tries++) {
await sleepMs(tries === 0 ? 700 : 900);
d = await leetcodeApi(`/submissions/detail/${runId}/check/`);
if (d?.state === "SUCCESS") break;
}
if (d?.state !== "SUCCESS") throw new RunError("LeetCode took too long to run the code. Try again.");
if (d.status_msg === "Compile Error" || d.compile_error) {
throw Object.assign(new RunError("Your code doesn't compile."), { detail: d.full_compile_error || d.compile_error || "" });
}
const answers = d.code_answer || [];
const expected = d.expected_code_answer || [];
const cmp = String(d.compare_result || "");
const stdout = d.std_output_list || [];
const failedRun = d.run_success === false || /Error|Exceeded/.test(d.status_msg || "");
batch.forEach((x, k) => {
if (k < cmp.length) {
results[x.key] = { status: cmp[k] === "1" ? "pass" : "fail", output: answers[k], expected: expected[k], stdout: stdout[k] || "" };
} else if (failedRun) {
results[x.key] = {
status: "error",
error: d.status_msg || "Error",
detail: d.full_runtime_error || d.runtime_error || "",
expected: expected[k],
stdout: stdout[k] || "",
};
} else {
results[x.key] = { status: "fail", output: answers[k], expected: expected[k], stdout: stdout[k] || "" };
}
});
if (state.slug !== slug) return null;
state.runResults = { ...(state.runResults || {}), ...results };
if (b + BATCH < cases.length) await sleepMs(1200);
}
return results;
}
function gfgInputFields() {
const out = [];
const seen = new Set();
for (const f of document.querySelectorAll('[class*="custom_separate_input_textarea"]')) {
if (/readonly/.test(f.className)) continue;
const name = (f.querySelector("label")?.textContent || "").replace(/=\s*$/, "").trim();
const ta = f.querySelector("textarea");
if (!name || !ta || seen.has(name)) continue;
seen.add(name);
out.push({ name, sample: String(ta.value || "").slice(0, 200) });
}
return out.slice(0, 12);
}
function gfgRunCase(args) {
return new Promise((resolve) => {
const id = Math.random().toString(36).slice(2);
const done = (r) => {
window.removeEventListener("message", onMsg);
clearTimeout(timer);
resolve(r);
};
const onMsg = (e) => {
if (e.source === window && e.data?.type === "LCHL_GFG_RUN_DONE" && e.data.id === id) done(e.data);
};
const timer = setTimeout(() => done({ ok: false, code: "NO_BRIDGE" }), 90000);
window.addEventListener("message", onMsg);
window.postMessage({ type: "LCHL_GFG_RUN", id, args: args.map((a) => ({ name: a.name, value: a.value })) }, location.origin);
});
}
const GFG_RUN_ERRORS = {
LOGIN: "Sign in to GeeksforGeeks to run code.",
NO_FIELDS: "Couldn't open GeeksforGeeks' Custom Input. Open it below the editor and try again.",
NO_BUTTON: "Couldn't find GeeksforGeeks' Compile & Run button.",
BUSY_BUTTON: "GeeksforGeeks is still busy with another run. Try again when it finishes.",
NO_START: "GeeksforGeeks didn't start the run. Check that you're signed in, then try again.",
BUSY: "GeeksforGeeks' servers are busy right now. Try again in a minute.",
TIMEOUT: "GeeksforGeeks took too long to run the code. Try again.",
NO_BRIDGE: "Couldn't talk to the GeeksforGeeks page. Refresh it and try again.",
};
const gfgOutputAt = (msg, i) => {
const o = msg && typeof msg === "object" ? msg.output : undefined;
return Array.isArray(o) ? o[i] : o;
};
const gfgText = (v) => (v == null ? "" : typeof v === "string" ? v : JSON.stringify(v)).replace(/\r\n/g, "\n");
const htmlText = (html) =>
(new DOMParser().parseFromString(String(html || "").replace(/<br\s*\/?>/gi, "\n"), "text/html").body.textContent || "").trim();
function gfgCaseResult(r, c) {
const ts = r.testSolution || {};
const m = ts.message && typeof ts.message === "object" ? ts.message : { error: ts.message };
const i = r.caseIndex || 0;
const expected = r.expectedOutput ? gfgText(gfgOutputAt(r.expectedOutput.message, i)) : null;
if (ts.view_mode === "compilation") return { compileError: htmlText(m.error || m.output || "") };
if (ts.view_mode === "runtime" || (m.error && m.output == null)) {
return { status: "error", error: "Runtime error", detail: htmlText(m.error), expected: expected?.trim() ?? "" };
}
const output = gfgText(gfgOutputAt(m, i));
const anyValid = !!(ts.is_multiple_answer || r.expectedOutput?.is_multiple_answer);
const verdict = Array.isArray(m.case_results) ? m.case_results[i] : null;
let pass;
if (verdict) pass = verdict.status === "correct";
else if (typeof m.multiple_answer_correct === "boolean") pass = m.multiple_answer_correct;
else if (expected != null) pass = output === expected;
else pass = sameOutput(output, c.output);
const res = { status: pass ? "pass" : "fail", output: output.trim(), expected: expected != null ? expected.trim() : "", stdout: "" };
if (anyValid) res.anyValid = true;
if (!pass && expected != null && output.trimEnd() === expected.trimEnd()) {
res.note = "Same answer, but your code prints extra blank lines or spaces at the end.";
}
return res;
}
async function runOnGfg(slug, cases, setRun) {
const results = {};
try {
for (let k = 0; k < cases.length; k++) {
setRun({ message: `Running case ${k + 1} of ${cases.length}…` });
const r = await gfgRunCase(cases[k].c.args);
if (state.slug !== slug) return null;
if (!r.ok) {
if (r.code === "FIELDS") {
throw Object.assign(new RunError("These tests don't match GeeksforGeeks' input boxes."), {
detail: `GeeksforGeeks asks for: ${(r.fields || []).join(", ")}\nThe tests give: ${(r.args || []).join(", ")}\nClick Regenerate to write tests for GeeksforGeeks' inputs.`,
});
}
throw new RunError(r.error || GFG_RUN_ERRORS[r.code] || "GeeksforGeeks couldn't run the code.");
}
const res = gfgCaseResult(r, cases[k].c);
if (res.compileError != null) throw Object.assign(new RunError("Your code doesn't compile."), { detail: res.compileError });
results[cases[k].key] = res;
state.runResults = { ...(state.runResults || {}), [cases[k].key]: res };
}
} finally {
window.postMessage({ type: "LCHL_GFG_RESTORE" }, location.origin);
}
return results;
}
function toast(text, kind = "good", ms = 6000, link = null) {
const a = link?.href ? ` <a href="${escapeHtml(link.href)}" target="_blank" rel="noopener noreferrer">${escapeHtml(link.label || "Open")}</a>` : "";
toastEl.innerHTML = `<div class="toast ${kind}" role="status">${escapeHtml(text)}${a}</div>`;
clearTimeout(toast.timer);
toast.timer = setTimeout(() => (toastEl.innerHTML = ""), ms);
}
async function recordSubmission(r) {
if (!state.slug || (r.slug && r.slug !== state.slug)) return;
if (r.site === "gfg") {
if (!r.code) {
const ed = await readEditorCode().catch(() => null);
r.code = ed?.code || "";
}
const latest = state.mySolutions?.[0];
if (latest && latest.code === r.code && Date.now() - Date.parse(latest.acceptedAt) < 10 * 60000) return;
}
state.attempts += 1;
if (!r.accepted) {
await save().catch(() => {});
toast(`${r.statusMsg || "Not accepted"}. The Review tab can show you why.`, "warn");
return;
}
const entry = {
code: r.code || "",
lang: LC_LANG_NAMES[r.lang] || LANG_NAMES[r.lang] || r.lang || toolbarLanguage() || "",
runtime: r.runtime || "",
memory: r.memory || "",
runtimePercentile: r.runtimePercentile ?? null,
memoryPercentile: r.memoryPercentile ?? null,
passed: r.totalTestcases != null ? `${r.totalCorrect} / ${r.totalTestcases}` : r.passed || "",
attempts: state.attempts,
hintsUsed: state.revealed,
acceptedAt: new Date().toISOString(),
platform: SITE.name,
};
if (!entry.code) {
const ed = await readEditorCode().catch(() => null);
entry.code = ed?.code || "";
}
const list = (state.mySolutions || []).filter((x) => x.code !== entry.code);
state.mySolutions = [entry, ...list].slice(0, 5);
await save().catch(() => {});
toast(
state.syncEnabled && state.includeSolutions && !state.pullFailed
? "Accepted! Saving your solution to GitHub…"
: "Accepted! Your solution is saved with your notes."
);
if (state.open) render();
}
window.addEventListener("message", (e) => {
if (e.source !== window || !e.data || e.data.type !== "LCHL_SUBMISSION" || !e.data.result) return;
recordSubmission(e.data.result);
});
const SOLVED_RE = /Problem Solved Successfully/i;
let lastGfgSolve = 0;
function isShown(el) {
if (!el || el.closest("script, style, noscript, template, [hidden], [aria-hidden='true']")) return false;
if (!el.getClientRects().length) return false;
const cs = getComputedStyle(el);
return cs.visibility !== "hidden" && cs.display !== "none" && Number(cs.opacity) !== 0;
}
function solvedElement(node) {
const el = node.nodeType === 3 ? node.parentElement : node;
if (!el || !SOLVED_RE.test(el.textContent || "")) return null;
const candidates = [el, ...el.querySelectorAll("*")].filter((x) => SOLVED_RE.test(x.textContent || ""));
const hit = candidates.reverse().find((x) => isShown(x) && SOLVED_RE.test(x.innerText || ""));
return hit || null;
}
const countedBanners = new WeakSet();
function checkGfgSolved(node) {
if (Date.now() - lastGfgSolve < (window.__LCHL_GFG_REPEAT_MS || 20000)) return;
const hit = solvedElement(node);
if (!hit) return;
if (countedBanners.has(hit)) return;
countedBanners.add(hit);
lastGfgSolve = Date.now();
let box = hit;
for (let k = 0; k < 4 && box.parentElement && !/Test Cases Passed/i.test(box.innerText || ""); k++) box = box.parentElement;
const all = (box.innerText || "").replace(/\s+/g, " ");
recordSubmission({
site: "gfg",
accepted: true,
statusMsg: "Accepted",
passed: ((all.match(/Test Cases Passed[:\s]*([\d,]+\s*\/\s*[\d,]+)/i) || [])[1] || "").replace(/\s+/g, " "),
runtime: (() => {
const t = all.match(/Time Taken[:\s]*([\d.]+)\s*(s|sec|seconds)?/i);
return t ? `${t[1]} s` : "";
})(),
});
}
if (SITE.id === "gfg") {
new MutationObserver((mutations) => {
for (const m of mutations) {
for (const n of m.addedNodes) if (n.nodeType === 1 || n.nodeType === 3) checkGfgSolved(n);
if (m.type === "attributes" && m.target.nodeType === 1 && m.target.childElementCount < 60) checkGfgSolved(m.target);
}
}).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "style", "hidden"] });
}
function openOn(tab, { mode } = {}) {
const wasOpen = state.open;
state.open = true;
if (mode) state.reviewMode = mode;
if (state.tab !== tab) state.tab = tab;
render();
if (!wasOpen) panelOpened();
}
const SHORTCUTS = [
{ code: "KeyH", keys: "Alt+H", desc: "Open the panel, or show the next hint", run: () => {
if (!state.open || state.tab !== "hints") return openOn("hints"), root.querySelector('[data-action="reveal"]')?.focus();
reveal();
} },
{ code: "KeyT", keys: "Alt+T", desc: "Test cases", run: () => openOn("tests") },
{ code: "KeyU", keys: "Alt+U", desc: "Run all test cases", run: () => {
openOn("tests");
if (state.tests) runAllTests();
} },
{ code: "KeyI", keys: "Alt+I", desc: "Intuition", run: () => openOn("approach") },
{ code: "KeyP", keys: "Alt+P", desc: "Check my approach (before coding)", run: () => {
openOn("review", { mode: "plan" });
root.querySelector("#plan")?.focus();
} },
{ code: "KeyR", keys: "Alt+R", desc: "Review my code", run: () => {
openOn("review", { mode: "code" });
if (!state.code) fetchCode({ quiet: true });
} },
{ code: "KeyW", keys: "Alt+W", desc: "Wider / narrower panel", run: () => {
state.wide = !state.wide;
chrome.storage.local.set({ ui: { wide: state.wide } }).catch(() => {});
state.open = true;
render();
} },
{ code: "KeyM", keys: "Alt+M", desc: "Full screen panel (hides the problem); Esc to leave", run: () => {
state.open = true;
setFull(!state.full);
} },
{ code: "Slash", keys: "Alt+/", desc: "Show these shortcuts", run: () => {
state.open = true;
state.showKeys = !state.showKeys;
render();
if (state.showKeys) root.querySelector(".scroll").scrollTop = 0;
} },
];
window.addEventListener(
"keydown",
(e) => {
if (!state.slug || !state.shortcutsOn || !e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
const sc = SHORTCUTS.find((x) => x.code === e.code);
if (!sc) return;
e.preventDefault();
e.stopPropagation();
sc.run();
},
true
);
chrome.runtime.onMessage?.addListener((msg) => {
if (msg?.type === "COMMAND" && msg.command === "toggle-panel" && state.slug) {
state.open = !state.open;
render(state.open && state.tab === "hints" ? "reveal" : null);
if (state.open) panelOpened();
}
});
const AUTHOR = { name: "Rishit Aggarwal", linkedin: "https://www.linkedin.com/in/rishit-aggarwal/", github: "https://github.com/rishitaggarwal1", medium: "https://medium.com/@rishitaggarwal1" };
function aboutHtml() {
if (!state.showAbout) return "";
const link = (href, label) => `<a href="${href}" target="_blank" rel="noopener noreferrer">${label}</a>`;
return `<div class="keys about" role="note">
      <div class="keys-head"><strong>About AlgoSphere</strong><button class="mini" data-action="about">Close</button></div>
      <p>Designed and built by <strong>${AUTHOR.name}</strong>.</p>
      <p class="about-links">${link(AUTHOR.linkedin, "LinkedIn")} · ${link(AUTHOR.github, "GitHub")} · ${link(AUTHOR.medium, "Medium")}</p>
      <p class="muted small">Apache License 2.0. Copies must keep the NOTICE file crediting the developer.</p>
    </div>`;
}
function keysHtml() {
if (!state.showKeys) return "";
return `<div class="keys" role="note">
      <div class="keys-head"><strong>Keyboard shortcuts</strong><button class="mini" data-action="keys">Close</button></div>
      <table>${SHORTCUTS.map((x) => `<tr><td><kbd>${escapeHtml(x.keys)}</kbd></td><td>${escapeHtml(x.desc)}</td></tr>`).join("")}
        <tr><td><kbd>Alt+Shift+H</kbd></td><td>Open or close the panel (change it at chrome://extensions/shortcuts)</td></tr>
        <tr><td><kbd>Esc</kbd></td><td>Close the panel</td></tr>
      </table>
      <p class="muted small">On a Mac, use Option instead of Alt. Turn shortcuts off in Settings.</p>
    </div>`;
}
function panelOpened() {
if (!state.slug) return;
const slug = state.slug;
const prepare = (kind) => {
if (state[kind] || state.jobs[kind] || state.error[kind]) return Promise.resolve();
return generate(kind).then(async (ok) => {
if (!ok || state.slug !== slug) return;
if (kind === "tests") dropResults("generated");
await save().catch(() => {});
if (state.open) render();
});
};
const hints = state.prefetchHints ? prepare("hints") : Promise.resolve();
if (!state.prefetchTests) return;
hints.then(() => state.slug === slug && !state.error.hints && prepare("tests"));
}
const usageDay = (t = Date.now()) => new Date(t).toLocaleDateString("en-CA");
async function loadUsage() {
try {
const { usage, settings } = await chrome.storage.local.get(["usage", "settings"]);
state.usageToday = usage?.days?.[usageDay()] || null;
state.usageSettings = settings?.usage || {};
state.includeSolutions = settings?.github?.includeSolutions !== false;
state.prefetchHints = settings?.prefetchHints !== false;
state.prefetchTests = settings?.prefetchTests !== false;
} catch (_) {
}
}
const fmtTokens = (n) => (n >= 1e6 ? `${(n / 1e6).toFixed(1)}M` : n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n || 0));
const fmtCost = (c) => (c <= 0 ? "$0.00" : c < 0.01 ? "<$0.01" : `$${c.toFixed(2)}`);
function usageChipHtml() {
const t = state.usageToday;
if (!t || !t.requests) return "";
const free = state.usageSettings.geminiFreeTier !== false && t.cost === 0 && t.listCost > 0;
const money = free ? "free tier" : t.unpriced && !t.cost ? "" : fmtCost(t.cost);
const title = [
`AI requests today: ${t.requests}${t.failed ? ` (${t.failed} failed)` : ""}`,
`Tokens: ${fmtTokens(t.input)} in, ${fmtTokens(t.output)} out`,
free ? `Free tier (about ${fmtCost(t.listCost)} on a paid plan)` : money ? `Estimated cost: ${money}` : "",
"Click for details in Settings",
]
.filter(Boolean)
.join("\n");
return `<button class="link usage-chip" data-action="settings" title="${escapeHtml(title)}">AI today: ${t.requests}${money ? ` · ${escapeHtml(money)}` : ""}</button>`;
}
function limitBannerHtml() {
const t = state.usageToday;
const us = state.usageSettings || {};
if (!t) return "";
const notes = [];
const check = (used, limit, label) => {
if (!(limit > 0)) return;
const ratio = used / limit;
if (ratio >= 1) {
notes.push(us.enforce
? `Daily ${label} reached. New AI requests are paused until midnight (you can change this in Settings).`
: `You've reached the daily ${label} you set.`);
} else if (ratio >= 0.8) {
notes.push(label === "budget"
? `${fmtCost(used)} of your ${fmtCost(limit)} daily budget used.`
: `${used} of your ${limit} daily AI requests used.`);
}
};
check(t.requests, Number(us.dailyRequests), "request limit");
check(t.cost, Number(us.dailyBudget), "budget");
return notes.length ? `<p class="warn limit-note" role="status">${notes.map(escapeHtml).join(" ")}</p>` : "";
}
function escapeHtml(s) {
return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}
function fmt(text) {
return escapeHtml(text)
.replace(/`([^`]+)`/g, "<code>$1</code>")
.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
.replace(/\n/g, "<br>");
}
const list = (items, tag = "ul", cls = "bullets") =>
items.length ? `<${tag} class="${cls}">${items.map((t) => `<li>${fmt(t)}</li>`).join("")}</${tag}>` : "";
const busy = (on) => (on ? 'disabled aria-busy="true"' : "");
function errorHtml(kind) {
const err = state.error[kind];
if (!err) return "";
const needsSettings = ["NO_KEY", "BAD_KEY", "BAD_MODEL", "LIMIT", "OVERLOADED"].includes(err.code);
return `<div class="error" role="alert">
      <p>${escapeHtml(err.message)}</p>
      ${needsSettings ? `<button class="secondary" data-action="settings">Open settings</button>` : ""}
    </div>`;
}
function rungHtml(i) {
const num = i + 1;
const label = LABELS[i];
if (i < state.revealed) {
return `<li class="rung revealed${i === state.fresh ? " fresh" : ""}">
        <span class="num" aria-hidden="true">${num}</span>
        <div class="body">
          <h3 class="label">Hint ${num}: ${label}</h3>
          <p class="text">${fmt(state.hints?.[i] ?? "")}</p>
        </div>
      </li>`;
}
if (i === state.revealed) {
const btnText = state.revealPending ? "Writing your hints…" : state.hints ? `Show hint ${num}` : "Show first hint";
return `<li class="rung next">
        <span class="num" aria-hidden="true">${num}</span>
        <div class="body">
          <h3 class="label">Hint ${num}: ${label}</h3>
          <button class="primary" data-action="reveal" ${busy(state.revealPending)}>${btnText}</button>
          ${progressHtml("hints")}
        </div>
      </li>`;
}
return `<li class="rung locked">
      <span class="num" aria-hidden="true">${num}</span>
      <div class="body"><h3 class="label">Hint ${num}: ${label}</h3></div>
    </li>`;
}
function hintsTabHtml() {
const intro = state.hints ? "" : `<p class="intro">Try the problem first. Climb one hint at a time when you're stuck.</p>`;
const rungs = Array.from({ length: TOTAL }, (_, i) => rungHtml(i)).join("");
const done =
state.revealed >= TOTAL
? `<p class="done">That's every hint. Write the code yourself, then use Review to check your thinking.</p>`
: "";
const mine = state.mySolutions?.[0];
const solved = mine
? `<p class="solved">✅ Solved in ${escapeHtml(mine.lang || "code")}${mine.runtime ? ` · ${escapeHtml(mine.runtime)}` : ""}${mine.hintsUsed != null ? ` · ${mine.hintsUsed} hint${mine.hintsUsed === 1 ? "" : "s"} used` : ""}${state.syncEnabled && state.syncedSections.mySolutions === fieldJson("mySolutions") ? " · saved to GitHub" : ""}</p>`
: "";
return `${solved}${intro}<ol class="ladder">${rungs}</ol>${done}`;
}
function caseHtml(c, group, i) {
const mine = group === "custom";
const r = state.runResults?.[`${group}:${i}`];
const argLines = c.args
.map((a) => `<div>${a.name ? `<span class="arg">${escapeHtml(a.name)} =</span> ` : ""}${escapeHtml(a.value)}</div>`)
.join("");
let tag = "";
let note = c.note || "";
if (group === "edge") {
const m = note.match(/^([^:]{2,40}):\s*([\s\S]*)$/);
if (m) {
tag = m[1];
note = m[2];
}
}
const title = mine ? "Yours" : group === "edge" ? "Edge" : "Case";
const label = mine ? `your case ${i + 1}` : `${group} case ${i + 1}`;
const expected = c.output
? escapeHtml(c.output)
: r?.expected
? escapeHtml(r.expected)
: `<span class="muted">${escapeHtml(SITE.name)} works it out when you run it</span>`;
return `<li class="case${mine ? " mine" : ""}">
      <div class="case-head">
        <span class="case-title">${title} ${i + 1}${tag ? ` <span class="tag">${escapeHtml(tag)}</span>` : ""}</span>
        <span class="case-actions">
          <button class="mini" data-action="copy" data-group="${group}" data-index="${i}" aria-label="Copy input of ${label}">Copy input</button>
          ${
mine
? `<button class="mini" data-action="custom-edit" data-index="${i}" aria-label="Edit ${label}">Edit</button>
                 <button class="mini" data-action="custom-delete" data-index="${i}" aria-label="Delete ${label}">Delete</button>`
: ""
}
        </span>
      </div>
      <div class="io"><span class="io-label">Input</span><div class="mono">${argLines}</div></div>
      ${caseVizHtml(c)}
      <div class="io"><span class="io-label">Expected</span><div class="mono">${expected}</div></div>
      ${note ? `<p class="note">${mine ? escapeHtml(note) : fmt(note)}</p>` : ""}
      ${runResultHtml(c, r, mine)}
    </li>`;
}
function runResultHtml(c, r, mine = false) {
if (!r) return "";
const differs = !r.anyValid && c.output && r.expected != null && r.expected !== "" && !sameOutput(r.expected, c.output);
const aiNote = !differs
? ""
: mine
? `<p class="note ai-wrong">The expected output you wrote differs from ${SITE.name}'s: it expects <code>${escapeHtml(r.expected)}</code>.</p>`
: `<p class="note ai-wrong">The expected output above was AI-written and is wrong; ${SITE.name} expects <code>${escapeHtml(r.expected)}</code>.</p>`;
const extra = r.note ? `<p class="note">${escapeHtml(r.note)}</p>` : "";
const out = r.stdout ? `<div class="io"><span class="io-label">Stdout</span><div class="mono">${escapeHtml(r.stdout)}</div></div>` : "";
if (r.status === "pass") {
return `<div class="run-res pass"><strong>✓ Passed</strong> · your output <code>${escapeHtml(r.output ?? "")}</code></div>${out}${aiNote}`;
}
if (r.status === "error") {
return `<div class="run-res error"><strong>⚠ ${escapeHtml(r.error || "Error")}</strong>${r.detail ? `<pre>${escapeHtml(r.detail)}</pre>` : ""}</div>${out}`;
}
return `<div class="run-res fail"><strong>✗ Failed</strong> · your output <code>${escapeHtml(r.output ?? "")}</code> · ${SITE.name} expects <code>${escapeHtml(r.expected ?? "")}</code></div>${out}${extra}${aiNote}`;
}
function runBarHtml() {
const rs = state.runState;
if (!canRunTests()) return `<p class="muted small run-note">${escapeHtml(SITE.runHint)}</p>`;
const counts = state.runResults ? Object.values(state.runResults) : [];
const passed = counts.filter((r) => r.status === "pass").length;
const summary = !rs.running && counts.length
? `<span class="run-summary ${passed === counts.length ? "all-pass" : "some-fail"}">${passed} of ${counts.length} passed</span>`
: "";
return `<div class="run-bar">
        <button class="primary" data-action="run-tests" ${busy(rs.running)}>${rs.running ? escapeHtml(rs.message || "Running…") : `▶ Run all on ${SITE.id === "gfg" ? "GFG" : "LeetCode"}`}</button>
        ${summary}
      </div>
      <p class="muted small run-note">${
SITE.id === "gfg"
? "Runs your editor code on every case below through GeeksforGeeks' Compile &amp; Run (signed in, one case at a time). Expected outputs then come from GeeksforGeeks itself. Your Custom Input is put back afterwards."
: "Runs your editor code on every case below with your LeetCode account. Expected outputs then come from LeetCode itself."
}</p>
      ${
rs.error
? `<div class="error" role="alert"><p>${escapeHtml(rs.error.title)}</p>${rs.error.detail ? `<pre class="err-detail">${escapeHtml(rs.error.detail)}</pre>` : ""}</div>`
: ""
}`;
}
function caseGroupHtml(title, group) {
const items = state.tests[group];
return `<section class="group">
      <div class="group-head">
        <h3>${title} <span class="count">${items.length}</span></h3>
        <button class="mini" data-action="copy" data-group="${group}">Copy all</button>
      </div>
      <ol class="cases">${items.map((c, i) => caseHtml(c, group, i)).join("")}</ol>
    </section>`;
}
function customFormHtml() {
const f = state.customForm;
const editing = f.index >= 0;
const where = SITE.id === "gfg" ? "GeeksforGeeks' Custom Input" : "LeetCode's Testcase tab";
const inputs = f.raw
? `<label class="cf-field" for="cf-raw"><span class="cf-label">Input <small>one value per line, as in ${where}</small></span></label>
         <textarea id="cf-raw" rows="3" spellcheck="false" autocomplete="off">${escapeHtml(f.rawText)}</textarea>`
: f.args
.map(
(a, k) => `<label class="cf-row" for="cf-arg-${k}"><span class="cf-name mono">${escapeHtml(a.name)} =</span>
              <input id="cf-arg-${k}" class="cf-input mono" value="${escapeHtml(a.value)}" placeholder="${escapeHtml(a.example ? `for example ${a.example}` : "")}" spellcheck="false" autocomplete="off"></label>`
)
.join("");
return `<div class="custom-form" role="group" aria-label="${editing ? `Edit your case ${f.index + 1}` : "New test case"}">
      <p class="cf-title">${editing ? `Edit your case ${f.index + 1}` : "New test case"}</p>
      ${inputs}
      <label class="cf-row" for="cf-out"><span class="cf-name">Expected</span>
        <input id="cf-out" class="cf-input mono" value="${escapeHtml(f.output)}" placeholder="optional: ${escapeHtml(SITE.name)} works it out" spellcheck="false" autocomplete="off"></label>
      <label class="cf-row" for="cf-note"><span class="cf-name">Checks</span>
        <input id="cf-note" class="cf-input" value="${escapeHtml(f.note)}" placeholder="optional: what this case tests" autocomplete="off"></label>
      ${f.error ? `<p class="cf-error" role="alert">${escapeHtml(f.error)}</p>` : ""}
      <div class="cf-actions">
        <button class="primary" data-action="custom-save">${editing ? "Save" : "Add case"}</button>
        <button class="secondary" data-action="custom-cancel">Cancel</button>
      </div>
    </div>`;
}
function customGroupHtml() {
const items = state.customTests || [];
const f = state.customForm;
const where = SITE.id === "gfg" ? "GeeksforGeeks' Custom Input" : "LeetCode's Testcase tab";
const running = state.runState.running;
const list = items
.map((c, i) => (f && f.index === i ? `<li class="case mine editing">${customFormHtml()}</li>` : caseHtml(c, "custom", i)))
.join("");
return `<section class="group custom-group" aria-label="Your test cases">
      <div class="group-head">
        <h3>Your cases <span class="count">${items.length}</span></h3>
        <span class="case-actions">
          ${items.length && canRunTests() ? `<button class="mini" data-action="run-custom" ${busy(running)}>▶ Run yours</button>` : ""}
          ${items.length ? `<button class="mini" data-action="copy" data-group="custom">Copy all</button>` : ""}
          ${!f || f.index >= 0 ? `<button class="mini" data-action="custom-add">＋ Add a case</button>` : ""}
        </span>
      </div>
      ${f && f.index < 0 ? customFormHtml() : ""}
      ${items.length ? `<ol class="cases">${list}</ol>` : f ? "" : `<p class="muted small custom-empty">Add your own inputs, like ${where}. They run with the others, and ${escapeHtml(SITE.name)} works out what they should return.</p>`}
    </section>`;
}
function testsTabHtml() {
const generate = `<div class="empty">
        <p class="intro">Get 5 normal test cases and a set of edge cases (boundaries, empty or single inputs, duplicates, extremes) to check your solution before you submit.</p>
        <button class="primary" data-action="fetch" data-kind="tests" ${busy(state.loading.tests)}>
          ${state.loading.tests ? "Writing test cases…" : "Generate test cases"}
        </button>
        ${progressHtml("tests")}
      </div>`;
if (!state.tests) {
const mine = state.customTests?.length || state.customForm;
return `${mine ? runBarHtml() : ""}${generate}${customGroupHtml()}`;
}
return `${runBarHtml()}
      <p class="intro small">${SITE.testcaseHint} Expected outputs are AI-written until you run them, so if one disagrees with your code, check it.</p>
      ${customGroupHtml()}
      ${caseGroupHtml("Normal cases", "normal")}
      ${caseGroupHtml("Edge cases", "edge")}`;
}
const levelClass = (lvl) => {
const l = lvl.toLowerCase();
return l.includes("optimal") ? "optimal" : l.includes("brute") ? "brute" : "better";
};
const CPP_KEYWORDS = new Set(
"alignas auto bool break case catch char class const constexpr continue default delete do double else enum explicit extern false float for friend if inline int long mutable namespace new noexcept nullptr operator private protected public return short signed sizeof static struct switch template this throw true try typedef typename union unsigned using virtual void volatile while".split(" ")
);
const CPP_TYPES = new Set(
"string vector map unordered_map set unordered_set multiset multimap pair queue stack priority_queue deque list array tuple bitset size_t int64_t uint64_t ListNode TreeNode Node Solution greater less cout cin endl".split(" ")
);
const PSEUDO_KEYWORDS = new Set(
"function for each in to downto from step while if else elif then return break continue do and or not end repeat until true false null none".split(" ")
);
const TOKEN_RE = /(\/\/[^\n]*|\/\*[\s\S]*?\*\/)|("(?:\\.|[^"\\\n])*"|'(?:\\.|[^'\\\n])*')|(#[ \t]*[a-z]+[^\n]*)|(\b\d+(?:\.\d+)?\b)|([A-Za-z_]\w*)/g;
function highlight(src, lang) {
const cpp = lang === "cpp";
let out = "";
let last = 0;
let m;
TOKEN_RE.lastIndex = 0;
while ((m = TOKEN_RE.exec(src))) {
out += escapeHtml(src.slice(last, m.index));
const t = escapeHtml(m[0]);
if (m[1]) out += `<span class="tk-c">${t}</span>`;
else if (m[2]) out += cpp || m[0][0] === '"' ? `<span class="tk-s">${t}</span>` : t;
else if (m[3]) out += cpp ? `<span class="tk-p">${t}</span>` : t;
else if (m[4]) out += `<span class="tk-n">${t}</span>`;
else if ((cpp ? CPP_KEYWORDS : PSEUDO_KEYWORDS).has(cpp ? m[0] : m[0].toLowerCase())) out += `<span class="tk-k">${t}</span>`;
else if (cpp && CPP_TYPES.has(m[0])) out += `<span class="tk-t">${t}</span>`;
else out += t;
last = TOKEN_RE.lastIndex;
}
return out + escapeHtml(src.slice(last));
}
function codeBlock(src, lang) {
const lines = highlight(String(src), lang).split("\n");
return `<div class="codelines ${lang}">${lines
.map((l, k) => `<div class="cl" data-line="${k + 1}"><span class="ln">${k + 1}</span><span class="lc">${l || " "}</span></div>`)
.join("")}</div>`;
}
const codeFor = (d, mode) => (mode === "full" ? [d.prelude, d.solution, d.main].filter(Boolean).join("\n\n") : d.solution);
function deepStatus(i, what) {
const key = `deep${i}`;
const err = state.error[key];
if (state.loading[key]) {
return `<div class="deep-loading" role="status"><span class="spinner" aria-hidden="true"></span>
        <span>Preparing the pseudocode, complexity breakdown, animated dry run and C++ code for this approach…</span></div>
        ${progressHtml(key)}`;
}
if (err) {
return `<div class="error" role="alert"><p>${escapeHtml(err.message)}</p>
        <button class="secondary" data-action="deep" data-index="${i}">Try again</button></div>`;
}
return `<button class="secondary" data-action="deep" data-index="${i}">Load ${what}</button>`;
}
function costHtml(title, b, fallback) {
return `<div class="cost">
      <div class="cost-head"><span class="cost-title">${title}</span><code class="big">${escapeHtml(b.total || fallback)}</code></div>
      ${
b.parts.length
? `<div class="table-wrap"><table class="cost-table"><thead><tr><th>Part</th><th>Cost</th><th>Why</th></tr></thead><tbody>${b.parts
.map((p) => `<tr><td>${fmt(p.part)}</td><td class="nowrap">${fmt(p.cost)}</td><td>${fmt(p.why)}</td></tr>`)
.join("")}</tbody></table></div>`
: ""
}
      ${b.sum ? `<p class="derive"><span class="derive-label">Adding it up</span>${fmt(b.sum)}</p>` : ""}
      ${b.cases ? `<p class="small"><span class="muted">Best vs worst case:</span> ${fmt(b.cases)}</p>` : ""}
      ${b.feel ? `<p class="small"><span class="muted">At the maximum input:</span> ${fmt(b.feel)}</p>` : ""}
      ${b.note ? `<p class="small"><span class="muted">Not counted:</span> ${fmt(b.note)}</p>` : ""}
    </div>`;
}
function explanationHtml(a, i, level) {
const d = a.deep;
const complexity =
d && d.time && d.space
? costHtml("Time", d.time, a.time) + costHtml("Space", d.space, a.space)
: `<div class="cx">
            <div><span class="cx-label">Time</span><code>${escapeHtml(a.time)}</code></div>
            <div><span class="cx-label">Space</span><code>${escapeHtml(a.space)}</code></div>
          </div>
          ${a.complexity ? `<p>${fmt(a.complexity)}</p>` : ""}
          ${d ? "" : deepStatus(i, "the line-by-line complexity breakdown")}`;
return `<p>${fmt(a.idea)}</p>
      ${a.steps.length ? `<h4>Steps</h4>${list(a.steps, "ol", "steps")}` : ""}
      <h4>How the complexity comes about</h4>
      ${complexity}
      ${a.tradeoff ? `<h4>${level === "optimal" ? "Why this is the best" : "Why move on"}</h4><p>${fmt(a.tradeoff)}</p>` : ""}`;
}
function pseudoHtml(a, i) {
if (!a.deep) return deepStatus(i, "the pseudocode");
return `<p class="muted small">Line numbers match the complexity table and the dry run. Open <strong>Dry run</strong> to watch it execute.</p>
      <div class="codebox">${codeBlock(a.deep.pseudocode.join("\n"), "pseudo")}</div>`;
}
function playerHtml(i, d, a) {
const dr = d.dryRun;
const n = dr.steps.length;
const fs = state.playerFull === i;
return `<div class="player${fs ? " fs" : ""}" data-index="${i}" tabindex="0" ${fs ? 'role="dialog" aria-modal="true" ' : ""}aria-label="Dry run player. Space plays or pauses; arrow keys step; F for full screen.">
      ${fs ? `<div class="pl-fs-head"><span class="pl-fs-title">Dry run · ${escapeHtml(a?.level || "")}${a?.name ? ` — ${escapeHtml(a.name)}` : ""}</span><button class="pl-btn" data-action="pl-full" title="Leave full screen (Esc)">⤡ Exit full screen</button></div>` : ""}
      ${dr.input ? `<p class="dr-input"><span class="io-label">Input</span> <code>${escapeHtml(dr.input)}</code></p>` : ""}
      <div class="pl-grid">
        <div class="pl-stage">
          <div class="pl-shapes"></div>
          <div class="pl-arrays"></div>
          <div class="pl-structs"></div>
          <div class="pl-vars"></div>
        </div>
        <div class="pl-code">${codeBlock(d.pseudocode.join("\n"), "pseudo")}</div>
      </div>
      <div class="pl-explain" aria-live="polite"></div>
      <div class="pl-controls">
        <button class="pl-btn" data-action="pl-first" aria-label="First step" title="First step (Home)">⏮</button>
        <button class="pl-btn" data-action="pl-prev" aria-label="Previous step" title="Previous step (←)">◀</button>
        <button class="pl-btn pl-play" data-action="pl-play" title="Play / pause (Space)">▶ Play</button>
        <button class="pl-btn" data-action="pl-next" aria-label="Next step" title="Next step (→)">▶</button>
        <button class="pl-btn" data-action="pl-last" aria-label="Last step" title="Last step (End)">⏭</button>
        <input type="range" class="pl-range" min="0" max="${n - 1}" value="${state.step[i] || 0}" aria-label="Step">
        <span class="pl-count"></span>
        ${fs ? "" : `<button class="pl-btn pl-full" data-action="pl-full" title="Full screen: see the whole dry run (F)">⛶ Full screen</button>`}
        <select class="pl-speed" aria-label="Playback speed">${[0.5, 1, 2]
.map((v) => `<option value="${v}"${state.speed === v ? " selected" : ""}>${v}×</option>`)
.join("")}</select>
      </div>
      <div class="pl-result"></div>
    </div>`;
}
function dryHtml(a, i) {
if (!a.deep) return deepStatus(i, "the animated dry run");
if (!a.deep.dryRun) return `<p class="muted">No dry run came back for this approach. Try Regenerate.</p>`;
return playerHtml(i, a.deep, a);
}
function codeViewHtml(a, i) {
const d = a.deep;
if (!d) return deepStatus(i, "the C++ code");
if (!d.solution) return `<p class="muted">No code came back for this approach. Try Regenerate.</p>`;
const mode = state.codeMode[i] || "solution";
const tab = (id, label) =>
`<button role="tab" class="${mode === id ? "active" : ""}" aria-selected="${mode === id}" data-action="code-mode" data-index="${i}" data-mode="${id}">${label}</button>`;
return `<div class="code-head">
        <div class="seg-mini" role="tablist" aria-label="Code version">${tab("solution", `${SITE.name} solution`)}${tab("full", "Full program")}</div>
        <button class="mini" data-action="copy-code" data-index="${i}">Copy code</button>
      </div>
      <p class="muted small">${
mode === "full"
? "Complete program with headers and a <code>main()</code> that runs the examples. Compile with <code>g++ -std=c++17 sol.cpp -o sol</code>."
: `Paste into ${SITE.editorName} with C++ selected.`
}</p>
      <div class="codebox">${codeBlock(codeFor(d, mode), "cpp")}</div>`;
}
const VIEWS = [
{ id: "idea", label: "Explanation" },
{ id: "pseudo", label: "Pseudocode" },
{ id: "dry", label: "Dry run" },
{ id: "code", label: "C++ code" },
];
function approachCardHtml(a, i) {
const open = state.expanded.has(i);
const level = levelClass(a.level);
const view = state.view[i] || "idea";
let body = "";
if (open) {
const content = { idea: explanationHtml, pseudo: pseudoHtml, dry: dryHtml, code: codeViewHtml }[view](a, i, level);
body = `<div class="approach-body" id="approach-${i}">
        ${a.aha ? `<p class="aha"><span class="aha-label">${i === 0 ? "Where you start" : "How you get here"}</span>${fmt(a.aha)}</p>` : ""}
        <div class="subtabs" role="tablist" aria-label="${escapeHtml(a.level)} views">
          ${VIEWS.map(
(v) => `<button role="tab" class="subtab${v.id === view ? " active" : ""}" aria-selected="${v.id === view}"
              data-action="view" data-index="${i}" data-view="${v.id}">${v.label}</button>`
).join("")}
        </div>
        ${content}
      </div>`;
}
return `<li class="approach ${level}${open ? " open" : ""}">
      <button class="approach-head" data-action="expand" data-index="${i}" aria-expanded="${open}" aria-controls="approach-${i}">
        <span class="level">${escapeHtml(a.level)}</span>
        <span class="approach-name">${escapeHtml(a.name || a.level)}</span>
        <span class="approach-cx">${escapeHtml(a.time)} time · ${escapeHtml(a.space)} space${
state.loading[`deep${i}`] ? ' <span class="dot" aria-label="loading"></span>' : ""
}</span>
        <span class="chev" aria-hidden="true">${open ? "−" : "+"}</span>
      </button>
      ${body}
    </li>`;
}
const SHAPE_KINDS = { tree: "binary tree", list: "linked list", graph: "graph", digraph: "directed graph" };
const textWidth = (v) => String(v).length * 7.4;
const nodeRadius = (labels) => Math.min(24, Math.max(15, Math.max(0, ...labels.map(textWidth)) / 2 + 7));
const r1 = (n) => Math.round(n * 10) / 10;
const shapeCache = new Map();
function arrowHead(x1, y1, x2, y2) {
const a = Math.atan2(y2 - y1, x2 - x1);
const corner = (t) => `${r1(x2 - 8 * Math.cos(a + t))},${r1(y2 - 8 * Math.sin(a + t))}`;
return `<polygon class="sah" points="${r1(x2)},${r1(y2)} ${corner(0.42)} ${corner(-0.42)}"/>`;
}
function nodeSvg(id, x, y, r, val, rect) {
const body = rect
? `<rect x="${r1(x - rect / 2)}" y="${r1(y - r)}" width="${r1(rect)}" height="${r1(r * 2)}" rx="7"/>`
: `<circle cx="${r1(x)}" cy="${r1(y)}" r="${r1(r)}"/>`;
return `<g class="sn" data-id="${escapeHtml(id)}">${body}<text x="${r1(x)}" y="${r1(y)}">${escapeHtml(val)}</text></g>`;
}
function treeShape(t) {
const nodes = [];
const at = new Map();
const values = t.values;
if (values.length && values[0] != null) {
const top = { id: 0, val: values[0], depth: 0, left: -1, right: -1, parent: -1 };
nodes.push(top);
at.set(0, top);
const queue = [top];
let k = 1;
while (queue.length && k < values.length) {
const p = queue.shift();
for (const side of ["left", "right"]) {
if (k >= values.length) break;
if (values[k] != null) {
const c = { id: k, val: values[k], depth: p.depth + 1, left: -1, right: -1, parent: p.id };
p[side] = k;
nodes.push(c);
at.set(k, c);
queue.push(c);
}
k++;
}
}
}
const r = nodeRadius(nodes.map((n) => n.val));
const gap = r * 2 + 10;
const level = r * 2 + 34;
let rank = 0;
const place = (id) => {
const n = at.get(id);
if (!n) return;
place(n.left);
n.x = 10 + r + rank++ * gap;
place(n.right);
};
place(0);
let depth = 0;
for (const n of nodes) {
n.y = 10 + r + n.depth * level;
depth = Math.max(depth, n.depth);
}
const lines = nodes
.filter((n) => n.parent >= 0)
.map((n) => {
const p = at.get(n.parent);
return `<line class="se" x1="${r1(p.x)}" y1="${r1(p.y)}" x2="${r1(n.x)}" y2="${r1(n.y)}"/>`;
})
.join("");
return {
kind: "tree",
width: 20 + r * 2 + Math.max(0, rank - 1) * gap,
height: 20 + r * 2 + depth * level,
r,
pos: new Map(nodes.map((n) => [String(n.id), { x: n.x, y: n.y }])),
svg: lines + nodes.map((n) => nodeSvg(n.id, n.x, n.y, r, n.val)).join(""),
empty: !nodes.length,
};
}
function listShape(l) {
const n = l.values.length;
const w = Math.min(96, Math.max(42, Math.max(0, ...l.values.map(textWidth)) + 22));
const h = 32;
const gap = 44;
const far = l.next.some((j, i) => j !== -1 && Math.abs(j - i) !== 1);
const top = far ? 50 : 8;
const xs = l.values.map((_, i) => 10 + i * (w + gap));
const cy = top + h / 2;
let links = "";
l.next.forEach((j, i) => {
const x = xs[i];
if (j === -1) {
const busy = l.next[i + 1] === i;
links += `<text class="snull" x="${r1(x + w + (busy ? 10 : gap / 2))}" y="${r1(busy ? cy - 13 : cy)}">∅</text>`;
} else if (j === i + 1 || j === i - 1) {
const fwd = j > i;
const x1 = fwd ? x + w : x;
const x2 = fwd ? xs[j] - 1 : xs[j] + w + 1;
links += `<line class="se" x1="${r1(x1)}" y1="${r1(cy)}" x2="${r1(x2)}" y2="${r1(cy)}"/>${arrowHead(x1, cy, x2, cy)}`;
} else {
const sx = x + w / 2;
const ex = xs[j] + w / 2 + (j > i ? -6 : 6);
const cx = (sx + ex) / 2;
const cyc = top - Math.min(46, 18 + Math.abs(j - i) * 9);
links += `<path class="se" d="M${r1(sx)},${top} Q${r1(cx)},${r1(cyc)} ${r1(ex)},${top - 1}"/>${arrowHead(cx, cyc, ex, top - 1)}`;
}
});
return {
kind: "list",
width: 10 + n * (w + gap),
height: top + h + 8,
r: h / 2,
pos: new Map(l.values.map((_, i) => [String(i), { x: xs[i] + w / 2, y: cy }])),
svg: links + l.values.map((v, i) => nodeSvg(i, xs[i] + w / 2, cy, h / 2, v, w)).join(""),
empty: !n,
};
}
function graphShape(g) {
const n = g.nodes.length;
const index = new Map(g.nodes.map((v, i) => [v, i]));
const r = nodeRadius(g.nodes);
const size = Math.max(150, Math.min(440, 70 + n * 30));
const P = g.nodes.map((_, i) => {
const a = (2 * Math.PI * i) / Math.max(1, n) - Math.PI / 2;
const R = n === 1 ? 0 : size / 2 - r - 8;
return { x: size / 2 + R * Math.cos(a), y: size / 2 + R * Math.sin(a) };
});
const links = g.edges.map(([a, b]) => [index.get(a), index.get(b)]).filter(([a, b]) => a !== b);
if (n > 3 && links.length) {
const k = (size / Math.sqrt(n)) * 0.75;
let temp = size / 10;
for (let it = 0; it < 140; it++) {
const d = P.map(() => ({ x: 0, y: 0 }));
for (let i = 0; i < n; i++) {
for (let j = i + 1; j < n; j++) {
const dx = P[i].x - P[j].x;
const dy = P[i].y - P[j].y;
const dist = Math.max(0.5, Math.hypot(dx, dy));
const f = (k * k) / dist / dist;
d[i].x += dx * f;
d[i].y += dy * f;
d[j].x -= dx * f;
d[j].y -= dy * f;
}
}
for (const [a, b] of links) {
const dx = P[a].x - P[b].x;
const dy = P[a].y - P[b].y;
const f = Math.hypot(dx, dy) / k;
d[a].x -= dx * f;
d[a].y -= dy * f;
d[b].x += dx * f;
d[b].y += dy * f;
}
for (let i = 0; i < n; i++) {
const len = Math.max(0.01, Math.hypot(d[i].x, d[i].y));
const step = Math.min(len, temp);
P[i].x = Math.min(size - r - 6, Math.max(r + 6, P[i].x + (d[i].x / len) * step));
P[i].y = Math.min(size - r - 6, Math.max(r + 6, P[i].y + (d[i].y / len) * step));
}
temp *= 0.96;
}
}
const pad = r + 10;
const minX = Math.min(...P.map((q) => q.x));
const minY = Math.min(...P.map((q) => q.y));
for (const q of P) {
q.x += pad - minX;
q.y += pad - minY;
}
const width = Math.max(...P.map((q) => q.x)) + pad;
const height = Math.max(...P.map((q) => q.y)) + pad;
const seen = new Set();
let edges = "";
for (const [a, b, w] of g.edges) {
const i = index.get(a);
const j = index.get(b);
if (i === j) continue;
const key = g.directed ? `${a}|${b}` : [a, b].sort().join("|");
if (seen.has(key)) continue;
seen.add(key);
const p = P[i];
const q = P[j];
const len = Math.hypot(q.x - p.x, q.y - p.y) || 1;
const ux = (q.x - p.x) / len;
const uy = (q.y - p.y) / len;
const twin = g.directed && g.edges.some(([x, y]) => x === b && y === a) ? 5 : 0;
const ox = -uy * twin;
const oy = ux * twin;
const x1 = p.x + ux * r + ox;
const y1 = p.y + uy * r + oy;
const x2 = q.x - ux * (r + 1) + ox;
const y2 = q.y - uy * (r + 1) + oy;
edges += `<g class="seg" data-e="${escapeHtml(`${a}|${b}`)}"><line class="se" x1="${r1(x1)}" y1="${r1(y1)}" x2="${r1(x2)}" y2="${r1(y2)}"/>${
g.directed ? arrowHead(x1, y1, x2, y2) : ""
}${w ? `<text class="sw" x="${r1((x1 + x2) / 2 + ox)}" y="${r1((y1 + y2) / 2 + oy)}">${escapeHtml(w)}</text>` : ""}</g>`;
}
return {
kind: g.directed ? "digraph" : "graph",
width,
height,
r,
pos: new Map(g.nodes.map((v, i) => [v, P[i]])),
svg: edges + g.nodes.map((v, i) => nodeSvg(v, P[i].x, P[i].y, r, v)).join(""),
empty: !n,
};
}
function drawShape(kind, data) {
const sig = kind + JSON.stringify(kind === "tree" ? data.values : kind === "list" ? [data.values, data.next] : [data.nodes, data.edges, data.directed]);
let shape = shapeCache.get(sig);
if (!shape) {
shape = kind === "tree" ? treeShape(data) : kind === "list" ? listShape(data) : graphShape(data);
shape.sig = sig;
if (shapeCache.size > 80) shapeCache.clear();
shapeCache.set(sig, shape);
}
return shape;
}
const shapeSvgHtml = (shape, label) =>
`<svg class="shape-svg" width="${r1(shape.width)}" height="${r1(shape.height)}" viewBox="0 0 ${r1(shape.width)} ${r1(shape.height)}" role="img" aria-label="${escapeHtml(label)}">${shape.svg}</svg>`;
function shapeEntries(s) {
const out = [];
for (const [name, data] of Object.entries(s?.trees || {})) out.push({ key: `tree:${name}`, kind: "tree", name, data });
for (const [name, data] of Object.entries(s?.lists || {})) out.push({ key: `list:${name}`, kind: "list", name, data });
for (const [name, data] of Object.entries(s?.graphs || {})) out.push({ key: `graph:${name}`, kind: "graph", name, data });
return out;
}
function updateShapes(el, s, prev, animate) {
const wrap = el.querySelector(".pl-shapes");
if (!wrap) return;
const items = shapeEntries(s);
[...wrap.children].forEach((b) => !items.some((it) => it.key === b.dataset.key) && b.remove());
const before = new Map(shapeEntries(prev).map((it) => [it.key, it.data]));
for (const it of items) {
const shape = drawShape(it.kind, it.data);
let block = [...wrap.children].find((b) => b.dataset.key === it.key);
if (!block) {
block = document.createElement("div");
block.className = "shape";
block.dataset.key = it.key;
wrap.appendChild(block);
}
const label = SHAPE_KINDS[shape.kind];
if (block.dataset.sig !== shape.sig) {
block.dataset.sig = shape.sig;
block.innerHTML = `<div class="arr-name">${escapeHtml(it.name)} <span class="shape-kind">${label}</span></div>
          <div class="shape-scroll">${
shape.empty
? '<span class="muted small">empty</span>'
: `<div class="shape-stage" style="width:${r1(shape.width)}px">${shapeSvgHtml(shape, `${it.name}, ${label}`)}<div class="sptrs"></div></div>`
}</div>
          <div class="shape-note"></div>`;
}
shapeState(block, it, shape, before.get(it.key), animate);
}
}
function shapeState(block, it, shape, was, animate) {
const d = it.data;
const hl = new Set((d.highlight || []).map(String));
const vis = new Set((d.visited || []).map(String));
const wasHl = new Set((was?.highlight || []).map(String));
block.querySelectorAll(".sn").forEach((g) => {
const id = g.dataset.id;
g.classList.toggle("hl", hl.has(id));
g.classList.toggle("vis", vis.has(id) && !hl.has(id));
if (animate && was && hl.has(id) && !wasHl.has(id)) flash(g, "pulse");
});
if (it.kind === "graph") {
const on = new Set((d.activeEdges || []).flatMap(([a, b]) => (d.directed ? [`${a}|${b}`] : [`${a}|${b}`, `${b}|${a}`])));
block.querySelectorAll(".seg").forEach((g) => g.classList.toggle("on", on.has(g.dataset.e)));
}
const nulls = [];
const layer = block.querySelector(".sptrs");
const rows = {};
const seen = new Set();
let bottom = shape.height;
for (const [label, target] of Object.entries(d.pointers || {})) {
const p = shape.pos.get(String(target));
if (!p || !layer) {
nulls.push(label);
continue;
}
const row = (rows[String(target)] = (rows[String(target)] ?? -1) + 1);
const top = p.y + shape.r + 3 + row * 19;
bottom = Math.max(bottom, top + 20);
seen.add(label);
let tag = [...layer.children].find((x) => x.dataset.label === label);
if (!tag) {
tag = document.createElement("span");
tag.className = "sptr";
tag.dataset.label = label;
tag.textContent = label;
layer.appendChild(tag);
}
tag.style.left = `${r1(p.x)}px`;
tag.style.top = `${r1(top)}px`;
}
if (layer) {
[...layer.children].forEach((x) => !seen.has(x.dataset.label) && x.remove());
layer.parentElement.style.height = `${r1(bottom)}px`;
}
const note = block.querySelector(".shape-note");
if (note) note.textContent = nulls.map((l) => `${l} = null`).join(" · ");
}
function looseList(text) {
const t = String(text || "").trim();
try {
return JSON.parse(t.replace(/'/g, '"').replace(/\b(N|None|nil)\b/g, "null"));
} catch (_) {
const parts = t.replace(/^\[|\]$/g, "").split(/[\s,]+/).filter(Boolean);
return parts.length ? parts.map((x) => (/^(null|n|none|nil|#)$/i.test(x) ? null : x)) : null;
}
}
function argShape(a) {
let kind = String(a.kind || "").toLowerCase();
if (!kind) {
const n = String(a.name || "");
kind = /^(root\d*|tree\d*|t[12])$/i.test(n)
? "tree"
: /^(head\d*|head[AB]|l[12]|list[12])$/i.test(n)
? "linked list"
: /^edges$/i.test(n)
? "edges"
: /^(graph|adj|adjList|adjacency)$/i.test(n)
? "adjacency"
: "";
}
if (!kind) return null;
const v = looseList(a.value);
if (!Array.isArray(v) || !v.length) return null;
const flat = !v.some(Array.isArray);
if (kind.includes("tree")) {
if (!flat || v.filter((x) => x != null).length > 63) return null;
return { kind: "tree", data: { values: v.map((x) => (x == null ? null : String(x))), pointers: {}, highlight: [], visited: [] } };
}
if (kind.includes("adjac")) {
if (!v.every(Array.isArray) || v.length > 25) return null;
const edges = [];
v.forEach((nb, i) => nb.forEach((j) => edges.push([String(i), String(j), ""])));
const directed = !edges.every(([x, y]) => edges.some(([p, q]) => p === y && q === x));
return { kind: "graph", data: { nodes: v.map((_, i) => String(i)), edges, directed, pointers: {}, highlight: [], visited: [], activeEdges: [] } };
}
if (kind.includes("edge")) {
if (!v.every((e) => Array.isArray(e) && e.length >= 2) || v.length > 60) return null;
const nodes = [...new Set(v.flatMap((e) => [String(e[0]), String(e[1])]))].sort((x, y) => (isNaN(x) || isNaN(y) ? x.localeCompare(y) : x - y));
if (nodes.length > 25) return null;
const edges = v.map((e) => [String(e[0]), String(e[1]), e.length > 2 ? String(e[2]) : ""]);
const directed = /direct/.test(kind) && !/undirect/.test(kind);
return { kind: "graph", data: { nodes, edges, directed, pointers: {}, highlight: [], visited: [], activeEdges: [] } };
}
if (/link|list/.test(kind)) {
if (!flat || v.length > 25) return null;
return { kind: "list", data: { values: v.map(String), next: v.map((_, i) => (i + 1 < v.length ? i + 1 : -1)), pointers: {}, highlight: [] } };
}
return null;
}
function caseVizHtml(c) {
return c.args
.map((a) => {
const sh = argShape(a);
if (!sh) return "";
const shape = drawShape(sh.kind, sh.data);
if (shape.empty) return "";
const label = `${a.name || "input"} · ${SHAPE_KINDS[shape.kind]}`;
return `<figure class="case-viz"><figcaption>${escapeHtml(label)}</figcaption><div class="shape-scroll">${shapeSvgHtml(shape, label)}</div></figure>`;
})
.join("");
}
let playTimer = null;
let playingIndex = -1;
const dryOf = (i) => state.approach?.approaches[i]?.deep?.dryRun || null;
function stopPlayer() {
clearInterval(playTimer);
playTimer = null;
const was = playingIndex;
playingIndex = -1;
if (was >= 0) updatePlayer(was, false);
}
function setStep(i, k, animate = true) {
const dr = dryOf(i);
if (!dr) return;
state.step[i] = Math.max(0, Math.min(dr.steps.length - 1, k));
updatePlayer(i, animate);
}
function togglePlay(i) {
if (playingIndex === i) return stopPlayer();
stopPlayer();
const dr = dryOf(i);
if (!dr) return;
if ((state.step[i] || 0) >= dr.steps.length - 1) setStep(i, 0, false);
playingIndex = i;
playTimer = setInterval(() => {
const k = (state.step[i] || 0) + 1;
if (k >= dr.steps.length) return stopPlayer();
setStep(i, k);
if (k >= dr.steps.length - 1) stopPlayer();
}, 1700 / state.speed);
updatePlayer(i, false);
}
function flash(el, cls) {
el.classList.remove(cls);
void el.offsetWidth;
el.classList.add(cls);
}
function cellWidth(dr, name) {
let max = 1;
for (const st of dr.steps) for (const v of st.arrays[name]?.values || []) max = Math.max(max, String(v).length);
return Math.max(34, Math.min(96, max * 8 + 20));
}
function gridHtml(name, a, pa, animate) {
const ptrAt = {};
for (const [label, p] of Object.entries(a.pointers)) if (Array.isArray(p)) (ptrAt[p.join(",")] ||= []).push(label);
const hl = new Set(a.highlight.filter(Array.isArray).map((p) => p.join(",")));
return `<div class="arr-name">${escapeHtml(name)}</div>
      <div class="grid-wrap"><table class="grid"><tbody>${a.values
.map(
(row, r) =>
`<tr><th>${r}</th>${(Array.isArray(row) ? row : [row])
.map((v, c) => {
const key = `${r},${c}`;
const old = pa && Array.isArray(pa.values[r]) ? pa.values[r][c] : undefined;
const cls = [hl.has(key) ? "hl" : "", animate && pa && old !== v ? "changed" : "", ptrAt[key] ? "ptr-cell" : ""].join(" ");
return `<td class="${cls}">${escapeHtml(v)}${ptrAt[key] ? `<span class="gptr">${escapeHtml(ptrAt[key].join(","))}</span>` : ""}</td>`;
})
.join("")}</tr>`
)
.join("")}</tbody></table></div>`;
}
function updateArrays(el, dr, s, prev, animate) {
const wrap = el.querySelector(".pl-arrays");
const names = Object.keys(s.arrays);
[...wrap.children].forEach((b) => !names.includes(b.dataset.name) && b.remove());
for (const name of names) {
const a = s.arrays[name];
const pa = prev?.arrays[name];
let block = [...wrap.children].find((b) => b.dataset.name === name);
const is2D = a.values.some(Array.isArray);
if (!block) {
block = document.createElement("div");
block.className = "arr";
block.dataset.name = name;
wrap.appendChild(block);
}
if (is2D) {
block.dataset.kind = "2d";
block.innerHTML = gridHtml(name, a, pa, animate);
continue;
}
if (block.dataset.kind !== "1d" || Number(block.dataset.len) !== a.values.length) {
block.dataset.kind = "1d";
block.dataset.len = a.values.length;
block.style.setProperty("--cell", `${cellWidth(dr, name)}px`);
block.innerHTML = `<div class="arr-name">${escapeHtml(name)}</div>
          <div class="arr-scroll"><div class="arr-track">
            <div class="cells">${a.values.map((_, j) => `<div class="cellbox"><span class="v"></span><span class="idx">${j}</span></div>`).join("")}</div>
            <div class="ptrs"></div>
          </div></div>`;
}
const hl = new Set(a.highlight.filter(Number.isInteger));
block.querySelectorAll(".cellbox").forEach((c, j) => {
const v = a.values[j];
const vEl = c.querySelector(".v");
if (vEl.textContent !== String(v)) vEl.textContent = v;
c.classList.toggle("hl", hl.has(j));
if (animate && pa && pa.values[j] !== v) flash(c, "changed");
});
const layer = block.querySelector(".ptrs");
const rows = {};
const seen = new Set();
let maxRow = 0;
for (const [label, p] of Object.entries(a.pointers)) {
if (!Number.isInteger(p)) continue;
const pos = Math.max(-1, Math.min(a.values.length, p));
const row = (rows[pos] = (rows[pos] ?? -1) + 1);
maxRow = Math.max(maxRow, row);
seen.add(label);
let ptr = [...layer.children].find((x) => x.dataset.label === label);
const left = `calc(var(--cell) * ${pos} + var(--cell) / 2)`;
if (!ptr) {
ptr = document.createElement("div");
ptr.className = "ptr";
ptr.dataset.label = label;
ptr.innerHTML = `<span class="ptr-arrow">▲</span><span class="ptr-label">${escapeHtml(label)}</span>`;
ptr.style.left = left;
ptr.style.top = `${row * 30}px`;
layer.appendChild(ptr);
} else {
ptr.style.left = left;
ptr.style.top = `${row * 30}px`;
}
ptr.classList.toggle("out", p < 0 || p >= a.values.length);
}
[...layer.children].forEach((x) => !seen.has(x.dataset.label) && x.remove());
layer.style.height = seen.size ? `${(maxRow + 1) * 30}px` : "0px";
}
}
function updatePlayer(i, animate) {
const el = root.querySelector(`.player[data-index="${i}"]`);
const dr = dryOf(i);
if (!el || !dr) {
if (playingIndex === i && !el) stopPlayer();
return;
}
const n = dr.steps.length;
const k = Math.min(state.step[i] || 0, n - 1);
const s = dr.steps[k];
const prev = k > 0 ? dr.steps[k - 1] : null;
el.classList.toggle("no-anim", !animate);
updateShapes(el, s, prev, animate);
updateArrays(el, dr, s, prev, animate);
el.querySelector(".pl-structs").innerHTML = Object.entries(s.structures)
.map(([name, st]) => {
const before = new Set(prev?.structures[name]?.items || []);
const tag = st.type === "stack" ? "top →" : st.type === "queue" ? "← front" : "";
const items = st.items.length
? st.items.map((it) => `<span class="item${animate && prev && !before.has(it) ? " new" : ""}">${fmt(it)}</span>`).join("")
: `<span class="muted small">empty</span>`;
return `<div class="struct ${escapeHtml(st.type)}">
          <div class="struct-head"><span class="struct-name">${escapeHtml(name)}</span><span class="struct-type">${escapeHtml(st.type)}${tag ? ` · ${tag}` : ""}</span></div>
          <div class="items">${items}</div>
        </div>`;
})
.join("");
el.querySelector(".pl-vars").innerHTML = Object.entries(s.vars)
.map(([name, v]) => {
const changed = animate && prev && prev.vars[name] !== v;
return `<span class="var${changed ? " changed" : ""}"><span class="var-name">${escapeHtml(name)}</span><span class="var-val">${escapeHtml(v)}</span></span>`;
})
.join("");
el.querySelector(".pl-explain").innerHTML = `<span class="pl-stepno">Step ${k + 1}${s.line ? ` · line ${s.line}` : ""}</span>${fmt(s.explain)}`;
el.querySelector(".pl-count").textContent = `${k + 1} / ${n}`;
el.querySelector(".pl-range").value = k;
el.querySelector(".pl-result").innerHTML =
k === n - 1 && dr.result ? `<span class="io-label">Result</span> ${fmt(dr.result)}` : "";
const box = el.querySelector(".pl-code");
box.querySelectorAll(".cl.cur").forEach((c) => c.classList.remove("cur"));
const cur = s.line ? box.querySelector(`.cl[data-line="${s.line}"]`) : null;
if (cur) {
cur.classList.add("cur");
box.scrollTop = cur.offsetTop - box.clientHeight / 2 + cur.offsetHeight / 2;
}
const playing = playingIndex === i;
const playBtn = el.querySelector(".pl-play");
playBtn.textContent = playing ? "❚❚ Pause" : k === n - 1 ? "↺ Replay" : "▶ Play";
playBtn.setAttribute("aria-pressed", String(playing));
el.querySelector('[data-action="pl-first"]').disabled = k === 0;
el.querySelector('[data-action="pl-prev"]').disabled = k === 0;
el.querySelector('[data-action="pl-next"]').disabled = k === n - 1;
el.querySelector('[data-action="pl-last"]').disabled = k === n - 1;
}
function thinkingHtml(items) {
const allOpen = items.every((_, i) => state.thinkOpen.has(i));
return `<section class="block">
      <div class="block-head">
        <h3>Think it through</h3>
        <button class="mini" data-action="think-all">${allOpen ? "Hide answers" : "Reveal all"}</button>
      </div>
      <p class="muted small">Answer each question yourself before you reveal it.</p>
      <ol class="qa">
        ${items
.map((t, i) => {
const open = state.thinkOpen.has(i);
return `<li class="${open ? "open" : ""}">
              <button class="q" data-action="think" data-index="${i}" aria-expanded="${open}">
                <span class="qn">Q${i + 1}</span><span>${fmt(t.q)}</span>
              </button>
              ${open ? `<p class="a">${fmt(t.a)}</p>` : ""}
            </li>`;
})
.join("")}
      </ol>
    </section>`;
}
function signalHtml(s) {
const [clue, ...rest] = s.split(/\s*(?:→|->)\s*/);
return rest.length
? `<li><span class="clue">${fmt(clue)}</span><span class="arrow" aria-hidden="true">→</span><span>${fmt(rest.join(" → "))}</span></li>`
: `<li>${fmt(s)}</li>`;
}
function approachTabHtml() {
if (!state.approach) {
const hintNudge =
state.revealed < TOTAL
? `<p class="warn">This explains full solutions, with code. If you're still working on the problem, the Hints tab teaches more.</p>`
: "";
return `<div class="empty">
        <p class="intro">Learn how to think about this problem: the clues that point to the pattern, what the constraints demand, an expert's train of thought, then brute force → better → optimal, each with a line-by-line complexity breakdown, detailed pseudocode, an animated dry run and complete C++ code.</p>
        ${hintNudge}
        <button class="primary" data-action="fetch" data-kind="approach" ${busy(state.loading.approach)}>
          ${state.loading.approach ? "Writing the overview…" : "Explain the approach"}
        </button>
        ${progressHtml("approach")}
      </div>`;
}
const a = state.approach;
const cmp = `<div class="table-wrap"><table class="cmp">
        <thead><tr><th>Approach</th><th>Time</th><th>Space</th></tr></thead>
        <tbody>${a.approaches
.map(
(x) => `<tr class="${levelClass(x.level)}"><td><span class="lvl-dot"></span>${escapeHtml(x.name || x.level)}</td>
              <td><code>${escapeHtml(x.time)}</code></td><td><code>${escapeHtml(x.space)}</code></td></tr>`
)
.join("")}</tbody>
      </table></div>`;
return `${
a.oneLiner || a.pattern
? `<div class="summary-card">
            ${a.oneLiner ? `<p class="oneliner">${fmt(a.oneLiner)}</p>` : ""}
            ${a.pattern ? `<p class="pattern"><span class="chip">${escapeHtml(a.pattern)}</span></p>` : ""}
          </div>`
: ""
}
      ${a.signals.length ? `<section class="block"><h3>Clues in the problem</h3><ul class="signals">${a.signals.map(signalHtml).join("")}</ul></section>` : ""}
      ${a.constraints ? `<section class="block"><h3>What the constraints tell you</h3><p>${fmt(a.constraints)}</p></section>` : ""}
      ${a.thinking.length ? thinkingHtml(a.thinking) : a.intuition.length ? `<section class="block"><h3>How to think about it</h3>${a.intuition.map((p) => `<p>${fmt(p)}</p>`).join("")}</section>` : ""}
      <section class="block">
        <h3>Approaches</h3>
        ${cmp}
        <ol class="approaches">${a.approaches.map(approachCardHtml).join("")}</ol>
      </section>
      ${a.mistakes.length ? `<section class="block"><h3>Common mistakes</h3>${list(a.mistakes)}</section>` : ""}
      ${a.edgeCases.length ? `<section class="block"><h3>Edge cases to check</h3>${list(a.edgeCases)}</section>` : ""}
      ${
a.related.length
? `<section class="block"><h3>Practice next</h3><ul class="related">${a.related
.map(
(r) => `<li><a href="https://leetcode.com/problems/${escapeHtml(r.slug)}/" target="_blank" rel="noopener">${escapeHtml(r.title)}</a>
                  ${r.why ? `<span class="muted"> · ${fmt(r.why)}</span>` : ""}</li>`
)
.join("")}</ul></section>`
: ""
}
      ${a.takeaways.length ? `<section class="block"><h3>Takeaways</h3>${list(a.takeaways)}</section>` : ""}`;
}
function reviewResultHtml(r) {
const v = VERDICT_INFO[r.verdict] || VERDICT_INFO.partially_correct;
const stale = state.reviewFor != null && state.code && state.code !== state.reviewFor;
return `<div class="review-result">
      ${stale ? `<p class="warn">Your code changed since this review. Run it again to check the new version.</p>` : ""}
      <div class="verdict ${v.tone}">
        <span class="badge">${v.label}</span>
        <p>${fmt(r.summary)}</p>
      </div>
      ${r.yourIdea ? `<section class="block"><h3>What your code is doing</h3><p>${fmt(r.yourIdea)}</p></section>` : ""}
      ${
r.gaps.length
? `<section class="block"><h3>Where your intuition goes wrong</h3><ol class="findings">${r.gaps
.map(
(g) => `<li class="finding gap">
                  <div class="finding-head"><strong>${fmt(g.title || "Reasoning gap")}</strong>${g.lines ? `<span class="lines">line ${escapeHtml(g.lines)}</span>` : ""}</div>
                  <p>${fmt(g.explanation)}</p></li>`
)
.join("")}</ol></section>`
: ""
}
      ${
r.counterexample
? `<section class="block"><h3>An input that breaks it</h3><div class="case">
              <div class="io"><span class="io-label">Input</span><div class="mono">${escapeHtml(r.counterexample.input)}</div></div>
              <div class="io"><span class="io-label">Expected</span><div class="mono">${escapeHtml(r.counterexample.expected)}</div></div>
              <div class="io"><span class="io-label">Yours</span><div class="mono bad-ink">${escapeHtml(r.counterexample.yours)}</div></div>
              ${r.counterexample.why ? `<p class="note">${fmt(r.counterexample.why)}</p>` : ""}
            </div></section>`
: ""
}
      ${
r.bugs.length
? `<section class="block"><h3>Bugs in the code</h3><ol class="findings">${r.bugs
.map(
(b) => `<li class="finding bug">
                  <div class="finding-head"><strong>${fmt(b.issue)}</strong>${b.lines ? `<span class="lines">line ${escapeHtml(b.lines)}</span>` : ""}</div>
                  ${b.fix ? `<p><span class="muted">Fix:</span> ${fmt(b.fix)}</p>` : ""}</li>`
)
.join("")}</ol></section>`
: ""
}
      ${
r.complexity.time || r.complexity.verdict
? `<section class="block"><h3>Complexity</h3>
              <div class="cx">
                ${r.complexity.time ? `<div><span class="cx-label">Time</span><code>${escapeHtml(r.complexity.time)}</code></div>` : ""}
                ${r.complexity.space ? `<div><span class="cx-label">Space</span><code>${escapeHtml(r.complexity.space)}</code></div>` : ""}
              </div>
              ${r.complexity.verdict ? `<p>${fmt(r.complexity.verdict)}</p>` : ""}</section>`
: ""
}
      ${r.nudge ? `<section class="block"><h3>Think about this</h3><p class="nudge">${fmt(r.nudge)}</p></section>` : ""}
      ${r.strengths.length ? `<section class="block"><h3>What you got right</h3>${list(r.strengths, "ul", "bullets good-list")}</section>` : ""}
      ${
r.correctIdea
? state.showCorrect
? `<section class="block"><h3>The correct intuition</h3><p>${fmt(r.correctIdea)}</p></section>`
: `<button class="secondary wide-btn" data-action="show-correct">Show the correct intuition</button>`
: ""
}
    </div>`;
}
function planResultHtml(r) {
const v = PLAN_VERDICTS[r.verdict] || PLAN_VERDICTS.incomplete;
const stale = state.planCheckFor != null && state.planText.trim() && state.planText.trim() !== state.planCheckFor;
return `<div class="review-result plan-result">
      ${stale ? `<p class="warn">You've changed your plan since this check. Check it again.</p>` : ""}
      <div class="verdict ${v.tone}">
        <span class="badge">${v.label}</span>
        <p>${fmt(r.summary)}</p>
      </div>
      ${r.restated ? `<section class="block"><h3>Your plan, as I understand it</h3><p>${fmt(r.restated)}</p></section>` : ""}
      ${r.strengths.length ? `<section class="block"><h3>What's right</h3>${list(r.strengths, "ul", "bullets good-list")}</section>` : ""}
      ${
r.issues.length
? `<section class="block"><h3>Where the plan goes wrong</h3><ol class="findings">${r.issues
.map((g) => `<li class="finding gap"><div class="finding-head"><strong>${fmt(g.title || "Problem")}</strong></div><p>${fmt(g.explanation)}</p></li>`)
.join("")}</ol></section>`
: ""
}
      ${
r.counterexample
? `<section class="block"><h3>An input that breaks it</h3><div class="case">
              <div class="io"><span class="io-label">Input</span><div class="mono">${escapeHtml(r.counterexample.input)}</div></div>
              <div class="io"><span class="io-label">Expected</span><div class="mono">${escapeHtml(r.counterexample.expected)}</div></div>
              <div class="io"><span class="io-label">Plan gives</span><div class="mono bad-ink">${escapeHtml(r.counterexample.planGives)}</div></div>
              ${r.counterexample.why ? `<p class="note">${fmt(r.counterexample.why)}</p>` : ""}
            </div></section>`
: ""
}
      ${
r.complexity.time || r.complexity.verdict
? `<section class="block"><h3>Complexity</h3>
              <div class="cx">
                ${r.complexity.time ? `<div><span class="cx-label">Time</span><code>${escapeHtml(r.complexity.time)}</code></div>` : ""}
                ${r.complexity.space ? `<div><span class="cx-label">Space</span><code>${escapeHtml(r.complexity.space)}</code></div>` : ""}
              </div>
              ${r.complexity.verdict ? `<p>${fmt(r.complexity.verdict)}</p>` : ""}</section>`
: ""
}
      ${r.remember.length ? `<section class="block"><h3>Remember while coding</h3>${list(r.remember)}</section>` : ""}
      ${r.nudge ? `<section class="block"><h3>Think about this</h3><p class="nudge">${fmt(r.nudge)}</p></section>` : ""}
    </div>`;
}
function planModeHtml() {
const err = state.error.plan;
return `<p class="intro small">Before you code, describe your approach in a few sentences: the idea, the data structure, the steps, and the complexity you expect. The coach checks whether it will work within the constraints, without giving you the answer.</p>
      <label for="plan" class="field-label">My approach</label>
      <textarea id="plan" class="note-input plan-input" rows="5" placeholder="e.g. Sort the array, then for each element binary-search for target − nums[i]. I expect O(n log n) time and O(1) extra space.">${escapeHtml(state.planText)}</textarea>
      ${err ? `<div class="error" role="alert"><p>${escapeHtml(err.message)}</p>${["NO_KEY", "BAD_KEY", "BAD_MODEL", "LIMIT", "OVERLOADED"].includes(err.code) ? `<button class="secondary" data-action="settings">Open settings</button>` : ""}</div>` : ""}
      <button class="primary" data-action="check-plan" ${busy(state.loading.plan)}>
        ${state.loading.plan ? "Checking your plan…" : state.planCheck ? "Check again" : "Check my approach"}
      </button>
      ${progressHtml("plan")}
      ${state.planCheck ? planResultHtml(state.planCheck) : ""}`;
}
function reviewTabHtml() {
const modes = [
{ id: "plan", label: "Check my approach" },
{ id: "code", label: "Review my code" },
];
const switcher = `<div class="seg-mini mode-switch" role="tablist" aria-label="Review mode">${modes
.map((m) => `<button role="tab" class="${state.reviewMode === m.id ? "active" : ""}" aria-selected="${state.reviewMode === m.id}" data-action="review-mode" data-mode="${m.id}">${m.label}</button>`)
.join("")}</div>`;
return switcher + (state.reviewMode === "plan" ? planModeHtml() : codeModeHtml());
}
function codeModeHtml() {
const lines = state.code ? state.code.split("\n").length : 0;
const meta = [state.codeLang, lines ? `${lines} line${lines === 1 ? "" : "s"}` : ""].filter(Boolean).join(" · ");
return `<p class="intro small">Write your attempt in ${SITE.editorName}, then let the coach read it and explain where your thinking goes wrong, without handing you the answer.</p>
      <div class="code-head">
        <label for="code" class="field-label">Your code${meta ? ` <span class="muted">· ${escapeHtml(meta)}</span>` : ""}</label>
        <button class="mini" data-action="fetch-code" ${busy(state.codeFetching)}>${state.codeFetching ? "Reading…" : "Fetch from editor"}</button>
      </div>
      ${state.codeSource === "page" ? `<p class="warn small">Only the lines visible on screen could be read. Check that the code below is complete, or paste it in.</p>` : ""}
      <textarea id="code" class="code-input" spellcheck="false" rows="10" placeholder="Click “Fetch from editor”, or paste your solution here.">${escapeHtml(state.code)}</textarea>
      <label for="note" class="field-label">What happened? <span class="muted">(optional)</span></label>
      <textarea id="note" class="note-input" rows="2" placeholder="e.g. Wrong Answer on nums = [3,3], target = 6 · Time Limit Exceeded · I think a greedy works because…">${escapeHtml(state.note)}</textarea>
      <button class="primary" data-action="review" ${busy(state.loading.review)}>
        ${state.loading.review ? "Reading your code…" : state.review ? "Review again" : "Find where my thinking goes wrong"}
      </button>
      ${progressHtml("review")}
      ${state.review ? reviewResultHtml(state.review) : ""}`;
}
function subtitle() {
if (state.tab === "hints") return state.hints ? `${state.revealed} of ${TOTAL} hints shown` : "8 hints, one at a time";
if (state.tab === "tests")
return state.tests ? `${state.tests.normal.length} normal · ${state.tests.edge.length} edge cases` : "Normal and edge test cases";
if (state.tab === "review") return state.reviewMode === "plan" ? "Check your approach before you code" : "Check your own code's reasoning";
return "Clues → thinking → brute force → optimal";
}
function footerHtml() {
const parts = [];
if (state.tab === "hints" && state.hints) parts.push(`<button class="link" data-action="start-over">Start over</button>`);
if (state.tab === "tests" && (state.tests || state.customTests?.length)) parts.push(`<button class="link" data-action="copy" data-group="all">Copy every case</button>`);
if (state[state.tab] && state.tab !== "review") parts.push(`<button class="link" data-action="regenerate">Regenerate</button>`);
parts.push(`<button class="link" data-action="settings">Settings</button>`);
parts.push(usageChipHtml());
parts.push(syncStatusHtml());
return parts.join("");
}
function panelHtml() {
const title = escapeHtml(pageTitle());
const tabs = TABS.map(
(t) => `<button class="seg${state.tab === t.id ? " active" : ""}" role="tab" id="tab-${t.id}"
        aria-selected="${state.tab === t.id}" aria-controls="tabpanel" tabindex="${state.tab === t.id ? 0 : -1}"
        data-action="tab" data-tab="${t.id}">${t.label}${state.loading[t.id] ? ' <span class="dot" aria-label="loading"></span>' : ""}</button>`
).join("");
const content = { hints: hintsTabHtml, tests: testsTabHtml, approach: approachTabHtml, review: reviewTabHtml }[state.tab]();
return `<section class="panel${state.wide || state.full ? " wide" : ""}${state.full ? " full" : ""}" role="${EMBED ? "region" : "dialog"}" aria-label="${SITE.name} helper for ${title}">
      <header>
        <div>
          <h2>${title}</h2>
          <p class="sub">${subtitle()}</p>
        </div>
        <div class="header-btns">
          <button class="icon-btn" data-action="about" aria-label="About AlgoSphere" aria-pressed="${state.showAbout}" title="About AlgoSphere">ⓘ</button>
          <button class="icon-btn" data-action="keys" aria-label="Keyboard shortcuts" title="Keyboard shortcuts (Alt+/)">⌨</button>
          <button class="icon-btn" data-action="full" aria-pressed="${state.full}" aria-label="${state.full ? "Exit full screen" : "Full screen: hide the problem"}" title="${state.full ? "Exit full screen (Esc)" : "Full screen: hide the problem (Alt+M)"}">${state.full ? "⤡" : "⤢"}</button>
          <button class="icon-btn" data-action="theme" aria-label="Theme: ${THEME_LABELS[state.themePref]}. Click to change." title="Theme: ${THEME_LABELS[state.themePref]}">${THEME_ICONS[state.themePref]}</button>
          ${EMBED || state.full ? "" : `<button class="icon-btn" data-action="wide" aria-label="${state.wide ? "Make panel narrower" : "Make panel wider"}" title="${state.wide ? "Narrower" : "Wider"}">${state.wide ? "⇥" : "⇤"}</button>
          <button class="icon-btn close" data-action="close" aria-label="Close panel">×</button>`}
        </div>
      </header>
      <div class="segs" role="tablist" aria-label="Sections">${tabs}</div>
      <div class="scroll" id="tabpanel" role="tabpanel" aria-labelledby="tab-${state.tab}">
        ${aboutHtml()}
        ${keysHtml()}
        ${regeneratingHtml()}
        ${limitBannerHtml()}
        ${errorHtml(state.tab)}
        ${content}
      </div>
      <footer>${footerHtml()}</footer>
    </section>`;
}
function tabHtml() {
if (EMBED) return "";
const count = state.hints ? ` ${state.revealed}/${TOTAL}` : "";
return `<button class="tab" data-action="toggle" aria-expanded="${state.open}" title="AlgoSphere by ${AUTHOR.name}">AlgoSphere${count}</button>`;
}
const host = document.createElement("div");
host.id = "lc-hint-ladder";
if (EMBED) host.setAttribute("data-embed", "");
const root = host.attachShadow({ mode: "open" });
const style = document.createElement("style");
style.textContent = CSS();
const mount = document.createElement("div");
mount.className = "mount";
const toastEl = document.createElement("div");
toastEl.className = "toast-wrap";
root.append(style, mount, toastEl);
((EMBED && document.querySelector(EMBED.mount)) || document.body || document.documentElement).appendChild(host);
let lastRenderedTab = null;
function render(focusAction) {
host.style.display = state.slug ? "" : "none";
const active = root.activeElement;
const typing = active && /^(plan|code|note|cf-[\w-]+)$/.test(active.id)
? { id: active.id, start: active.selectionStart, end: active.selectionEnd, scroll: active.scrollTop }
: null;
const prevScroll = root.querySelector(".scroll")?.scrollTop || 0;
mount.innerHTML = tabHtml() + (state.open ? panelHtml() : "");
const scroller = root.querySelector(".scroll");
if (scroller && lastRenderedTab === state.tab) scroller.scrollTop = prevScroll;
lastRenderedTab = state.open ? state.tab : null;
if (focusAction && state.open) {
const target =
root.querySelector(`[data-action="${focusAction}"]:not([disabled])`) || root.querySelector('[data-action="close"]');
target?.focus({ preventScroll: true });
}
state.fresh = -1;
if (typing && !focusAction) {
const el = root.getElementById(typing.id);
if (el) {
el.focus({ preventScroll: true });
el.setSelectionRange(typing.start, typing.end);
el.scrollTop = typing.scroll;
}
}
root.querySelectorAll(".player").forEach((p) => updatePlayer(Number(p.dataset.index), false));
if (state.playerFull >= 0 && !root.querySelector(".player.fs")) {
state.playerFull = -1;
if (document.fullscreenElement === host) document.exitFullscreen?.().catch(() => {});
}
if (playingIndex >= 0 && !root.querySelector(`.player[data-index="${playingIndex}"]`)) stopPlayer();
}
function rerenderKeepFocus(selector) {
render();
root.querySelector(selector)?.focus({ preventScroll: true });
}
function setPlayerFull(i) {
state.playerFull = i;
render();
if (i >= 0) {
root.querySelector(`.player[data-index="${i}"]`)?.focus({ preventScroll: true });
if (document.fullscreenEnabled && document.fullscreenElement !== host) host.requestFullscreen?.().catch(() => {});
} else if (document.fullscreenElement === host) {
document.exitFullscreen?.().catch(() => {});
}
}
document.addEventListener("fullscreenchange", () => {
if (document.fullscreenElement !== host && state.playerFull >= 0) {
state.playerFull = -1;
render();
}
});
function setFull(on) {
state.full = !!on;
render();
if (EMBED) window.dispatchEvent(new CustomEvent("algosphere:panel-full", { detail: { full: state.full } }));
}
function closePanel() {
if (EMBED) return;
state.full = false;
state.open = false;
render();
root.querySelector(".tab")?.focus();
}
function selectTab(id) {
state.tab = id;
render();
root.querySelector(`#tab-${id}`)?.focus({ preventScroll: true });
if (id === "review" && state.reviewMode === "code" && !state.code) fetchCode({ quiet: true });
}
root.addEventListener("click", (e) => {
const el = e.target.closest("[data-action]");
if (!el) return;
const action = el.dataset.action;
const i = Number(el.dataset.index);
if (action === "toggle") {
state.open = !state.open;
render(state.open && state.tab === "hints" ? "reveal" : null);
if (state.open) panelOpened();
if (state.open && state.tab === "review" && state.reviewMode === "code" && !state.code) fetchCode({ quiet: true });
} else if (action === "close") closePanel();
else if (action === "theme") {
const order = ["auto", "light", "dark"];
setThemePref(order[(order.indexOf(state.themePref) + 1) % order.length]);
rerenderKeepFocus('[data-action="theme"]');
} else if (action === "wide") {
state.wide = !state.wide;
chrome.storage.local.set({ ui: { wide: state.wide } }).catch(() => {});
rerenderKeepFocus('[data-action="wide"]');
} else if (action === "about") {
state.showAbout = !state.showAbout;
rerenderKeepFocus('[data-action="about"]');
if (state.showAbout) root.querySelector(".scroll").scrollTop = 0;
} else if (action === "full") {
setFull(!state.full);
root.querySelector('[data-action="full"]')?.focus({ preventScroll: true });
} else if (action === "tab") selectTab(el.dataset.tab);
else if (action === "reveal") reveal();
else if (action === "fetch") fetchSection(el.dataset.kind);
else if (action === "expand") {
state.expanded.has(i) ? state.expanded.delete(i) : state.expanded.add(i);
rerenderKeepFocus(`[data-action="expand"][data-index="${i}"]`);
if (state.expanded.has(i)) fetchDeep(i);
} else if (action === "view") {
state.view[i] = el.dataset.view;
rerenderKeepFocus(`[data-action="view"][data-index="${i}"][data-view="${el.dataset.view}"]`);
if (el.dataset.view !== "idea") fetchDeep(i);
} else if (action === "deep") fetchDeep(i);
else if (action === "code-mode") {
state.codeMode[i] = el.dataset.mode;
rerenderKeepFocus(`[data-action="code-mode"][data-index="${i}"][data-mode="${el.dataset.mode}"]`);
} else if (action === "pl-full") {
const pi = Number(el.closest(".player")?.dataset.index);
setPlayerFull(state.playerFull === pi ? -1 : pi);
} else if (action.startsWith("pl-")) {
const pi = Number(el.closest(".player")?.dataset.index);
const dr = dryOf(pi);
if (!dr) return;
if (action === "pl-play") togglePlay(pi);
else {
stopPlayer();
const k = state.step[pi] || 0;
setStep(pi, { "pl-first": 0, "pl-prev": k - 1, "pl-next": k + 1, "pl-last": dr.steps.length - 1 }[action], action !== "pl-first");
}
} else if (action === "think") {
state.thinkOpen.has(i) ? state.thinkOpen.delete(i) : state.thinkOpen.add(i);
rerenderKeepFocus(`[data-action="think"][data-index="${i}"]`);
} else if (action === "think-all") {
const items = state.approach?.thinking || [];
const allOpen = items.every((_, k) => state.thinkOpen.has(k));
state.thinkOpen = allOpen ? new Set() : new Set(items.map((_, k) => k));
rerenderKeepFocus('[data-action="think-all"]');
} else if (action === "copy-code") {
const d = state.approach?.approaches[i]?.deep;
if (d) copy(el, codeFor(d, state.codeMode[i] || "solution"));
} else if (action === "copy") copyCases(el);
else if (action === "fetch-code") fetchCode();
else if (action === "review") runReview();
else if (action === "check-plan") runPlanCheck();
else if (action === "cancel-gen") {
state.cancelers[el.dataset.key]?.();
}
else if (action === "run-tests") runAllTests();
else if (action === "run-custom") runAllTests("custom");
else if (action === "custom-add") openCustomForm();
else if (action === "custom-edit") openCustomForm(i);
else if (action === "custom-delete") deleteCustomCase(i);
else if (action === "custom-save") saveCustomCase();
else if (action === "custom-cancel") closeCustomForm();
else if (action === "sync-retry") retrySyncNow();
else if (action === "keys") {
state.showKeys = !state.showKeys;
render();
if (state.showKeys) root.querySelector(".scroll").scrollTop = 0;
} else if (action === "review-mode") {
state.reviewMode = el.dataset.mode;
rerenderKeepFocus(`[data-action="review-mode"][data-mode="${el.dataset.mode}"]`);
if (state.reviewMode === "code" && !state.code) fetchCode({ quiet: true });
}
else if (action === "show-correct") {
state.showCorrect = true;
render();
} else if (action === "regenerate") regenerate();
else if (action === "start-over") startOver();
else if (action === "settings") openSettings();
});
root.addEventListener("input", (e) => {
if (e.target.classList.contains("pl-range")) {
const pi = Number(e.target.closest(".player").dataset.index);
stopPlayer();
setStep(pi, Number(e.target.value));
return;
}
if (e.target.id === "code") {
state.code = e.target.value;
if (state.codeSource === "page") state.codeSource = "manual";
} else if (e.target.id === "note") state.note = e.target.value;
else if (e.target.id === "plan") state.planText = e.target.value;
else if (/^cf-/.test(e.target.id) && state.customForm) {
const f = state.customForm;
const id = e.target.id;
if (id === "cf-raw") f.rawText = e.target.value;
else if (id === "cf-out") f.output = e.target.value;
else if (id === "cf-note") f.note = e.target.value;
else if (f.args[Number(id.slice(7))]) f.args[Number(id.slice(7))].value = e.target.value;
}
});
root.addEventListener("change", (e) => {
if (!e.target.classList.contains("pl-speed")) return;
state.speed = Number(e.target.value) || 1;
if (playingIndex >= 0) {
const pi = playingIndex;
stopPlayer();
togglePlay(pi);
}
});
root.addEventListener("keydown", (e) => {
if (state.customForm && e.target.closest?.(".custom-form")) {
if (e.key === "Escape") {
e.preventDefault();
closeCustomForm();
return;
}
if (e.key === "Enter" && e.target.tagName === "INPUT") {
e.preventDefault();
saveCustomCase();
return;
}
}
if (e.key === "Escape" && state.playerFull >= 0) {
setPlayerFull(-1);
return;
}
if (e.key === "Escape" && state.full) {
setFull(false);
root.querySelector('[data-action="full"]')?.focus();
return;
}
if (e.key === "Escape" && state.open && !EMBED) {
closePanel();
return;
}
const player = e.target.closest?.(".player");
if (player && !/^(INPUT|SELECT|BUTTON)$/.test(e.target.tagName)) {
const pi = Number(player.dataset.index);
const dr = dryOf(pi);
const k = state.step[pi] || 0;
const moves = { ArrowRight: k + 1, ArrowLeft: k - 1, Home: 0, End: dr ? dr.steps.length - 1 : 0 };
if (e.key === " ") togglePlay(pi);
else if (e.key === "f" || e.key === "F") setPlayerFull(state.playerFull === pi ? -1 : pi);
else if (e.key in moves) {
stopPlayer();
setStep(pi, moves[e.key]);
} else return;
e.preventDefault();
return;
}
if (e.key === "Tab" && e.target.id === "code" && !e.shiftKey) {
e.preventDefault();
e.target.setRangeText("    ", e.target.selectionStart, e.target.selectionEnd, "end");
state.code = e.target.value;
return;
}
if ((e.key === "ArrowRight" || e.key === "ArrowLeft") && e.target.closest?.('.segs [role="tab"]')) {
const k = KINDS.indexOf(state.tab);
const next = KINDS[(k + (e.key === "ArrowRight" ? 1 : KINDS.length - 1)) % KINDS.length];
selectTab(next);
e.preventDefault();
}
});
host.addEventListener("keydown", (e) => e.stopPropagation());
function syncTheme() {
const dark = state.themePref === "auto" ? SITE.dark() : state.themePref === "dark";
host.dataset.theme = dark ? "dark" : "light";
}
async function setThemePref(pref) {
state.themePref = pref;
syncTheme();
try {
const { settings = {} } = await chrome.storage.local.get("settings");
settings.theme = pref;
await chrome.storage.local.set({ settings });
} catch (_) {
}
}
const [themeEl, themeAttrs] = SITE.themeWatch();
if (themeEl) new MutationObserver(syncTheme).observe(themeEl, { attributes: true, attributeFilter: themeAttrs });
syncTheme();
chrome.storage.local
.get("settings")
.then(({ settings }) => {
state.themePref = THEME_LABELS[settings?.theme] ? settings.theme : "auto";
state.shortcutsOn = settings?.shortcuts !== false;
syncTheme();
if (state.open) render();
})
.catch(() => {});
chrome.storage.onChanged?.addListener((changes, area) => {
if (area === "local" && changes.settings) state.shortcutsOn = changes.settings.newValue?.shortcuts !== false;
if (area === "local" && (changes.usage || changes.settings)) {
loadUsage().then(() => {
if (state.open) renderFooter();
});
}
});
loadUsage();
chrome.storage.onChanged?.addListener((changes, area) => {
if (area !== "local" || !state.slug) return;
const ch = changes[storageKey(state.slug)];
if (!ch?.newValue) return;
const adopted = adoptOtherTab(ch.newValue, changedFields());
if (!adopted.length) return;
for (const f of adopted) state.baseline[f] = fieldJson(f);
state.contentAt = Math.max(state.contentAt, Number(ch.newValue.contentAt) || 0);
if (state.open) render();
});
chrome.storage.onChanged?.addListener((changes, area) => {
if (area !== "local" || !changes.settings) return;
const before = JSON.stringify(changes.settings.oldValue?.github || null);
const after = JSON.stringify(changes.settings.newValue?.github || null);
if (before === after || !state.slug) return;
state.syncedSections = {};
clearSyncRetry();
state.pull = pullFromGithub(state.slug);
});
const retryIfWaiting = () => {
if (state.sync.status === "error" && state.syncRetry.run && !state.syncRetry.permanent && state.syncRetry.at) retrySyncNow();
};
window.addEventListener("online", retryIfWaiting);
document.addEventListener("visibilitychange", () => document.visibilityState === "visible" && retryIfWaiting());
chrome.storage.onChanged?.addListener((changes, area) => {
if (area !== "local" || !changes.settings) return;
const pref = changes.settings.newValue?.theme;
const next = THEME_LABELS[pref] ? pref : "auto";
if (next === state.themePref) return;
state.themePref = next;
syncTheme();
if (state.open) render();
});
async function onRouteChange() {
const slug = currentSlug();
if (slug === state.slug) return;
await loadFor(slug);
render();
if (EMBED && slug) panelOpened();
}
setInterval(onRouteChange, 700);
onRouteChange();
function CSS() {
return `
:host {
  all: initial;
  --surface: #ffffff;
  --raised: #f7f8fa;
  --ink: #262626;
  --muted: #6e6e6e;
  --line: #e3e3e3;
  --accent: #2f6fb0;
  --on-accent: #ffffff;
  --accent-soft: #e8f0fa;
  --code-bg: #f0f2f5;
  --error-bg: #fdf0ef;
  --error-ink: #a3312a;
  --warn-bg: #fdf6e7;
  --warn-ink: #7a5600;
  --good-bg: #eaf6ee;
  --good-ink: #23683f;
  --brute: #b5502d;
  --better: #9a7400;
  --optimal: #2c7a4b;
  --hl-line: rgba(47, 111, 176, 0.14);
  --ptr: #c2410c;
  --tk-k: #8a3fb8;
  --tk-t: #1f7a8c;
  --tk-s: #a3471f;
  --tk-n: #0f7b5c;
  --tk-c: #6b7580;
  --tk-p: #a3312a;
  --shadow: 0 14px 36px rgba(20, 30, 45, 0.18);
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
}
:host([data-theme="dark"]) {
  --surface: #2a2a2a;
  --raised: #323232;
  --ink: #ececec;
  --muted: #a0a0a0;
  --line: #404040;
  --accent: #7fb2ea;
  --on-accent: #10233a;
  --accent-soft: #2c3a4a;
  --code-bg: #3a3e44;
  --error-bg: #3a2725;
  --error-ink: #f2aca5;
  --warn-bg: #3a3221;
  --warn-ink: #f0cf87;
  --good-bg: #233a2b;
  --good-ink: #8fdcaf;
  --brute: #f0a07f;
  --better: #e6c45c;
  --optimal: #7fd3a1;
  --hl-line: rgba(127, 178, 234, 0.18);
  --ptr: #fb923c;
  --tk-k: #d2a8ff;
  --tk-t: #7dd3c0;
  --tk-s: #f0a07f;
  --tk-n: #8fdcaf;
  --tk-c: #8b949e;
  --tk-p: #f2aca5;
  --shadow: 0 14px 36px rgba(0, 0, 0, 0.5);
}
* { box-sizing: border-box; }
button { font: inherit; cursor: pointer; }
button:focus-visible, a:focus-visible, textarea:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
a { color: var(--accent); }

.tab {
  position: fixed;
  right: 0;
  top: 42%;
  z-index: 2147483000;
  writing-mode: vertical-rl;
  transform: rotate(180deg);
  padding: 14px 7px;
  border: 0;
  border-radius: 0 8px 8px 0;
  background: var(--accent);
  color: var(--on-accent);
  font-size: 13px;
  font-weight: 600;
  letter-spacing: 0.02em;
  box-shadow: var(--shadow);
}

.panel {
  position: fixed;
  top: 64px;
  right: 40px;
  z-index: 2147483001;
  width: min(440px, calc(100vw - 56px));
  max-height: calc(100vh - 88px);
  display: flex;
  flex-direction: column;
  background: var(--surface);
  color: var(--ink);
  border: 1px solid var(--line);
  border-radius: 12px;
  box-shadow: var(--shadow);
  font-size: 14px;
  line-height: 1.55;
}
.panel.wide { width: min(720px, calc(100vw - 56px)); }
.panel.full {
  top: 0; right: 0; bottom: 0; left: 0; width: 100vw; height: 100vh; max-height: none;
  border: 0; border-radius: 0; z-index: 2147483003;
}
/* Full screen: keep lines readable by centring the content in at most 1100px. */
.panel.full > header, .panel.full > .scroll, .panel.full > footer {
  padding-left: max(18px, calc((100% - 1100px) / 2)); padding-right: max(18px, calc((100% - 1100px) / 2));
}
.panel.full > .segs { margin-left: max(18px, calc((100% - 1100px) / 2)); margin-right: max(18px, calc((100% - 1100px) / 2)); }
a.sync-status { text-decoration: none; }
a.sync-status:hover { text-decoration: underline; }
.toast a { color: inherit; font-weight: 700; text-decoration: underline; margin-left: 4px; }
:host([data-embed]) { display: block; height: 100%; }
:host([data-embed]) .mount { height: 100%; }
:host([data-embed]) .panel {
  position: relative; top: auto; right: auto; z-index: auto;
  width: 100%; height: 100%; max-height: none;
  border: 0; border-radius: 0; box-shadow: none;
}

header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  gap: 12px;
  padding: 16px 12px 10px 18px;
}
h2 { margin: 0; font-size: 16px; font-weight: 650; line-height: 1.3; }
.sub { margin: 4px 0 0; color: var(--muted); font-size: 12.5px; }
.header-btns { display: flex; gap: 2px; flex: none; }
.icon-btn {
  width: 28px; height: 28px;
  border: 0; border-radius: 6px;
  background: transparent; color: var(--muted);
  font-size: 16px; line-height: 1;
}
.close { font-size: 20px; }
.icon-btn:hover { background: var(--code-bg); color: var(--ink); }

/* Section switcher */
.segs {
  display: flex;
  gap: 2px;
  margin: 0 18px 6px;
  padding: 3px;
  background: var(--code-bg);
  border-radius: 9px;
}
.seg {
  flex: 1;
  padding: 6px 4px;
  border: 0;
  border-radius: 7px;
  background: transparent;
  color: var(--muted);
  font-size: 13px;
  font-weight: 600;
  white-space: nowrap;
}
.seg:hover { color: var(--ink); }
.seg.active { background: var(--surface); color: var(--ink); box-shadow: 0 1px 3px rgba(0,0,0,0.12); }
.dot {
  display: inline-block; width: 6px; height: 6px; margin-left: 3px; vertical-align: middle;
  border-radius: 50%; background: var(--accent);
  animation: pulse 1s ease-in-out infinite alternate;
}
@keyframes pulse { from { opacity: 0.3; } to { opacity: 1; } }

.scroll { overflow-y: auto; padding: 6px 18px 12px; flex: 1 1 auto; min-height: 0; }

.intro { margin: 4px 0 12px; color: var(--muted); font-size: 13.5px; }
.intro.small, .small { font-size: 12.5px; }
.muted { color: var(--muted); }
.empty { padding: 4px 0 8px; }
.warn {
  margin: 0 0 12px; padding: 8px 10px; border-radius: 8px;
  background: var(--warn-bg); color: var(--warn-ink); font-size: 12.5px;
}

/* Hint ladder */
.ladder { list-style: none; margin: 0; padding: 0; }
.rung {
  position: relative;
  display: grid;
  grid-template-columns: 28px 1fr;
  gap: 12px;
  padding: 8px 0 12px;
}
/* The rail between rungs fills in as you climb. */
.rung:not(:last-child)::before {
  content: "";
  position: absolute;
  left: 13px;
  top: 38px;
  bottom: -8px;
  width: 2px;
  background: var(--line);
}
.rung.revealed:not(:last-child)::before { background: var(--accent); }
.num {
  width: 28px; height: 28px;
  border-radius: 50%;
  display: grid; place-items: center;
  border: 2px solid var(--line);
  background: var(--surface);
  color: var(--muted);
  font-size: 13px; font-weight: 650;
  position: relative;
}
.revealed .num { background: var(--accent); border-color: var(--accent); color: var(--on-accent); }
.next .num { border-color: var(--accent); color: var(--accent); }
.label { margin: 4px 0 4px; font-size: 12.5px; font-weight: 600; color: var(--muted); }
.revealed .label { color: var(--accent); }
.locked .label { opacity: 0.65; }
.text { margin: 0; overflow-wrap: anywhere; }
.done { margin: 0 0 8px 40px; color: var(--muted); font-size: 13px; }

code {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12.5px;
  background: var(--code-bg);
  padding: 1px 5px;
  border-radius: 4px;
}

/* Test cases */
.group { margin-bottom: 14px; }
.group-head, .block-head, .code-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin: 6px 0 8px; }
.group-head h3, .block h3 { margin: 0; font-size: 13.5px; font-weight: 650; }
.count { color: var(--muted); font-weight: 500; font-size: 12px; margin-left: 4px; }
.cases { list-style: none; margin: 0; padding: 0; display: grid; gap: 8px; }
.case {
  border: 1px solid var(--line);
  border-radius: 9px;
  padding: 9px 11px;
  background: var(--raised);
}
.case-head { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 6px; }
.case-title { font-size: 12.5px; font-weight: 650; }
.tag {
  margin-left: 4px; padding: 1px 7px; border-radius: 10px;
  background: var(--code-bg); color: var(--muted); font-weight: 600; font-size: 11.5px;
}
.io { display: grid; grid-template-columns: 62px 1fr; gap: 8px; margin: 3px 0; align-items: baseline; }
.io-label { color: var(--muted); font-size: 11.5px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.03em; }
.mono {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12.5px;
  overflow-wrap: anywhere;
}
.arg { color: var(--muted); }
.case .note { margin: 6px 0 0; color: var(--muted); font-size: 12.5px; }
.mini {
  flex: none;
  padding: 2px 9px;
  border: 1px solid var(--line); border-radius: 6px;
  background: var(--surface); color: var(--ink);
  font-size: 12px; font-weight: 600;
}
.mini:hover:not([disabled]) { border-color: var(--accent); color: var(--accent); }
.mini[disabled] { opacity: 0.6; cursor: progress; }
.case-actions { display: flex; gap: 6px; flex-wrap: wrap; justify-content: flex-end; }
/* Your own test cases */
.custom-group { padding: 2px 0 4px; }
.custom-empty { margin: 0 0 6px; }
.case.mine { border-left: 3px solid var(--accent); }
.case.editing { padding: 0; border-left-width: 1px; }
.custom-form { border: 1px solid var(--accent); border-radius: 9px; padding: 10px 11px; background: var(--surface); margin-bottom: 8px; }
.case.editing .custom-form { margin: 0; border: 0; }
.cf-title { margin: 0 0 8px; font-size: 12.5px; font-weight: 650; }
.cf-row { display: grid; grid-template-columns: minmax(62px, max-content) 1fr; gap: 8px; align-items: center; margin: 0 0 6px; }
.cf-name { color: var(--muted); font-size: 12px; font-weight: 600; white-space: nowrap; }
.cf-input, .custom-form textarea {
  width: 100%; min-width: 0; padding: 5px 8px; border: 1px solid var(--line); border-radius: 7px;
  background: var(--raised); color: var(--ink); font-size: 12.5px;
}
.cf-input:focus-visible, .custom-form textarea:focus-visible { outline: 2px solid var(--accent); outline-offset: 1px; }
.cf-label { display: block; font-size: 12px; font-weight: 600; color: var(--muted); margin: 0 0 4px; }
.cf-label small { font-weight: 500; }
.custom-form textarea { margin-bottom: 6px; }
.cf-error { margin: 2px 0 6px; color: var(--error-ink); font-size: 12.5px; }
.cf-actions { display: flex; gap: 8px; align-items: center; margin-top: 4px; }

/* Intuition */
.summary-card {
  margin: 4px 0 14px; padding: 10px 12px; border-radius: 9px;
  background: var(--accent-soft);
}
.oneliner { margin: 0 0 6px; font-size: 14px; }
.pattern { margin: 0; }
.chip {
  display: inline-block; padding: 2px 10px; border-radius: 12px;
  background: var(--accent); color: var(--on-accent); font-size: 12px; font-weight: 650;
}
.block { margin-bottom: 18px; }
.block > h3 { margin-bottom: 6px; }
.block p { margin: 0 0 8px; overflow-wrap: anywhere; }
.bullets, .steps { margin: 0; padding-left: 20px; }
.bullets li, .steps li { margin-bottom: 5px; overflow-wrap: anywhere; }
.signals { list-style: none; margin: 0; padding: 0; display: grid; gap: 6px; }
.signals li {
  display: grid; grid-template-columns: minmax(0, 1fr) auto minmax(0, 1.2fr); gap: 8px; align-items: baseline;
  padding: 7px 10px; border-radius: 8px; background: var(--raised); border: 1px solid var(--line); font-size: 13px;
}
.clue { font-weight: 600; }
.arrow { color: var(--accent); font-weight: 700; }
.qa { list-style: none; margin: 0; padding: 0; display: grid; gap: 6px; }
.qa li { border: 1px solid var(--line); border-radius: 8px; background: var(--raised); overflow: hidden; }
.qa li.open { border-color: var(--accent); }
.q {
  width: 100%; display: grid; grid-template-columns: auto 1fr; gap: 8px; text-align: left;
  padding: 8px 10px; border: 0; background: transparent; color: var(--ink); font-size: 13.5px; font-weight: 600;
}
.qn { color: var(--accent); font-size: 12px; font-weight: 700; padding-top: 1px; }
.a { margin: 0 !important; padding: 0 10px 10px 38px; font-size: 13.5px; }

.table-wrap { overflow-x: auto; margin: 0 0 10px; border: 1px solid var(--line); border-radius: 8px; }
table { border-collapse: collapse; width: 100%; font-size: 12.5px; }
th, td { padding: 5px 8px; text-align: left; border-bottom: 1px solid var(--line); vertical-align: top; }
th { background: var(--code-bg); font-weight: 650; white-space: nowrap; }
tr:last-child td { border-bottom: 0; }
td code { background: transparent; padding: 0; }
.cmp tr.brute { --lvl: var(--brute); }
.cmp tr.better { --lvl: var(--better); }
.cmp tr.optimal { --lvl: var(--optimal); }
.lvl-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: var(--lvl); margin-right: 6px; }

.approaches { list-style: none; margin: 0; padding: 0; display: grid; gap: 8px; }
.approach {
  border: 1px solid var(--line);
  border-left: 4px solid var(--lvl);
  border-radius: 9px;
  background: var(--raised);
  overflow: hidden;
}
.approach.brute { --lvl: var(--brute); }
.approach.better { --lvl: var(--better); }
.approach.optimal { --lvl: var(--optimal); }
.approach-head {
  width: 100%;
  display: grid;
  grid-template-columns: 1fr auto;
  grid-template-areas: "level chev" "name chev" "cx chev";
  text-align: left;
  padding: 9px 12px;
  border: 0;
  background: transparent;
  color: var(--ink);
}
.level { grid-area: level; font-size: 11.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: var(--lvl); }
.approach-name { grid-area: name; font-weight: 650; font-size: 13.5px; }
.approach-cx { grid-area: cx; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 12px; color: var(--muted); }
.chev { grid-area: chev; align-self: center; font-size: 18px; color: var(--muted); padding-left: 8px; }
.approach-body { padding: 0 12px 12px; font-size: 13.5px; }
.approach-body h4 { margin: 10px 0 4px; font-size: 12px; font-weight: 650; color: var(--muted); text-transform: uppercase; letter-spacing: 0.03em; }
.approach-body p { margin: 0 0 6px; }
.aha {
  padding: 8px 10px; border-radius: 8px; background: var(--surface); border: 1px dashed var(--lvl);
  margin-bottom: 10px !important;
}
.aha-label { display: block; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: var(--lvl); margin-bottom: 2px; }
.subtabs { display: flex; gap: 4px; margin: 4px 0 10px; border-bottom: 1px solid var(--line); }
.subtab {
  padding: 5px 10px; border: 0; border-bottom: 2px solid transparent; margin-bottom: -1px;
  background: transparent; color: var(--muted); font-size: 12.5px; font-weight: 600;
}
.subtab.active { color: var(--ink); border-bottom-color: var(--lvl); }
.dr-input, .dr-result { font-size: 13px; }
.cx { display: flex; gap: 18px; margin-bottom: 6px; flex-wrap: wrap; }
.cx-label { color: var(--muted); font-size: 12px; margin-right: 6px; }
pre.code {
  margin: 0; padding: 10px 12px; max-height: 420px; overflow: auto;
  background: var(--code-bg); border-radius: 8px;
  font-size: 12.5px; line-height: 1.5;
}
pre.code code { background: none; padding: 0; white-space: pre; }
.related { margin: 0; padding-left: 18px; }
.related li { margin-bottom: 5px; font-size: 13px; }

/* Review */
.field-label { display: block; font-size: 12.5px; font-weight: 650; margin: 8px 0 4px; }
.code-head .field-label { margin: 0; }
textarea {
  width: 100%; resize: vertical; display: block;
  padding: 8px 10px; border: 1px solid var(--line); border-radius: 8px;
  background: var(--raised); color: var(--ink);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 12.5px; line-height: 1.5;
}
.code-input { min-height: 150px; tab-size: 4; white-space: pre; overflow-wrap: normal; overflow-x: auto; }
.note-input { font-family: inherit; font-size: 13px; margin-bottom: 10px; }
.review-result { margin-top: 16px; padding-top: 14px; border-top: 1px solid var(--line); }
.verdict { padding: 10px 12px; border-radius: 9px; margin-bottom: 14px; }
.verdict p { margin: 6px 0 0; }
.verdict.good { background: var(--good-bg); color: var(--good-ink); }
.verdict.bad { background: var(--error-bg); color: var(--error-ink); }
.verdict.warn { background: var(--warn-bg); color: var(--warn-ink); }
.verdict.muted { background: var(--code-bg); color: var(--ink); }
.badge { display: inline-block; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; }
.findings { list-style: none; margin: 0; padding: 0; display: grid; gap: 8px; }
.finding { padding: 8px 10px; border-radius: 8px; background: var(--raised); border: 1px solid var(--line); border-left: 4px solid var(--brute); }
.finding.bug { border-left-color: var(--better); }
.finding p { margin: 4px 0 0; }
.finding-head { display: flex; justify-content: space-between; gap: 8px; align-items: baseline; }
.lines { flex: none; font-size: 11.5px; color: var(--muted); font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }
.bad-ink { color: var(--error-ink); }
.nudge { padding: 8px 10px; border-radius: 8px; background: var(--accent-soft); }
.good-list li::marker { color: var(--optimal); }
.wide-btn { width: 100%; padding: 8px 12px; }

.primary {
  margin-top: 2px;
  padding: 7px 14px;
  border: 0; border-radius: 7px;
  background: var(--accent); color: var(--on-accent);
  font-weight: 600; font-size: 13.5px;
}
.primary:hover:not([disabled]) { filter: brightness(1.08); }
.primary[disabled] { opacity: 0.7; cursor: progress; }
.secondary {
  padding: 5px 12px;
  border: 1px solid currentColor; border-radius: 7px;
  background: transparent; color: inherit;
  font-size: 13px; font-weight: 600;
}
.error {
  margin: 4px 0 10px;
  padding: 10px 12px;
  border-radius: 8px;
  background: var(--error-bg);
  color: var(--error-ink);
  font-size: 13px;
}
.error p { margin: 0 0 6px; }
.error p:last-child { margin: 0; }

footer {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  padding: 10px 18px 14px;
  border-top: 1px solid var(--line);
}
.link {
  padding: 0; border: 0; background: none;
  color: var(--muted); font-size: 12.5px;
}
.link:hover { color: var(--ink); text-decoration: underline; }
.seg-mini.mode-switch { display: flex; width: 100%; margin: 4px 0 12px; }
.seg-mini.mode-switch button { flex: 1; padding: 6px 8px; font-size: 12.5px; white-space: nowrap; }
.plan-input { font-family: inherit; min-height: 96px; }
.run-bar { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin: 4px 0 4px; }
.run-note { margin: 0 0 10px; }
.run-summary { font-size: 12.5px; font-weight: 700; padding: 2px 9px; border-radius: 10px; }
.run-summary.all-pass { background: var(--good-bg); color: var(--good-ink); }
.run-summary.some-fail { background: var(--error-bg); color: var(--error-ink); }
.run-res { margin-top: 6px; padding: 6px 9px; border-radius: 7px; font-size: 12.5px; overflow-wrap: anywhere; }
.run-res.pass { background: var(--good-bg); color: var(--good-ink); }
.run-res.fail { background: var(--error-bg); color: var(--error-ink); }
.run-res.error { background: var(--warn-bg); color: var(--warn-ink); }
.run-res code { background: transparent; padding: 0; color: inherit; font-weight: 700; }
.run-res pre, .err-detail { margin: 6px 0 0; white-space: pre-wrap; font-size: 11.5px; max-height: 160px; overflow: auto; }
.ai-wrong { color: var(--warn-ink) !important; }
.solved { margin: 2px 0 10px; padding: 7px 10px; border-radius: 8px; background: var(--good-bg); color: var(--good-ink); font-size: 13px; font-weight: 600; }
.keys { margin: 2px 0 12px; padding: 10px 12px; border: 1px solid var(--line); border-radius: 9px; background: var(--raised); font-size: 13px; }
.keys-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; }
.keys table { width: 100%; border-collapse: collapse; }
.keys td { padding: 3px 6px 3px 0; border: 0; vertical-align: top; }
.keys td:first-child { white-space: nowrap; width: 1%; }
kbd {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 11.5px;
  padding: 1px 6px; border: 1px solid var(--line); border-bottom-width: 2px; border-radius: 5px; background: var(--surface);
}
.toast-wrap { position: fixed; right: 48px; bottom: 24px; z-index: 2147483002; }
.toast {
  max-width: 340px; padding: 10px 14px; border-radius: 10px; box-shadow: var(--shadow);
  font: 600 13.5px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  animation: slidein 0.3s ease-out;
}
.toast.good { background: var(--good-bg); color: var(--good-ink); border: 1px solid var(--good-ink); }
.toast.warn { background: var(--warn-bg); color: var(--warn-ink); border: 1px solid var(--warn-ink); }
.regen-note { display: flex; gap: 8px; align-items: center; font-size: 13px; color: var(--muted); }
.gen-progress { display: flex; flex-wrap: wrap; align-items: baseline; gap: 4px 10px; margin-top: 6px; font-size: 12.5px; color: var(--muted); }
.gen-elapsed { font-variant-numeric: tabular-nums; }
.gen-note { flex-basis: 100%; order: 3; color: var(--warn-ink); }
.gen-cancel { font-size: 12.5px; }
.usage-chip { margin-left: auto; font-variant-numeric: tabular-nums; white-space: nowrap; }
.usage-chip + .sync-status { margin-left: 12px; }
.limit-note { margin-top: 2px; }
.sync-status {
  margin-left: auto; padding: 0; border: 0; background: none;
  font-size: 12px; color: var(--muted); white-space: nowrap;
}
.sync-status.loaded, .sync-status.saved { color: var(--good-ink); }
.sync-status.error { color: var(--error-ink); cursor: pointer; }
.sync-status.error:hover { text-decoration: underline; }

.fresh .body { animation: reveal 220ms ease-out; }
@keyframes reveal {
  from { opacity: 0; transform: translateY(-4px); }
  to { opacity: 1; transform: none; }
}
/* Code and pseudocode */
.codebox { border: 1px solid var(--line); border-radius: 8px; background: var(--code-bg); max-height: 460px; overflow: auto; }
.codelines {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12.5px; line-height: 1.6; padding: 6px 0; min-width: max-content;
}
.cl { display: grid; grid-template-columns: 34px 1fr; padding-right: 12px; transition: background 0.2s; }
.ln { color: var(--muted); text-align: right; padding-right: 10px; user-select: none; opacity: 0.7; }
.lc { white-space: pre; }
.cl.cur { background: var(--hl-line); box-shadow: inset 3px 0 0 var(--accent); }
.cl.cur .ln { color: var(--accent); opacity: 1; font-weight: 700; }
.tk-k { color: var(--tk-k); font-weight: 600; }
.tk-t { color: var(--tk-t); }
.tk-s { color: var(--tk-s); }
.tk-n { color: var(--tk-n); }
.tk-c { color: var(--tk-c); font-style: italic; }
.tk-p { color: var(--tk-p); }
.seg-mini { display: inline-flex; background: var(--code-bg); border-radius: 7px; padding: 2px; gap: 2px; }
.seg-mini button {
  border: 0; background: transparent; color: var(--muted); font-size: 12px; font-weight: 600;
  padding: 3px 9px; border-radius: 5px;
}
.seg-mini button.active { background: var(--surface); color: var(--ink); box-shadow: 0 1px 2px rgba(0,0,0,0.12); }

/* Complexity derivation */
.cost { border: 1px solid var(--line); border-radius: 9px; padding: 10px 12px; margin-bottom: 10px; background: var(--surface); }
.cost-head { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
.cost-title { font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: var(--muted); }
code.big { font-size: 14px; font-weight: 700; padding: 2px 8px; color: var(--lvl, var(--accent)); }
.cost-table td { font-size: 12.5px; }
.nowrap { white-space: nowrap; }
.derive { padding: 8px 10px; border-radius: 8px; background: var(--accent-soft); }
.derive-label { display: block; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: var(--accent); margin-bottom: 2px; }
.deep-loading {
  display: flex; gap: 10px; align-items: center; padding: 10px 12px; margin: 6px 0;
  border-radius: 8px; background: var(--surface); border: 1px dashed var(--line); color: var(--muted); font-size: 13px;
}
.spinner {
  flex: none; width: 16px; height: 16px; border-radius: 50%;
  border: 2px solid var(--line); border-top-color: var(--accent);
  animation: spin 0.8s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* Dry-run player */
.player { outline: none; border-radius: 10px; }
.player:focus-visible { box-shadow: 0 0 0 2px var(--accent); }
.pl-grid { display: grid; gap: 10px; }
.panel.wide .pl-grid { grid-template-columns: minmax(0, 1.25fr) minmax(0, 1fr); align-items: start; }
.pl-stage {
  border: 1px solid var(--line); border-radius: 9px; background: var(--surface);
  padding: 10px; display: grid; gap: 10px; min-height: 90px;
}
.pl-stage > div:empty { display: none; }
.pl-code { position: relative; max-height: 230px; overflow: auto; border: 1px solid var(--line); border-radius: 9px; background: var(--code-bg); scroll-behavior: smooth; }
.panel.wide .pl-code { max-height: 340px; }
.arr-name, .struct-name { font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 12px; font-weight: 700; color: var(--muted); margin-bottom: 4px; }
.arr-scroll { overflow-x: auto; overflow-y: hidden; padding: 0 2px 4px; }
.arr-track { position: relative; width: max-content; padding: 0 calc(var(--cell) / 2); }
.cells { display: flex; }
.cellbox { width: var(--cell); display: flex; flex-direction: column; align-items: center; }
.cellbox .v {
  width: calc(var(--cell) - 4px); height: 34px; display: grid; place-items: center;
  border: 2px solid var(--line); border-radius: 7px; background: var(--raised);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 13px; font-weight: 600;
  overflow: hidden; white-space: nowrap; text-overflow: ellipsis;
  transition: background 0.3s, border-color 0.3s, transform 0.3s;
}
.cellbox .idx { font-size: 10.5px; color: var(--muted); margin-top: 2px; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }
.cellbox.hl .v { border-color: var(--accent); background: var(--accent-soft); transform: translateY(-2px); }
.cellbox.changed .v { animation: pop 0.6s ease-out; }
.ptrs { position: relative; height: 0; margin-top: 2px; transition: height 0.3s; }
.ptr {
  position: absolute; transform: translateX(-50%); display: flex; flex-direction: column; align-items: center;
  transition: left 0.45s cubic-bezier(.3,.7,.3,1), top 0.3s;
  color: var(--ptr); font-weight: 700; line-height: 1.1;
}
.ptr-arrow { font-size: 11px; }
.ptr-label { font-size: 11.5px; font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; background: var(--surface); padding: 0 3px; border-radius: 4px; }
.ptr.out { opacity: 0.45; }
.grid-wrap { overflow-x: auto; }
table.grid { width: auto; border-collapse: separate; border-spacing: 3px; }
table.grid th { background: transparent; color: var(--muted); font-size: 10.5px; padding: 0 4px; border: 0; }
table.grid td {
  min-width: 32px; height: 30px; text-align: center; vertical-align: middle; position: relative;
  border: 2px solid var(--line); border-radius: 6px; background: var(--raised);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-weight: 600; padding: 2px 6px;
}
table.grid td.hl { border-color: var(--accent); background: var(--accent-soft); }
table.grid td.changed { animation: pop 0.6s ease-out; }
table.grid td.ptr-cell { border-color: var(--ptr); }
.gptr { position: absolute; top: -7px; right: -4px; font-size: 9.5px; background: var(--ptr); color: var(--surface); border-radius: 4px; padding: 0 3px; }
.struct-head { display: flex; gap: 8px; align-items: baseline; }
.struct-type { font-size: 11px; color: var(--muted); }
.items { display: flex; flex-wrap: wrap; gap: 4px; min-height: 26px; align-items: center; }
.item {
  padding: 2px 8px; border-radius: 6px; border: 1px solid var(--line); background: var(--raised);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 12.5px;
}
.item code { background: none; padding: 0; }
.item.new { animation: slidein 0.5s ease-out; border-color: var(--optimal); }
.stack .item:last-child, .queue .item:first-child { border-color: var(--accent); font-weight: 700; }
.pl-vars { display: flex; flex-wrap: wrap; gap: 6px; }
.var {
  display: inline-flex; border: 1px solid var(--line); border-radius: 7px; overflow: hidden;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; font-size: 12.5px;
}
.var-name { padding: 2px 7px; background: var(--code-bg); color: var(--muted); font-weight: 600; }
.var-val { padding: 2px 8px; background: var(--surface); font-weight: 700; }
.var.changed { animation: pop 0.6s ease-out; border-color: var(--better); }
.var.changed .var-val { background: var(--warn-bg); color: var(--warn-ink); }
.pl-explain {
  margin: 10px 0 8px; padding: 9px 12px; border-radius: 9px; min-height: 44px;
  background: var(--accent-soft); font-size: 13.5px;
}
.pl-stepno { display: block; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.04em; color: var(--accent); margin-bottom: 2px; }
.pl-controls { display: flex; align-items: center; gap: 5px; flex-wrap: wrap; }
.pl-btn {
  min-width: 30px; height: 28px; padding: 0 8px; border: 1px solid var(--line); border-radius: 7px;
  background: var(--surface); color: var(--ink); font-size: 12px; font-weight: 600;
}
.pl-btn:hover:not([disabled]) { border-color: var(--accent); color: var(--accent); }
.pl-btn[disabled] { opacity: 0.4; cursor: default; }
.pl-play { min-width: 86px; background: var(--accent); color: var(--on-accent); border-color: var(--accent); }
.pl-play:hover:not([disabled]) { color: var(--on-accent); filter: brightness(1.08); }
.pl-range { flex: 1; min-width: 80px; accent-color: var(--accent); }
.pl-count { font-size: 12px; color: var(--muted); font-variant-numeric: tabular-nums; min-width: 42px; text-align: center; }
.pl-speed { font: inherit; font-size: 12px; padding: 3px 4px; border: 1px solid var(--line); border-radius: 6px; background: var(--surface); color: var(--ink); }
.pl-result:not(:empty) { margin-top: 10px; padding: 9px 12px; border-radius: 9px; background: var(--good-bg); color: var(--good-ink); font-size: 13.5px; }
.player.no-anim .ptr, .player.no-anim .cellbox .v { transition: none; }
.pl-full { margin-left: auto; }
.about p { margin: 6px 0 0; }
.about-links a { font-weight: 600; }
/* Dry run full screen */
.pl-fs-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
.pl-fs-title { font-weight: 700; font-size: 15px; }
.player.fs {
  position: fixed; inset: 0; z-index: 2147483006; border-radius: 0; margin: 0;
  display: flex; flex-direction: column; gap: 10px; padding: 14px 22px 16px; overflow: hidden;
  background: var(--surface); color: var(--ink); font-size: 14px; line-height: 1.55;
}
.player.fs:focus-visible { box-shadow: none; }
.player.fs .dr-input { margin: 0; }
.player.fs .pl-grid { flex: 1; min-height: 0; grid-template-columns: minmax(0, 1.2fr) minmax(380px, 1fr); align-items: stretch; }
.player.fs .pl-stage { overflow: auto; align-content: start; }
.player.fs .pl-code { max-height: none; height: 100%; }
.player.fs .shape-scroll { max-height: none; }
/* Use the room: larger drawings, cells and variables (they still scroll if too big). */
.player.fs .shape-stage { zoom: 1.35; }
.player.fs .pl-arrays, .player.fs .pl-structs, .player.fs .pl-vars { zoom: 1.15; }
.player.fs .pl-explain { margin: 0; font-size: 15px; }
@media (max-width: 760px) {
  .player.fs { overflow: auto; }
  .player.fs .pl-grid { grid-template-columns: 1fr; flex: none; }
  .player.fs .pl-code { height: auto; max-height: 40vh; }
}
@keyframes pop {
  0% { transform: scale(1); }
  35% { transform: scale(1.14); }
  100% { transform: scale(1); }
}
@keyframes slidein {
  from { opacity: 0; transform: translateY(-6px); }
  to { opacity: 1; transform: none; }
}

/* Trees, linked lists and graphs */
.pl-shapes { display: grid; gap: 12px; }
.pl-shapes:empty { display: none; }
.shape-kind { font-weight: 500; color: var(--muted); font-family: inherit; }
.shape-scroll { overflow: auto; max-height: 360px; padding: 2px 2px 4px; }
.shape-stage { position: relative; margin: 0 auto; }
.shape-svg { display: block; overflow: visible; }
.shape-svg .se { stroke: var(--muted); stroke-opacity: 0.6; stroke-width: 1.6; fill: none; }
.shape-svg .sah { fill: var(--muted); fill-opacity: 0.8; }
.shape-svg .seg.on .se { stroke: var(--accent); stroke-opacity: 1; stroke-width: 2.8; }
.shape-svg .seg.on .sah { fill: var(--accent); fill-opacity: 1; }
.shape-svg .sn circle, .shape-svg .sn rect { fill: var(--surface); stroke: var(--muted); stroke-width: 1.6; transition: fill 0.25s, stroke 0.25s; }
.shape-svg .sn text {
  fill: var(--ink); font: 600 12px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  text-anchor: middle; dominant-baseline: central; transition: fill 0.25s;
}
.shape-svg .sn.vis circle, .shape-svg .sn.vis rect { fill: var(--good-bg); stroke: var(--good-ink); }
.shape-svg .sn.hl circle, .shape-svg .sn.hl rect { fill: var(--accent); stroke: var(--accent); }
.shape-svg .sn.hl text { fill: var(--on-accent); }
.shape-svg .sn { transform-box: fill-box; transform-origin: center; }
.shape-svg .sn.pulse { animation: sn-pulse 0.5s ease-out; }
@keyframes sn-pulse { 0% { transform: scale(1.22); } 100% { transform: scale(1); } }
.shape-svg .sw {
  fill: var(--ink); font: 600 11px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  text-anchor: middle; dominant-baseline: central; paint-order: stroke; stroke: var(--surface); stroke-width: 4px;
}
.shape-svg .snull { fill: var(--muted); font-size: 15px; text-anchor: middle; dominant-baseline: central; }
.sptrs { position: absolute; inset: 0; pointer-events: none; }
.sptr {
  position: absolute; transform: translateX(-50%); padding: 0 6px; border-radius: 6px;
  background: var(--ptr); color: #fff; font: 700 11px/17px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  white-space: nowrap; transition: left 0.35s ease, top 0.35s ease;
}
.player.no-anim .sptr { transition: none; }
.shape-note { font-size: 12px; color: var(--muted); font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }
.shape-note:empty { display: none; }
.case-viz { margin: 8px 0 2px; padding: 8px 10px; border: 1px solid var(--line); border-radius: 9px; background: var(--surface); }
.case-viz figcaption { font-size: 11.5px; color: var(--muted); font-weight: 600; margin-bottom: 4px; }
.case-viz .shape-scroll { max-height: 240px; }
.case-viz .shape-svg { margin: 0 auto; }

@media (prefers-reduced-motion: reduce) {
  .fresh .body, .dot, .spinner, .cellbox.changed .v, .var.changed, .item.new, table.grid td.changed { animation: none; }
  .ptr, .cellbox .v, .pl-code, .sptr, .shape-svg .sn circle, .shape-svg .sn rect { transition: none; scroll-behavior: auto; }
  .shape-svg .sn.pulse { animation: none; }
}
`;
}
})();
