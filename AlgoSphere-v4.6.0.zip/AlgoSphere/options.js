// AlgoSphere v4.6.0. Copyright 2026 Rishit Aggarwal (https://github.com/rishitaggarwal1). Apache-2.0: see LICENSE and NOTICE.
const DEFAULT_PROVIDER = "gemini";
const DEFAULT_MODELS = {
anthropic: "claude-haiku-5-5",
gemini: "gemini-3.8-flash",
openai: "gpt-5-mini",
};
const DEEP_SUGGESTIONS = {
anthropic: "e.g. claude-sonnet-5-5",
gemini: "e.g. a Gemini Pro model",
openai: "e.g. gpt-5",
};
const KEY_HELP = {
anthropic: 'Create a key in the Claude Console. See <a href="https://docs.claude.com" target="_blank" rel="noopener">docs.claude.com</a>.',
gemini:
'Create a free key in <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">Google AI Studio</a> (sign in with a Google account, then "Create API key"). After saving, click <strong>Find models</strong> to see which models your key can use.',
openai: 'Create a key at <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener">platform.openai.com</a>.',
};
const $ = (id) => document.getElementById(id);
let settings = { provider: DEFAULT_PROVIDER, apiKeys: {}, models: {}, deepModels: {}, theme: "auto" };
let lastProvider = null;
function setStatus(text, ok) {
$("status").textContent = text;
$("status").className = "status " + (ok ? "ok" : "bad");
}
function showProvider() {
const p = $("provider").value;
$("apiKey").value = settings.apiKeys[p] || "";
$("apiKey").placeholder = "Paste your " + $("provider").selectedOptions[0].text.replace(/\s*\(.*\)$/, "") + " key";
$("model").value = settings.models[p] || "";
$("model").placeholder = DEFAULT_MODELS[p];
$("deepModel").value = settings.deepModels[p] || "";
$("deepModel").placeholder = DEEP_SUGGESTIONS[p];
$("keyHelp").innerHTML = KEY_HELP[p];
$("findModels").hidden = p !== "gemini";
$("modelList").innerHTML = "";
}
function stash(p = $("provider").value) {
settings.apiKeys[p] = $("apiKey").value.trim();
settings.models[p] = $("model").value.trim();
settings.deepModels[p] = $("deepModel").value.trim();
}
async function countHints() {
const all = await chrome.storage.local.get(null);
const n = Object.keys(all).filter((k) => k.startsWith("hints:")).length;
$("hintCount").textContent =
n === 0 ? "No problems have saved data yet." : `${n} problem${n === 1 ? " has" : "s have"} saved hints, tests, explanations or reviews.`;
}
async function init() {
const { settings: saved } = await chrome.storage.local.get("settings");
if (saved) {
settings = {
provider: saved.provider || DEFAULT_PROVIDER,
apiKeys: saved.apiKeys || {},
models: saved.models || {},
deepModels: saved.deepModels || {},
theme: saved.theme || "auto",
};
}
showTheme(settings.theme);
showGithub(saved?.github || {});
$("keysEnabled").checked = saved?.shortcuts !== false;
usageSettings = saved?.usage || {};
speedSettings = {
speed: saved?.speed || "balanced",
backupModels: saved?.backupModels || {},
backupProvider: saved?.backupProvider || "",
prefetchHints: saved?.prefetchHints !== false,
prefetchTests: saved?.prefetchTests !== false,
};
$("provider").value = settings.provider;
lastProvider = settings.provider;
showProvider();
countHints();
showUsageSettings();
showSpeedSettings();
loadUsageView();
}
function ghStatus(text, ok) {
$("ghStatus").textContent = text;
$("ghStatus").className = "status " + (ok ? "ok" : "bad");
}
function readGithubForm() {
return {
enabled: $("ghEnabled").checked,
repo: $("ghRepo").value.trim(),
token: $("ghToken").value.trim(),
branch: $("ghBranch").value.trim(),
folder: $("ghFolder").value.trim() || "dsa-notes",
includeSolutions: $("ghSolutions").checked,
};
}
function showGithub(g) {
$("ghEnabled").checked = !!g.enabled;
$("ghRepo").value = g.repo || "";
$("ghToken").value = g.token || "";
$("ghBranch").value = g.branch || "";
$("ghFolder").value = g.folder || "";
$("ghSolutions").checked = g.includeSolutions !== false;
updatePathHelp();
}
function updatePathHelp() {
const folder = ($("ghFolder").value.trim() || "dsa-notes").replace(/^\/+|\/+$/g, "");
$("ghPathHelp").innerHTML = `Each problem gets a folder such as <code>${escapeText(folder)}/leetcode/two-sum/</code> with a README, a C++ solution and the saved data. <code>${escapeText(folder)}/README.md</code> lists every problem.`;
}
function escapeText(s) {
return s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
}
$("ghFolder").addEventListener("input", updatePathHelp);
$("ghSave").addEventListener("click", async () => {
const g = readGithubForm();
if (g.enabled && (!g.repo || !g.token)) return ghStatus("Fill in the repository and the token to turn sync on.", false);
const { settings: stored = {} } = await chrome.storage.local.get("settings");
await chrome.storage.local.set({ settings: { ...stored, github: g } });
ghStatus(g.enabled ? "Saved. Problems you open will now load from and save to GitHub." : "Saved. GitHub sync is off.", true);
});
$("ghTest").addEventListener("click", async () => {
const btn = $("ghTest");
btn.disabled = true;
ghStatus("Checking…", true);
const res = await send({ type: "SYNC_TEST", github: readGithubForm() });
btn.disabled = false;
if (!res || !res.ok) return ghStatus(res?.error || "No response.", false);
const r = res.result;
$("ghRepo").value = r.repo;
const expires = Date.parse(String(r.tokenExpires || "").replace(" UTC", "Z").replace(" ", "T"));
const days = Math.ceil((expires - Date.now()) / 86400000);
const expiry = !expires
? ""
: days <= 7
? ` Your token expires in ${days} day${days === 1 ? "" : "s"} (${new Date(expires).toLocaleDateString()}): create a new one soon so saving keeps working.`
: ` The token expires on ${new Date(expires).toLocaleDateString()}.`;
ghStatus(
`Connected to ${r.repo} (${r.private ? "private" : "public"}). Files will go to ${r.folder || "the repository root"}/ on the "${r.branch}" branch. Remember to save.${expiry}`,
!expires || days > 7
);
});
let speedSettings = { speed: "balanced", backupModels: {}, backupProvider: "", prefetchHints: true, prefetchTests: true };
function showSpeedSettings() {
const provider = $("provider").value;
const radio = document.querySelector(`input[name="speed"][value="${speedSettings.speed || "balanced"}"]`);
if (radio) radio.checked = true;
$("backupModelProvider").textContent = PROVIDER_NAMES[provider] || provider;
$("backupModel").value = speedSettings.backupModels?.[provider] || "";
$("backupModel").placeholder = provider === "openai" ? "None" : "Automatic";
$("backupModelHelp").textContent =
provider === "gemini"
? "Used when the main model is overloaded (503) or doesn't answer in time. Automatic picks another fast Gemini model your key can use."
: provider === "anthropic"
? "Used when the main model is overloaded or doesn't answer in time. Automatic switches between Claude Haiku 5.5 and Sonnet 5.5."
: "Used when the main model is overloaded or doesn't answer in time.";
$("backupProvider").value = speedSettings.backupProvider || "";
$("prefetchHints").checked = speedSettings.prefetchHints !== false;
$("prefetchTests").checked = speedSettings.prefetchTests !== false;
showBackupKey();
}
function showBackupKey() {
const bp = $("backupProvider").value;
const show = !!bp && bp !== $("provider").value;
$("backupKeyBox").hidden = !show;
if (!show) return;
$("backupKeyProvider").textContent = PROVIDER_NAMES[bp] || bp;
$("backupKey").value = settings.apiKeys[bp] || "";
$("backupKey").placeholder = `Paste your ${PROVIDER_NAMES[bp] || bp} key`;
$("backupKeyHelp").innerHTML = `${KEY_HELP[bp]} Saved with the speed settings. It uses ${PROVIDER_NAMES[bp]}'s model from the AI provider section, or ${DEFAULT_MODELS[bp]} if none is set.`;
}
$("backupProvider").addEventListener("change", () => {
showBackupKey();
$("speedStatus").textContent = "";
});
$("backupKey").addEventListener("input", () => {
const bp = $("backupProvider").value;
if (bp) settings.apiKeys[bp] = $("backupKey").value.trim();
});
$("backupTest").addEventListener("click", async () => {
const bp = $("backupProvider").value;
const key = $("backupKey").value.trim();
const status = (text, ok) => {
$("speedStatus").textContent = text;
$("speedStatus").className = "status " + (ok ? "ok" : "bad");
};
if (!key) return status(`Paste your ${PROVIDER_NAMES[bp]} key first.`, false);
const model = settings.models[bp] || DEFAULT_MODELS[bp];
$("backupTest").disabled = true;
status("Testing…", true);
const res = await send({ type: "TEST_CONNECTION", provider: bp, key, model });
$("backupTest").disabled = false;
if (res && res.ok) status(`${model} works (answered in ${(res.result.ms / 1000).toFixed(1)}s). Remember to save.`, true);
else status(`${model}: ${res?.error || "no response"}`, false);
});
$("speedSave").addEventListener("click", async () => {
const provider = $("provider").value;
const { settings: stored = {} } = await chrome.storage.local.get("settings");
const backupModels = { ...(stored.backupModels || {}) };
const bm = $("backupModel").value.trim();
if (bm) backupModels[provider] = bm;
else delete backupModels[provider];
const backupProvider = $("backupProvider").value;
const apiKeys = { ...(stored.apiKeys || {}) };
if (backupProvider && backupProvider !== provider) {
const key = $("backupKey").value.trim();
if (key) apiKeys[backupProvider] = key;
else delete apiKeys[backupProvider];
settings.apiKeys[backupProvider] = key;
}
const next = {
...stored,
apiKeys,
speed: document.querySelector('input[name="speed"]:checked')?.value || "balanced",
backupModels,
backupProvider: backupProvider === provider ? "" : backupProvider,
prefetchHints: $("prefetchHints").checked,
prefetchTests: $("prefetchTests").checked,
};
await chrome.storage.local.set({ settings: next });
speedSettings = next;
const noKey = next.backupProvider && !apiKeys[next.backupProvider];
$("speedStatus").textContent = noKey
? `Saved, but there's no ${PROVIDER_NAMES[next.backupProvider]} key yet: paste one in "API key for ${PROVIDER_NAMES[next.backupProvider]}" to use it as the backup.`
: backupProvider && backupProvider === provider
? "Saved. The backup provider must differ from the main one, so it was left off."
: "Speed settings saved.";
$("speedStatus").className = noKey ? "status bad" : "status ok";
});
$("provider").addEventListener("change", showSpeedSettings);
const KIND_LABELS = {
hints: "Hints",
tests: "Test cases",
approach: "Intuition overview",
deep: "Approach deep dives",
review: "Code review",
plan: "Approach check",
test: "Connection test",
};
const PROVIDER_NAMES = { gemini: "Google Gemini", anthropic: "Anthropic Claude", openai: "OpenAI" };
const dayKey = (t) => new Date(t).toLocaleDateString("en-CA");
const fmtTokens = (n) => (n >= 1e6 ? `${(n / 1e6).toFixed(1)}M` : n >= 1000 ? `${(n / 1000).toFixed(1)}k` : String(n || 0));
const fmtCost = (c) => (c == null ? "–" : c <= 0 ? "$0.00" : c < 0.01 ? "<$0.01" : `$${c.toFixed(2)}`);
const emptyB = () => ({ requests: 0, failed: 0, input: 0, output: 0, cost: 0, listCost: 0, unpriced: 0 });
function addB(a, b) {
for (const k of Object.keys(emptyB())) a[k] += b[k] || 0;
return a;
}
let usageCache = { days: {}, recent: [] };
let usageSettings = {};
function costText(b) {
if (!b.requests) return "$0.00";
if (b.cost === 0 && b.listCost > 0) return "Free";
if (b.unpriced && !b.cost) return "Unknown price";
return fmtCost(b.cost);
}
function renderUsage() {
const days = usageCache.days || {};
const today = days[dayKey(Date.now())] || emptyB();
$("uTodayReq").textContent = today.requests;
$("uTodayTokens").textContent = `${fmtTokens(today.input)} in · ${fmtTokens(today.output)} out${today.failed ? ` · ${today.failed} failed` : ""}`;
const freeToday = today.cost === 0 && today.listCost > 0;
$("uTodayCost").textContent = freeToday ? "$0.00" : fmtCost(today.cost);
$("uTodayCostSub").textContent = freeToday
? `Free tier · about ${fmtCost(today.listCost)} on a paid plan`
: today.unpriced
? `${today.unpriced} request${today.unpriced === 1 ? "" : "s"} with an unknown price`
: usageSettings.dailyBudget > 0
? `of ${fmtCost(Number(usageSettings.dailyBudget))} daily budget`
: " ";
const last30 = emptyB();
const kinds = {};
const models = {};
for (let i = 0; i < 30; i++) {
const d = days[dayKey(Date.now() - i * 86400000)];
if (!d) continue;
addB(last30, d);
for (const [k, b] of Object.entries(d.kinds || {})) addB((kinds[k] ||= emptyB()), b);
for (const [k, b] of Object.entries(d.models || {})) addB((models[k] ||= emptyB()), b);
}
$("u30Req").textContent = last30.requests;
$("u30Sub").textContent = `requests · ${fmtTokens(last30.input + last30.output)} tokens · ${costText(last30)}`;
const series = [];
for (let i = 13; i >= 0; i--) {
const t = Date.now() - i * 86400000;
series.push({ t, key: dayKey(t), b: days[dayKey(t)] || emptyB() });
}
const max = Math.max(1, ...series.map((x) => x.b.requests));
$("uBars").innerHTML = series
.map((x, i) => {
const h = x.b.requests ? Math.max(4, Math.round((x.b.requests / max) * 100)) : 0;
const date = new Date(x.t).toLocaleDateString([], { month: "short", day: "numeric" });
const label = `${date}: ${x.b.requests} request${x.b.requests === 1 ? "" : "s"}, ${fmtTokens(x.b.input + x.b.output)} tokens, ${costText(x.b)}`;
return `<div class="bar${x.b.requests ? "" : " empty"}" tabindex="0" data-i="${i}" aria-label="${label}" data-tip="${label}"><span style="height:${h}%"></span></div>`;
})
.join("");
$("uAxis").innerHTML = series
.map((x, i) => `<span>${i % 2 === 1 || i === 13 ? new Date(x.t).getDate() : ""}</span>`)
.join("");
const table = (rows, nameHead) =>
`<thead><tr><th>${nameHead}</th><th class="num">Requests</th><th class="num">Tokens</th><th class="num">Cost</th></tr></thead><tbody>${
rows.length
? rows
.map(([name, b]) => `<tr><td>${escapeText(name)}</td><td class="num">${b.requests}</td><td class="num">${fmtTokens(b.input + b.output)}</td><td class="num">${costText(b)}</td></tr>`)
.join("")
: `<tr class="empty-row"><td colspan="4">No requests yet.</td></tr>`
}</tbody>`;
$("uKinds").innerHTML = table(
Object.entries(kinds).sort((a, b) => b[1].requests - a[1].requests).map(([k, b]) => [KIND_LABELS[k] || k, b]),
"Feature"
);
$("uModels").innerHTML = table(Object.entries(models).sort((a, b) => b[1].requests - a[1].requests), "Model");
const recent = (usageCache.recent || []).slice(0, 8);
$("uRecent").innerHTML = recent.length
? recent
.map((e) => {
const when = new Date(e.at).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
const what = `${KIND_LABELS[e.kind] || e.kind}${e.title ? ` · ${e.title}` : ""}`;
const amount = e.ok
? `${fmtTokens(e.input + e.output)} tokens · ${e.free ? "free" : e.cost == null ? "price unknown" : fmtCost(e.cost)}`
: "failed";
return `<li><span class="when">${escapeText(when)}</span><span class="what">${escapeText(what)} <small>${escapeText(e.model || "")}</small></span><span class="amount${e.ok ? "" : " failed"}" title="${escapeText(e.error || "")}">${escapeText(amount)}</span></li>`;
})
.join("")
: '<li class="log-empty" style="display:block">No AI requests yet.</li>';
}
function showTip(bar) {
const tip = $("uTip");
if (!bar) {
tip.hidden = true;
return;
}
const chart = $("uChart").getBoundingClientRect();
const r = bar.getBoundingClientRect();
tip.textContent = bar.dataset.tip;
tip.hidden = false;
const half = tip.offsetWidth / 2;
const x = Math.min(Math.max(r.left - chart.left + r.width / 2, half), chart.width - half);
tip.style.left = `${x}px`;
}
$("uBars").addEventListener("mouseover", (e) => showTip(e.target.closest(".bar")));
$("uBars").addEventListener("mouseleave", () => showTip(null));
$("uBars").addEventListener("focusin", (e) => showTip(e.target.closest(".bar")));
$("uBars").addEventListener("focusout", () => showTip(null));
function showUsageSettings() {
const us = usageSettings;
$("uLimitReq").value = us.dailyRequests > 0 ? us.dailyRequests : "";
$("uLimitCost").value = us.dailyBudget > 0 ? us.dailyBudget : "";
$("uEnforce").checked = !!us.enforce;
$("uFreeTier").checked = us.geminiFreeTier !== false;
const provider = $("provider").value;
$("uPriceProvider").textContent = PROVIDER_NAMES[provider] || provider;
const custom = us.prices?.[provider] || {};
$("uPriceIn").value = custom.in || "";
$("uPriceOut").value = custom.out || "";
}
async function loadUsageView() {
const { usage, settings: stored } = await chrome.storage.local.get(["usage", "settings"]);
usageCache = usage && usage.days ? usage : { days: {}, recent: [] };
usageSettings = stored?.usage || {};
renderUsage();
}
$("uSave").addEventListener("click", async () => {
const provider = $("provider").value;
const { settings: stored = {} } = await chrome.storage.local.get("settings");
const prev = stored.usage || {};
const prices = { ...(prev.prices || {}) };
const pin = Number($("uPriceIn").value);
const pout = Number($("uPriceOut").value);
if (pin > 0 || pout > 0) prices[provider] = { in: pin || 0, out: pout || 0 };
else delete prices[provider];
const next = {
dailyRequests: Math.max(0, Math.floor(Number($("uLimitReq").value) || 0)),
dailyBudget: Math.max(0, Number($("uLimitCost").value) || 0),
enforce: $("uEnforce").checked,
geminiFreeTier: $("uFreeTier").checked,
prices,
};
await chrome.storage.local.set({ settings: { ...stored, usage: next } });
usageSettings = next;
$("uStatus").textContent = "Usage settings saved.";
$("uStatus").className = "status ok";
renderUsage();
});
$("uClear").addEventListener("click", async () => {
if (!confirm("Clear the usage history? Your settings and saved problems stay.")) return;
await chrome.storage.local.remove("usage");
await loadUsageView();
$("uStatus").textContent = "Usage history cleared.";
$("uStatus").className = "status ok";
});
$("provider").addEventListener("change", showUsageSettings);
chrome.storage.onChanged?.addListener((changes, area) => {
if (area === "local" && (changes.usage || changes.settings)) loadUsageView();
});
$("keysEnabled").addEventListener("change", async () => {
const { settings: stored = {} } = await chrome.storage.local.get("settings");
await chrome.storage.local.set({ settings: { ...stored, shortcuts: $("keysEnabled").checked } });
$("keysStatus").textContent = $("keysEnabled").checked ? "Shortcuts are on." : "Shortcuts are off.";
$("keysStatus").className = "status ok";
});
$("changeKeys").addEventListener("click", (e) => {
e.preventDefault();
if (chrome.tabs?.create) chrome.tabs.create({ url: "chrome://extensions/shortcuts" });
});
async function showSyncLog() {
const { syncLog = [] } = await chrome.storage.local.get("syncLog");
const list = $("ghLog");
if (!syncLog.length) {
list.innerHTML = '<li class="log-empty">Nothing yet. Open a problem with sync turned on.</li>';
return;
}
list.innerHTML = "";
for (const e of syncLog.slice(0, 6)) {
const li = document.createElement("li");
li.className = e.ok ? "log-ok" : "log-bad";
const time = new Date(e.at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
const what = e.ok
? `Saved ${e.target}${e.repo ? ` to ${e.repo}` : ""}${e.label ? ` (${e.label})` : ""}`
: `Couldn't ${e.action} ${e.target}: ${e.error}`;
li.textContent = `${e.ok ? "✓" : "⚠"} ${time} · ${what}`;
list.appendChild(li);
}
}
chrome.storage.onChanged?.addListener((changes, area) => {
if (area === "local" && changes.syncLog) showSyncLog();
});
showSyncLog();
$("ghUpload").addEventListener("click", async () => {
const btn = $("ghUpload");
btn.disabled = true;
ghStatus("Uploading… this makes one commit per problem.", true);
const res = await send({ type: "SYNC_UPLOAD_ALL" });
btn.disabled = false;
if (!res || !res.ok) return ghStatus(res?.error || "No response.", false);
const { uploaded } = res.result;
ghStatus(uploaded ? `Uploaded ${uploaded} problem${uploaded === 1 ? "" : "s"} to GitHub.` : "No saved problems to upload yet.", true);
});
const THEMES = ["auto", "light", "dark"];
function showTheme(theme) {
const t = THEMES.includes(theme) ? theme : "auto";
const radio = document.querySelector(`input[name="theme"][value="${t}"]`);
if (radio) radio.checked = true;
if (t === "auto") document.documentElement.removeAttribute("data-theme");
else document.documentElement.setAttribute("data-theme", t);
}
document.querySelectorAll('input[name="theme"]').forEach((radio) =>
radio.addEventListener("change", async () => {
const theme = radio.value;
settings.theme = theme;
showTheme(theme);
const { settings: stored = {} } = await chrome.storage.local.get("settings");
stored.theme = theme;
await chrome.storage.local.set({ settings: stored });
})
);
chrome.storage.onChanged?.addListener((changes, area) => {
if (area !== "local" || !changes.settings) return;
const theme = changes.settings.newValue?.theme || "auto";
if (theme !== settings.theme) {
settings.theme = theme;
showTheme(theme);
}
});
$("provider").addEventListener("change", () => {
if (lastProvider) stash(lastProvider);
lastProvider = $("provider").value;
showProvider();
showBackupKey();
$("status").textContent = "";
});
$("save").addEventListener("click", async () => {
stash();
settings.provider = $("provider").value;
for (const group of [settings.models, settings.deepModels]) {
for (const k of Object.keys(group)) if (!group[k]) delete group[k];
}
const { settings: stored = {} } = await chrome.storage.local.get("settings");
const { provider, apiKeys, models, deepModels } = settings;
await chrome.storage.local.set({ settings: { ...stored, provider, apiKeys, models, deepModels } });
if (!settings.apiKeys[settings.provider]) setStatus("Saved, but there's no API key for this provider yet.", false);
else setStatus("Settings saved.", true);
});
async function send(msg) {
try {
return await chrome.runtime.sendMessage(msg);
} catch (err) {
return { ok: false, error: err.message || String(err) };
}
}
$("test").addEventListener("click", async () => {
const btn = $("test");
const provider = $("provider").value;
const key = $("apiKey").value.trim();
if (!key) return setStatus("Paste an API key first.", false);
btn.disabled = true;
setStatus("Testing…", true);
const models = [$("model").value.trim() || DEFAULT_MODELS[provider]];
const deep = $("deepModel").value.trim();
if (deep && deep !== models[0]) models.push(deep);
const results = [];
for (const model of models) {
const res = await send({ type: "TEST_CONNECTION", provider, key, model });
results.push(
res && res.ok
? `${model} works (answered in ${(res.result.ms / 1000).toFixed(1)}s)`
: `${model}: ${res?.error || "no response"}`
);
if (!res || !res.ok) {
btn.disabled = false;
const hint = provider === "gemini" && /model/i.test(res?.error || "") ? " Try Find models." : "";
return setStatus(results.join(" · ") + hint, false);
}
}
btn.disabled = false;
setStatus(results.join(" · ") + ". Remember to save.", true);
});
$("findModels").addEventListener("click", async () => {
const btn = $("findModels");
const key = $("apiKey").value.trim();
if (!key) return setStatus("Paste your Gemini API key first.", false);
btn.disabled = true;
const res = await send({ type: "LIST_GEMINI_MODELS", key });
btn.disabled = false;
if (!res || !res.ok) return setStatus(res?.error || "Couldn't list models.", false);
const models = res.result || [];
if (!models.length) return setStatus("Your key has no Gemini text models available.", false);
$("modelList").innerHTML = models.map((m) => `<option value="${m}"></option>`).join("");
if (!$("model").value.trim()) $("model").value = models[0];
setStatus(`Found ${models.length} models. Filled in ${$("model").value}; click the model box to pick another, then save.`, true);
});
$("clear").addEventListener("click", async () => {
if (!confirm("Delete saved hints, test cases, explanations and reviews for every problem? Your API key stays.")) return;
const all = await chrome.storage.local.get(null);
const keys = Object.keys(all).filter((k) => k.startsWith("hints:"));
await chrome.storage.local.remove(keys);
$("clearStatus").textContent = `Cleared ${keys.length} problem${keys.length === 1 ? "" : "s"}.`;
$("clearStatus").className = "status ok";
countHints();
});
init();
