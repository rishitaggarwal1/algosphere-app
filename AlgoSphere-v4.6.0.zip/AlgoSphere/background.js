// AlgoSphere v4.6.0. Copyright 2026 Rishit Aggarwal (https://github.com/rishitaggarwal1). Apache-2.0: see LICENSE and NOTICE.
const DEFAULT_PROVIDER = "gemini";
const DEFAULT_MODELS = {
anthropic: "claude-haiku-5-5",
gemini: "gemini-3.8-flash",
openai: "gpt-5-mini",
};
const DEEP_KINDS = new Set(["approach", "deep", "review", "plan"]);
const HINT_COUNT = 8;
const NO_CODE_RULES = `- Never write code in any programming language, not even pseudocode with syntax.
- Plain text only. You may wrap identifiers or expressions in backticks, like \`nums[i]\` or \`O(n log n)\`.`;
const PROMPTS = {
hints: `You are a patient DSA coach. Given a LeetCode problem, write exactly ${HINT_COUNT} progressive hints that lead a learner to the optimal solution without giving it away early.

Hint 1 (Restate): Restate what the problem is really asking in simpler words. Do not name an algorithm or data structure.
Hint 2 (Observation): Point out something worth noticing in the examples or the structure of the input.
Hint 3 (Constraints): Explain what the input size constraints imply about the target time complexity, and why the obvious brute force is too slow (or fine).
Hint 4 (Pattern): Name the pattern or technique this problem belongs to (for example sliding window, monotonic stack, binary search on the answer, DP on subsequences) and say briefly why it fits.
Hint 5 (Key insight): Give the single idea that makes the optimal approach work.
Hint 6 (Data structure / state): Say exactly what you need to store or track while processing, and what each stored value means.
Hint 7 (Approach): Outline the algorithm as short plain-language steps, one per line, without code.
Hint 8 (Edge cases and complexity): Cover the trickiest step, the edge cases to handle, and the final time and space complexity.

Rules:
- Each hint must reveal more than the one before it and must not repeat it.
- Keep hints 1-6 to one to three sentences. Hint 7 may use up to 7 short lines.
${NO_CODE_RULES}
- Respond with only a JSON object and nothing else: {"hints": ["...", "...", "...", "...", "...", "...", "...", "..."]}`,
tests: `You are a careful competitive programmer writing test cases for a LeetCode problem.

Write exactly 5 normal test cases and 5 to 7 edge test cases.
- Normal cases: typical, varied inputs of small to moderate size that exercise the main logic. Do not copy the problem's own examples.
- Edge cases: boundaries from the constraints (minimum size, maximum or minimum values, negatives, zeros, duplicates, all-equal elements, already-sorted or reverse-sorted input, no valid answer, single element, and so on, whichever apply). Keep every input short enough to read; describe a huge case in the "note" instead of writing it out.

For every case:
- "args": one entry per function parameter, in the order LeetCode's custom testcase box expects. "name" is the parameter name from the examples; "value" is the literal exactly as typed in that box (for example "[2,7,11,15]", "9", "\\"abc\\"", "[[1,2],[3,4]]"). Add "kind" when the parameter is a structure: "tree" (binary tree, level order with null), "linked list", "edges" (graph as an edge list, undirected), "directed edges" or "adjacency" (graph as an adjacency list); leave it out otherwise.
- "output": the expected output, written the way LeetCode displays it.
- "note": one short sentence on what the case tests. For edge cases, start with a short label then a colon, for example "Single element: ...".

Work out every expected output carefully by tracing the problem's rules step by step. Correctness matters more than variety.

Respond with only a JSON object and nothing else:
{"normal": [{"args": [{"name": "nums", "value": "[1,2,3]"}], "output": "6", "note": "..."}], "edge": [ ...same shape... ]}
For a tree parameter an arg looks like {"name": "root", "value": "[3,9,20,null,null,15,7]", "kind": "tree"}.`,
approach: `You are an exceptional DSA teacher. Your goal is that the learner could re-derive the solution to THIS problem on their own next week, and recognise the same idea in new problems. Teach the reasoning, not just the answer.

Everything you write must be specific to this exact problem: use its variable names, its examples and its constraints. Never write generic filler such as "think about the problem carefully" or "consider edge cases". If a sentence would fit any problem, rewrite it or delete it.

Produce a JSON object with these keys:

"oneLiner": the problem restated in one plain sentence, stripped of story.

"pattern": the core pattern or technique, a few words.

"signals": 2 to 4 entries. Each quotes or paraphrases a specific clue in this problem (a phrase, a constraint, an example property) and says what it suggests. Format: "clue → what it suggests".

"constraints": 1 to 3 sentences. Use the actual input limits to estimate how many operations each complexity class would take (for example "n = 10^5: O(n^2) ≈ 10^10, far too slow; O(n log n) ≈ 1.7·10^6, fine"), and conclude what target complexity is needed. If no limits are given, say what is reasonable.

"thinking": 4 to 6 objects {"q": "...", "a": "..."}. This is the train of thought an expert has when first seeing the problem, as questions the learner should ask themself, each answered for THIS problem. Start from the naive view and end at the key insight of the optimal approach. Each answer is 1 to 3 sentences.

"approaches": exactly 3 objects, in order Brute force, Better, Optimal. If there is no natural middle step, use the most instructive intermediate improvement (for example sorting first, or memoised recursion before bottom-up DP). Each object has:
  "level": "Brute force", "Better" or "Optimal"
  "name": short technique name, for example "Hash map of complements"
  "aha": for Brute force, why it is the first thing anyone thinks of; for the others, the exact observation about the previous approach's wasted work that leads to this one (1 to 2 sentences)
  "idea": 3 to 5 sentences explaining how it works and WHY it is correct (the invariant or property it relies on)
  "steps": 4 to 8 plain-language steps
  "time": time complexity, for example "O(n^2)"
  "space": auxiliary space, for example "O(1)"
  "complexity": 2 to 3 sentences: which part of the algorithm dominates the running time and why, and what uses the extra memory
  "tradeoff": for Brute force and Better, the specific bottleneck and why it fails the constraints; for Optimal, why it cannot be beaten or what it trades off

"mistakes": 2 to 4 mistakes learners commonly make on this specific problem, each saying what goes wrong.

"edgeCases": 2 to 5 edge cases worth checking, each with why it matters.

"related": 2 to 4 well-known problems from leetcode.com that use the same idea, as {"title": "...", "slug": "...", "why": "..."} where slug is the URL slug (for example "two-sum"). Only include problems you are certain exist.

"takeaways": 2 to 4 lessons that transfer to other problems.

Rules:
- Plain text only. You may wrap identifiers or expressions in backticks.
- Do not write code here; code comes later.
- Respond with only the JSON object and nothing else.`,
deep: `You are an exceptional DSA teacher preparing a complete deep dive into ONE approach to a LeetCode problem, for a learner who wants to understand it fully. You are given the problem and the approach (its idea, steps and complexity). Stay consistent with that approach: same idea, same complexity.

Produce a JSON object with these keys:

"pseudocode": an array of 10 to 28 strings, one per line. Indent with 2 spaces per level. Language-neutral but precise: declare every variable with its starting value, show every loop with its exact bounds, every condition, every update and every return. Use the keywords function, for, while, if, else, return, and "←" for assignment. End non-obvious lines with a short comment after "//" saying why.

"time": {
  "total": the time complexity, for example "O(n^2)",
  "parts": 2 to 5 objects {"part": "which piece of the pseudocode, with line numbers, e.g. 'Outer loop (lines 2-7)'", "cost": "how many times it runs × cost per run, e.g. 'n iterations × O(1)'", "why": "one sentence"},
  "sum": "how the parts combine into the total, showing the arithmetic, e.g. '(n−1) + (n−2) + … + 1 = n(n−1)/2 = O(n^2); the nested loop dominates the O(n) setup'",
  "cases": "best vs worst case if they differ (with the input that causes each), else an empty string",
  "feel": "what this means for this problem's maximum input, e.g. 'n = 10^4 → about 5·10^7 steps, roughly 0.1 s'"
}

"space": {
  "total": the auxiliary space, for example "O(n)",
  "parts": 1 to 4 objects in the same shape as time.parts,
  "sum": "how they combine",
  "note": "what is not counted (the output, the input) or recursion-stack depth if relevant; else an empty string"
}

"dryRun": an animated trace of the pseudocode on one small input (Example 1 if it has at most 8 elements, otherwise a smaller input of your own):
  "input": the input as text
  "steps": 6 to 16 snapshots in execution order. Each snapshot is the COMPLETE state right after the line runs:
    {
      "line": the pseudocode line number (1-based) that just ran,
      "explain": "1 to 2 sentences: what happened in this step and why, using the actual values",
      "vars": {"name": "value"} all scalar variables currently in scope, values as strings,
      "arrays": {"name": {"values": [...], "pointers": {"i": 0, "j": 3}, "highlight": [0, 3]}} for arrays or strings the algorithm walks (a string becomes an array of characters). "pointers" maps index variables to positions; "highlight" lists positions being compared or updated in this step. For a 2D table (DP grid, matrix), "values" is an array of rows and every pointer and highlight is [row, col].
      "structures": {"name": {"type": "map|set|stack|queue|heap|list", "items": ["..."]}} for other containers. Write map entries as "key→value". A stack's top is the LAST item; a queue's front is the FIRST item.
      "trees": {"name": {"values": ["3", "9", "20", null, null, "15", "7"], "pointers": {"curr": 2}, "highlight": [2], "visited": [0, 1]}} for a binary tree, in LeetCode's level-order format with null for a missing child. Positions count every entry of "values", nulls included, so here "20" is position 2. "highlight" is the node being worked on in this step, "visited" the nodes already finished.
      "lists": {"name": {"values": ["1", "2", "3"], "next": [1, 2, -1], "pointers": {"prev": -1, "curr": 0}, "highlight": [0]}} for a linked list: "values" in the order the nodes were created, "next" the position each node points to right now (-1 for null), so a list being reversed shows its links changing. A pointer at -1 is null.
      "graphs": {"name": {"nodes": ["0", "1", "2"], "edges": [["0", "1"], ["1", "2", "4"]], "directed": false, "pointers": {"u": "1"}, "highlight": ["1"], "visited": ["0"], "activeEdges": [["0", "1"]]}} for a graph: nodes by label, edges as [from, to] or [from, to, weight]. "activeEdges" are the edges being followed in this step.
    }
    When the algorithm works on a tree, a linked list or a graph, show it with "trees", "lists" or "graphs" (not as an array), and move "pointers", "highlight" and "visited" step by step so the learner can watch the traversal.
    Repeat the full current contents in every snapshot, not only what changed. Every value must be exactly what the algorithm really holds at that moment. If the input is long, skip repetitive middle iterations and say so in "explain".
  "result": the final answer and one sentence on why it is correct.

"solution": the complete C++ solution in LeetCode's exact class and method signature for this problem, implementing THIS approach. If a code template from the learner's editor is given, keep its class name, method name, parameter types and return type exactly. Put a comment on every non-trivial line explaining why it is there. Must compile with C++17.

"prelude": the code that goes BEFORE the solution to make it a standalone program: "#include <bits/stdc++.h>", "using namespace std;", plus any type LeetCode defines for this problem (ListNode, TreeNode, Node, and so on) and small helpers to build and print them.

"main": an "int main()" that builds each example from the problem statement, calls the solution, and prints the output next to the expected value.

Rules:
- Use \\n for newlines inside JSON strings.
- Respond with only the JSON object and nothing else.`,
plan: `You are a DSA coach. Before writing any code, a learner has described the approach they plan to use for a LeetCode problem. Judge whether that plan will give correct answers within the problem's constraints, and if not, explain where the thinking goes wrong. Do not give them the solution.

Check three things:
1. Correctness: trace the plan on the examples and on tricky inputs. Look for false assumptions, unsafe greedy choices, missed cases.
2. Efficiency: estimate the operation count at the maximum input size and compare it with what the limits allow.
3. Completeness: if the plan is vague, say exactly which decision is still missing.
Be honest: if the plan is sound, say so clearly and don't invent problems.

Produce a JSON object:
"verdict": one of "will_work", "too_slow", "wont_work", "incomplete"
"summary": one sentence to the learner ("Your plan ...").
"restated": 1 to 2 sentences restating the plan as you understood it.
"strengths": 0 to 3 short things the plan gets right.
"issues": 0 to 4 objects {"title": "...", "explanation": "..."}: each a flaw in the reasoning and why it fails for THIS problem, written to the learner. Empty when the plan is sound.
"counterexample": if the plan gives a wrong answer, a small input that breaks it as {"input": "...", "expected": "...", "planGives": "...", "why": "..."}; otherwise null.
"complexity": {"time": "...", "space": "...", "verdict": "one sentence on whether it fits the constraints, with the operation count"}
"remember": 0 to 4 edge cases or details to handle while coding.
"nudge": 1 to 2 sentences: a question that leads them to fix the plan themself, or, if it works, what to watch while coding.

Rules:
- Never write code, and never describe the full optimal solution.
- Plain text; you may wrap identifiers or expressions in backticks.
- Respond with only the JSON object.`,
review: `You are a senior engineer and DSA coach reviewing a learner's own attempt at a LeetCode problem. Your job is to explain where their THINKING goes wrong, so they learn, rather than to hand them a fixed solution.

You get the problem, the learner's code with line numbers, the language, and optionally a note from them (for example a failing test, an error, or "Time Limit Exceeded").

First, read the code and work out what approach and reasoning the learner had in mind. Then check it against the problem: trace it on the examples and on tricky inputs, and compare its complexity with the constraints. Be honest: if the code is correct and efficient, say so clearly and do not invent problems. If it is unfinished or a template, say what's missing.

Distinguish two kinds of problems:
- Intuition gaps: wrong or incomplete reasoning about the problem (wrong pattern, a false assumption, a missed case in the logic, a greedy choice that is not actually safe, recomputing work the optimal idea avoids, and so on).
- Bugs: the idea is right but the code slips (off-by-one, wrong loop bound, overflow, wrong return, typo).

Produce a JSON object with these keys:
"verdict": one of "correct", "wrong_answer", "too_slow", "partially_correct", "incomplete", "wont_compile"
"summary": one sentence verdict in plain words.
"yourIdea": 1 to 3 sentences describing the approach and intuition the learner's code is following, as you understand it, addressed to them ("You are ...").
"gaps": 0 to 4 objects {"title": "...", "explanation": "...", "lines": "e.g. 7-9 or empty"}. Each explains a flaw in the reasoning, why it is wrong for this problem, and what to think about instead. Write to the learner ("you").
"bugs": 0 to 5 objects {"lines": "...", "issue": "...", "fix": "..."}. "fix" says what to change in one sentence and may include one short code fragment in backticks; never a whole function.
"counterexample": if the code gives a wrong answer, a small input that breaks it as {"input": "...", "expected": "...", "yours": "...", "why": "..."}; otherwise null. Trace the code carefully so "yours" is what it really returns.
"complexity": {"time": "...", "space": "...", "verdict": "one sentence on whether it fits the constraints, with the operation count"}
"nudge": 1 to 3 sentences: the question or hint that would get the learner to fix their thinking themself, without giving the full answer.
"correctIdea": 2 to 4 sentences: the correct intuition for this problem stated plainly (the learner sees this only if they choose to).
"strengths": 0 to 3 short things they got right.

Rules:
- Refer to the learner's code by line numbers from the numbered listing.
- Do not write a full corrected solution anywhere.
- Plain text only; you may wrap identifiers, expressions or tiny code fragments in backticks.
- Respond with only the JSON object and nothing else.`,
};
const PLATFORMS = new Set(["LeetCode", "GeeksforGeeks"]);
const MAX_TOKENS = { hints: 2500, tests: 3000, approach: 6000, deep: 12000, review: 4000, plan: 2500 };
class HintError extends Error {
constructor(message, code) {
super(message);
this.code = code;
}
}
async function getSettings() {
const { settings } = await chrome.storage.local.get("settings");
const s = settings || {};
return {
provider: s.provider || DEFAULT_PROVIDER,
apiKeys: s.apiKeys || {},
models: { ...DEFAULT_MODELS, ...(s.models || {}) },
customModels: s.models || {},
deepModels: s.deepModels || {},
backupModels: s.backupModels || {},
backupProvider: s.backupProvider || "",
speed: SPEED_LEVELS[s.speed] ? s.speed : "balanced",
};
}
function numberLines(code) {
const lines = String(code).replace(/\r\n/g, "\n").split("\n");
const width = String(lines.length).length;
return lines.map((l, i) => `${String(i + 1).padStart(width, " ")} | ${l}`).join("\n");
}
function buildUserPrompt(kind, p, extra = {}) {
const heading = p.difficulty ? `${p.title} (${p.difficulty})` : p.title;
let prompt = `Problem (from ${p.platform || "LeetCode"}): ${heading}\n\n${p.description}`;
if (kind === "deep" && extra.approach) {
const a = extra.approach;
prompt +=
`\n\nApproach to explain: ${a.level} — ${a.name}` +
`\nIdea: ${a.idea}` +
`\nSteps:\n${(a.steps || []).map((s, i) => `${i + 1}. ${s}`).join("\n")}` +
`\nTime: ${a.time}   Space: ${a.space}`;
if (extra.template) {
prompt += `\n\nC++ code template from the learner's editor (match this class and signature exactly):\n${extra.template}`;
}
}
if (kind === "tests" && Array.isArray(extra.inputFields) && extra.inputFields.length) {
prompt +=
`\n\nGeeksforGeeks' Custom Input has one box per parameter:\n` +
extra.inputFields.map((f) => `- ${f.name}${f.sample ? `, for example: ${f.sample}` : ""}`).join("\n") +
`\nIn "args", use exactly these names (without "[]") and write every value in the same format as its example (for instance, no quotes around a string when the example has none).`;
}
if (kind === "plan") {
if (extra.language) prompt += `\n\nLanguage they will code in: ${extra.language}`;
prompt += `\n\nThe learner's planned approach:\n${extra.plan}`;
}
if (kind === "review") {
prompt += `\n\nLanguage: ${extra.language || "unknown"}`;
if (extra.note) prompt += `\n\nLearner's note: ${extra.note}`;
prompt += `\n\nLearner's code (line numbers added for reference):\n${numberLines(extra.code)}`;
}
return prompt;
}
async function readJson(res, name) {
let data = null;
try {
data = await res.json();
} catch (_) {
}
if (!res.ok) {
const detail =
(data && data.error && (data.error.message || data.error.status)) ||
res.statusText ||
"unknown error";
let err;
if (res.status === 401 || res.status === 403 || (res.status === 400 && /api key/i.test(detail))) {
err = new HintError(`${name} rejected the API key. Check it in settings. (${detail})`, "BAD_KEY");
} else if (res.status === 429) {
err = new HintError(`${name} rate limit or quota reached. (${detail})`, "RATE_LIMIT");
} else if (res.status === 404 || /model.*(not found|not supported|does not exist)/i.test(detail)) {
err = new HintError(`${name} doesn't recognise that model name. Update it in settings. (${detail})`, "BAD_MODEL");
} else if ([500, 502, 503, 504, 529].includes(res.status)) {
err = new HintError(`${name} is overloaded or unavailable right now (${res.status}). (${detail})`, "OVERLOADED");
} else {
err = new HintError(`${name} returned error ${res.status}: ${detail}`, "API_ERROR");
}
err.status = res.status;
err.retryAfter = retryAfterMs(res, data);
throw err;
}
return data;
}
function retryAfterMs(res, data) {
const header = Number(res.headers?.get?.("retry-after"));
if (header > 0) return header * 1000;
const info = (data?.error?.details || []).find((d) => d && d.retryDelay);
const secs = parseFloat(String(info?.retryDelay || ""));
return secs > 0 ? secs * 1000 : 0;
}
async function send(url, init, name, signal) {
try {
return await fetch(url, { ...init, signal });
} catch (e) {
if (signal?.aborted) {
const timeout = signal.reason === "timeout";
const err = new HintError(timeout ? `${name} took too long to answer.` : "Cancelled.", timeout ? "TIMEOUT" : "CANCELLED");
throw err;
}
throw new HintError(`Couldn't reach ${name}. Check your connection.`, "NETWORK");
}
}
async function callAnthropic(key, model, system, userPrompt, maxTokens, opts = {}) {
const body = { model, max_tokens: maxTokens, system, messages: [{ role: "user", content: userPrompt }] };
if (opts.level) body.output_config = { effort: opts.level };
const res = await send(
"https://api.anthropic.com/v1/messages",
{
method: "POST",
headers: {
"content-type": "application/json",
"x-api-key": key,
"anthropic-version": "2023-06-01",
"anthropic-dangerous-direct-browser-access": "true",
},
body: JSON.stringify(body),
},
"Anthropic",
opts.signal
);
const data = await readJson(res, "Anthropic");
const text = (data.content || [])
.filter((b) => b.type === "text")
.map((b) => b.text)
.join("");
const u = data.usage || {};
const input = (u.input_tokens || 0) + (u.cache_creation_input_tokens || 0) + (u.cache_read_input_tokens || 0);
return { text, usage: { input, output: u.output_tokens || 0 } };
}
const GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta";
async function callGemini(key, model, system, userPrompt, maxTokens, opts = {}) {
const url = `${GEMINI_BASE}/models/${encodeURIComponent(model.replace(/^models\//, ""))}:generateContent`;
const generationConfig = { responseMimeType: "application/json", maxOutputTokens: maxTokens * 3 };
if (opts.level) generationConfig.thinkingConfig = { thinkingLevel: opts.level };
const res = await send(
url,
{
method: "POST",
headers: { "content-type": "application/json", "x-goog-api-key": key },
body: JSON.stringify({
systemInstruction: { parts: [{ text: system }] },
contents: [{ role: "user", parts: [{ text: userPrompt }] }],
generationConfig,
}),
},
"Gemini",
opts.signal
);
const data = await readJson(res, "Gemini");
const cand = data.candidates?.[0];
if (!cand && data.promptFeedback?.blockReason) {
throw new HintError(`Gemini blocked the request (${data.promptFeedback.blockReason}).`, "API_ERROR");
}
const parts = (cand?.content?.parts || []).filter((p) => !p.thought);
const u = data.usageMetadata || {};
return {
text: parts.map((p) => p.text || "").join(""),
usage: { input: u.promptTokenCount || 0, output: (u.candidatesTokenCount || 0) + (u.thoughtsTokenCount || 0) },
};
}
async function listGeminiModels(key) {
const res = await fetch(`${GEMINI_BASE}/models?pageSize=200`, { headers: { "x-goog-api-key": key } });
const data = await readJson(res, "Gemini");
const version = (n) => parseFloat((n.match(/gemini-(\d+(?:\.\d+)?)/) || [])[1] || "0");
const rank = (n) =>
version(n) * 100 +
(/flash/.test(n) ? 20 : /pro/.test(n) ? 10 : 0) -
(/lite/.test(n) ? 5 : 0) -
(/preview|exp/.test(n) ? 3 : 0);
return (data.models || [])
.filter((m) => (m.supportedGenerationMethods || []).includes("generateContent"))
.map((m) => String(m.name || "").replace(/^models\//, ""))
.filter((n) => /^gemini-/.test(n) && !/(image|tts|audio|live|embedding|vision|robotics|computer-use)/.test(n))
.sort((a, b) => rank(b) - rank(a));
}
async function callOpenAI(key, model, system, userPrompt, maxTokens, opts = {}) {
const limit = opts.cap || maxTokens * 3;
const body = {
model,
messages: [
{ role: "system", content: system },
{ role: "user", content: userPrompt },
],
response_format: { type: "json_object" },
max_completion_tokens: limit,
};
if (opts.level) body.reasoning_effort = opts.level;
const res = await send(
"https://api.openai.com/v1/chat/completions",
{ method: "POST", headers: { "content-type": "application/json", authorization: `Bearer ${key}` }, body: JSON.stringify(body) },
"OpenAI",
opts.signal
);
if (res.status === 400 && !opts.cap) {
const err = await res.clone().json().catch(() => null);
const most = Number((String(err?.error?.message || "").match(/at most (\d+)/) || [])[1]);
if (most > 0 && most < limit) return callOpenAI(key, model, system, userPrompt, maxTokens, { ...opts, cap: most });
}
const data = await readJson(res, "OpenAI");
const u = data.usage || {};
return { text: data.choices?.[0]?.message?.content || "", usage: { input: u.prompt_tokens || 0, output: u.completion_tokens || 0 } };
}
const CALLERS = { anthropic: callAnthropic, gemini: callGemini, openai: callOpenAI };
const CLAUDE_PRICES = {
"claude-haiku-5-5": [0.1, 0.5],
"claude-sonnet-5-5": [2, 10],
"claude-sonnet-5": [2, 10],
"claude-opus-5-5": [4, 20],
"claude-opus-5": [5, 25],
"claude-opus-4-8": [5, 25],
"claude-opus-4-7": [5, 25],
"claude-opus-4-6": [5, 25],
"claude-fable-5-2": [8, 40],
"claude-mythos-5-2": [8, 40],
"claude-fable-5-1": [10, 50],
"claude-mythos-5-1": [10, 50],
"claude-fable-5": [10, 50],
"claude-sonnet-4-6": [3, 15],
"claude-haiku-4-5": [1, 5],
};
function listPrice(model, inputTokens, when = Date.now()) {
const m = String(model || "").toLowerCase().replace(/^models\//, "").replace(/-20\d{6}$/, "");
if (CLAUDE_PRICES[m]) {
if (m === "claude-haiku-5-5" && inputTokens > 100000) return [0.5, 2.5];
return CLAUDE_PRICES[m];
}
if (/^gemini-3\.[678]-flash(?!-lite)/.test(m)) {
return when < Date.UTC(2027, 0, 1) ? [0.75, 3.75] : [1.5, 7.5];
}
if (/^gpt-5-mini/.test(m)) return [0.25, 2];
if (/^gpt-5$/.test(m)) return [1.25, 10];
return null;
}
const USAGE_DEFAULTS = { dailyRequests: 0, dailyBudget: 0, enforce: false, geminiFreeTier: true, prices: {} };
async function getUsageSettings() {
const { settings } = await chrome.storage.local.get("settings");
return { ...USAGE_DEFAULTS, ...(settings?.usage || {}) };
}
const usageDay = (t = Date.now()) => new Date(t).toLocaleDateString("en-CA");
function costOf(provider, model, input, output, us, when = Date.now()) {
const custom = us.prices?.[provider];
const price = custom && (Number(custom.in) > 0 || Number(custom.out) > 0)
? [Number(custom.in) || 0, Number(custom.out) || 0]
: listPrice(model, input, when);
if (!price) return { cost: null, listCost: null, free: false };
const listCost = (input * price[0] + output * price[1]) / 1e6;
const free = provider === "gemini" && us.geminiFreeTier !== false;
return { cost: free ? 0 : listCost, listCost, free };
}
const emptyBucket = () => ({ requests: 0, failed: 0, input: 0, output: 0, cost: 0, listCost: 0, unpriced: 0 });
function addTo(b, e) {
b.requests += 1;
if (!e.ok) b.failed += 1;
b.input += e.input;
b.output += e.output;
if (e.cost == null) {
if (e.ok) b.unpriced += 1;
} else {
b.cost += e.cost;
b.listCost += e.listCost;
}
}
let usageWrites = Promise.resolve();
function recordUsage(entry) {
usageWrites = usageWrites
.catch(() => {})
.then(async () => {
const { usage: stored } = await chrome.storage.local.get("usage");
const usage = stored && stored.days ? stored : { days: {}, recent: [] };
const day = (usage.days[entry.day] ||= { ...emptyBucket(), kinds: {}, models: {} });
addTo(day, entry);
addTo((day.kinds[entry.kind] ||= emptyBucket()), entry);
addTo((day.models[entry.model] ||= emptyBucket()), entry);
usage.recent = [entry, ...(usage.recent || [])].slice(0, 40);
const days = Object.keys(usage.days).sort();
while (days.length > 120) delete usage.days[days.shift()];
await chrome.storage.local.set({ usage });
});
return usageWrites;
}
async function checkUsageLimits() {
const us = await getUsageSettings();
if (!us.enforce) return;
const { usage } = await chrome.storage.local.get("usage");
const today = usage?.days?.[usageDay()];
if (!today) return;
if (us.dailyRequests > 0 && today.requests >= us.dailyRequests) {
throw new HintError(`You've reached today's limit of ${us.dailyRequests} AI requests (set in Settings). It resets at midnight.`, "LIMIT");
}
if (us.dailyBudget > 0 && today.cost >= us.dailyBudget) {
throw new HintError(`You've reached today's budget of $${Number(us.dailyBudget).toFixed(2)} (set in Settings). It resets at midnight.`, "LIMIT");
}
}
function extractJson(text) {
const cleaned = String(text).replace(/^\s*```(?:json)?\s*/i, "").replace(/\s*```\s*$/, "").trim();
const start = cleaned.indexOf("{");
const end = cleaned.lastIndexOf("}");
if (start === -1 || end <= start) return null;
try {
return JSON.parse(cleaned.slice(start, end + 1));
} catch (_) {
return null;
}
}
const str = (v) => (v == null ? "" : typeof v === "string" ? v.trim() : JSON.stringify(v));
const strList = (v) => (Array.isArray(v) ? v.map(str).filter(Boolean) : str(v) ? [str(v)] : []);
const objList = (v) => (Array.isArray(v) ? v.filter((x) => x && typeof x === "object") : []);
function parseHints(obj) {
if (!obj || !Array.isArray(obj.hints) || obj.hints.length < HINT_COUNT) return null;
const hints = obj.hints.slice(0, HINT_COUNT).map(str);
return hints.every(Boolean) ? hints : null;
}
function parseCase(c) {
if (!c || typeof c !== "object") return null;
let args = Array.isArray(c.args) ? c.args : [];
args = args
.map((a) =>
a && typeof a === "object"
? { name: str(a.name), value: str(a.value), ...(str(a.kind) ? { kind: str(a.kind).toLowerCase().slice(0, 30) } : {}) }
: { name: "", value: str(a) }
)
.filter((a) => a.value);
const output = str(c.output);
if (!args.length || !output) return null;
return { args, output, note: str(c.note) };
}
function parseTests(obj) {
if (!obj) return null;
const normal = (Array.isArray(obj.normal) ? obj.normal : []).map(parseCase).filter(Boolean);
const edge = (Array.isArray(obj.edge) ? obj.edge : []).map(parseCase).filter(Boolean);
if (normal.length < 3 || edge.length < 2) return null;
return { normal: normal.slice(0, 5), edge: edge.slice(0, 8) };
}
const cell = (v) => (Array.isArray(v) ? v.map(str) : str(v));
const isPos = (v) => Number.isInteger(v) || (Array.isArray(v) && v.length === 2 && v.every(Number.isInteger));
const toPos = (v) => (typeof v === "string" && /^-?\d+$/.test(v.trim()) ? Number(v) : v);
function parseCostBlock(b) {
if (!b || typeof b !== "object") return null;
const parts = objList(b.parts)
.map((p) => ({ part: str(p.part), cost: str(p.cost), why: str(p.why) }))
.filter((p) => p.part || p.cost);
return {
total: str(b.total),
parts,
sum: str(b.sum),
cases: str(b.cases),
feel: str(b.feel),
note: str(b.note),
};
}
const isNull = (v) => v == null || /^(null|nil|none|n|#)$/i.test(String(v).trim());
const intList = (v) => (Array.isArray(v) ? v.map(toPos).filter(Number.isInteger) : []);
function parseTree(raw) {
const t = Array.isArray(raw) ? { values: raw } : raw && typeof raw === "object" ? raw : null;
if (!t || !Array.isArray(t.values)) return null;
const values = t.values.slice(0, 127).map((v) => (isNull(v) ? null : str(v)));
while (values.length && values[values.length - 1] === null) values.pop();
const node = (i) => Number.isInteger(i) && i >= 0 && i < values.length && values[i] !== null;
const pointers = {};
if (t.pointers && typeof t.pointers === "object") {
for (const [label, pos] of Object.entries(t.pointers)) {
const p = isNull(pos) ? -1 : toPos(pos);
if (p === -1 || node(p)) pointers[label] = p;
}
}
return { values, pointers, highlight: intList(t.highlight).filter(node), visited: intList(t.visited).filter(node) };
}
function parseList(raw) {
const l = Array.isArray(raw) ? { values: raw } : raw && typeof raw === "object" ? raw : null;
if (!l || !Array.isArray(l.values)) return null;
const values = l.values.slice(0, 40).map(str);
const n = values.length;
const inList = (i) => Number.isInteger(i) && i >= 0 && i < n;
const given = Array.isArray(l.next) ? l.next : null;
const next = values.map((_, i) => {
if (!given) return i + 1 < n ? i + 1 : -1;
const p = isNull(given[i]) ? -1 : toPos(given[i]);
return p === -1 || inList(p) ? p : i + 1 < n ? i + 1 : -1;
});
const pointers = {};
if (l.pointers && typeof l.pointers === "object") {
for (const [label, pos] of Object.entries(l.pointers)) {
const p = isNull(pos) ? -1 : toPos(pos);
if (p === -1 || inList(p)) pointers[label] = p;
}
}
return { values, next, pointers, highlight: intList(l.highlight).filter(inList) };
}
function parseGraph(raw) {
const g = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : null;
if (!g) return null;
const nodes = [];
const add = (v) => {
const k = str(v);
if (k && !nodes.includes(k) && nodes.length < 30) nodes.push(k);
return nodes.includes(k) ? k : "";
};
(Array.isArray(g.nodes) ? g.nodes : []).forEach(add);
const edges = [];
for (const e of Array.isArray(g.edges) ? g.edges : []) {
const [a, b, w] = Array.isArray(e) ? e : e && typeof e === "object" ? [e.from ?? e.u, e.to ?? e.v, e.weight ?? e.w] : [];
const from = add(a);
const to = add(b);
if (from && to && edges.length < 80) edges.push([from, to, w == null || w === "" ? "" : str(w)]);
}
if (!nodes.length) return null;
const has = (v) => nodes.includes(str(v));
const pointers = {};
if (g.pointers && typeof g.pointers === "object") {
for (const [label, v] of Object.entries(g.pointers)) if (has(v)) pointers[label] = str(v);
}
const labels = (v) => (Array.isArray(v) ? v.map(str).filter((x) => nodes.includes(x)) : []);
const activeEdges = (Array.isArray(g.activeEdges) ? g.activeEdges : [])
.filter((e) => Array.isArray(e) && has(e[0]) && has(e[1]))
.map((e) => [str(e[0]), str(e[1])]);
return { nodes, edges, directed: g.directed === true || g.directed === "true", pointers, highlight: labels(g.highlight), visited: labels(g.visited), activeEdges };
}
function parseShapes(raw, parse) {
const out = {};
if (raw && typeof raw === "object" && !Array.isArray(raw)) {
for (const [name, v] of Object.entries(raw).slice(0, 4)) {
const shape = parse(v);
if (shape) out[name] = shape;
}
}
return out;
}
function parseStep(s, lineCount) {
if (!s || typeof s !== "object") return null;
const vars = {};
if (s.vars && typeof s.vars === "object") {
for (const [k, v] of Object.entries(s.vars)) vars[k] = str(v);
}
const arrays = {};
if (s.arrays && typeof s.arrays === "object") {
for (const [name, raw] of Object.entries(s.arrays)) {
const a = Array.isArray(raw) ? { values: raw } : raw && typeof raw === "object" ? raw : null;
if (!a || !Array.isArray(a.values)) continue;
const values = a.values.map(cell);
const pointers = {};
if (a.pointers && typeof a.pointers === "object") {
for (const [label, pos] of Object.entries(a.pointers)) {
const p = toPos(pos);
if (isPos(p)) pointers[label] = p;
}
}
const highlight = (Array.isArray(a.highlight) ? a.highlight : []).map(toPos).filter(isPos);
arrays[name] = { values, pointers, highlight };
}
}
const structures = {};
if (s.structures && typeof s.structures === "object") {
for (const [name, raw] of Object.entries(s.structures)) {
const st = Array.isArray(raw) ? { type: "list", items: raw } : raw && typeof raw === "object" ? raw : null;
if (!st) continue;
structures[name] = { type: str(st.type).toLowerCase() || "list", items: (Array.isArray(st.items) ? st.items : []).map(str) };
}
}
let line = parseInt(s.line, 10);
if (!(line >= 1 && line <= lineCount)) line = 0;
return {
line,
explain: str(s.explain),
vars,
arrays,
structures,
trees: parseShapes(s.trees, parseTree),
lists: parseShapes(s.lists, parseList),
graphs: parseShapes(s.graphs, parseGraph),
};
}
function parseDeep(obj) {
if (!obj || typeof obj !== "object") return null;
let pseudocode = Array.isArray(obj.pseudocode) ? obj.pseudocode.map((l) => String(l ?? "").replace(/\s+$/, "")) : [];
if (!pseudocode.length && typeof obj.pseudocode === "string") pseudocode = obj.pseudocode.split("\n");
const dr = obj.dryRun && typeof obj.dryRun === "object" ? obj.dryRun : {};
const steps = (Array.isArray(dr.steps) ? dr.steps : [])
.map((s) => parseStep(s, pseudocode.length))
.filter(Boolean)
.slice(0, 24);
const code = (v) => (typeof v === "string" ? v.replace(/\s+$/, "") : "");
const solution = code(obj.solution);
if (!pseudocode.length || (!steps.length && !solution)) return null;
return {
pseudocode,
time: parseCostBlock(obj.time),
space: parseCostBlock(obj.space),
dryRun: steps.length ? { input: str(dr.input), steps, result: str(dr.result) } : null,
solution,
prelude: code(obj.prelude) || "#include <bits/stdc++.h>\nusing namespace std;",
main: code(obj.main),
};
}
function parseApproach(obj) {
if (!obj || !Array.isArray(obj.approaches)) return null;
const approaches = obj.approaches
.map((a) =>
a && typeof a === "object"
? {
level: str(a.level),
name: str(a.name),
aha: str(a.aha),
idea: str(a.idea),
steps: strList(a.steps),
time: str(a.time),
space: str(a.space),
complexity: str(a.complexity),
tradeoff: str(a.tradeoff),
}
: null
)
.filter((a) => a && a.idea && a.time && a.space);
if (approaches.length < 2) return null;
const defaultLevels = ["Brute force", "Better", "Optimal"];
approaches.slice(0, 3).forEach((a, i) => (a.level = a.level || defaultLevels[i]));
const thinking = objList(obj.thinking)
.map((t) => ({ q: str(t.q || t.question), a: str(t.a || t.answer) }))
.filter((t) => t.q && t.a);
const intuition = strList(obj.intuition);
if (!thinking.length && !intuition.length) return null;
return {
version: 3,
oneLiner: str(obj.oneLiner),
pattern: str(obj.pattern),
signals: strList(obj.signals),
constraints: str(obj.constraints),
thinking,
intuition,
approaches: approaches.slice(0, 3),
mistakes: strList(obj.mistakes),
edgeCases: strList(obj.edgeCases),
related: objList(obj.related)
.map((r) => ({ title: str(r.title), slug: str(r.slug).toLowerCase(), why: str(r.why) }))
.filter((r) => r.title && /^[a-z0-9-]+$/.test(r.slug))
.slice(0, 4),
takeaways: strList(obj.takeaways),
};
}
const VERDICTS = ["correct", "wrong_answer", "too_slow", "partially_correct", "incomplete", "wont_compile"];
function parseReview(obj) {
if (!obj || typeof obj !== "object") return null;
const verdict = str(obj.verdict).toLowerCase().replace(/[\s-]+/g, "_");
const summary = str(obj.summary);
if (!summary) return null;
const ce = obj.counterexample && typeof obj.counterexample === "object" ? obj.counterexample : null;
const cx = obj.complexity && typeof obj.complexity === "object" ? obj.complexity : {};
return {
verdict: VERDICTS.includes(verdict) ? verdict : "partially_correct",
summary,
yourIdea: str(obj.yourIdea),
gaps: objList(obj.gaps)
.map((g) => ({ title: str(g.title), explanation: str(g.explanation), lines: str(g.lines) }))
.filter((g) => g.explanation),
bugs: objList(obj.bugs)
.map((b) => ({ lines: str(b.lines), issue: str(b.issue), fix: str(b.fix) }))
.filter((b) => b.issue),
counterexample:
ce && str(ce.input)
? { input: str(ce.input), expected: str(ce.expected), yours: str(ce.yours), why: str(ce.why) }
: null,
complexity: { time: str(cx.time), space: str(cx.space), verdict: str(cx.verdict) },
nudge: str(obj.nudge),
correctIdea: str(obj.correctIdea),
strengths: strList(obj.strengths),
};
}
const PLAN_VERDICTS = ["will_work", "too_slow", "wont_work", "incomplete"];
function parsePlan(obj) {
if (!obj || typeof obj !== "object") return null;
const summary = str(obj.summary);
if (!summary) return null;
const verdict = str(obj.verdict).toLowerCase().replace(/[\s-]+/g, "_");
const ce = obj.counterexample && typeof obj.counterexample === "object" ? obj.counterexample : null;
const cx = obj.complexity && typeof obj.complexity === "object" ? obj.complexity : {};
return {
verdict: PLAN_VERDICTS.includes(verdict) ? verdict : "incomplete",
summary,
restated: str(obj.restated),
strengths: strList(obj.strengths),
issues: objList(obj.issues)
.map((x) => ({ title: str(x.title), explanation: str(x.explanation) }))
.filter((x) => x.explanation),
counterexample:
ce && str(ce.input)
? { input: str(ce.input), expected: str(ce.expected), planGives: str(ce.planGives), why: str(ce.why) }
: null,
complexity: { time: str(cx.time), space: str(cx.space), verdict: str(cx.verdict) },
remember: strList(obj.remember),
nudge: str(obj.nudge),
};
}
const PARSERS = { hints: parseHints, tests: parseTests, approach: parseApproach, deep: parseDeep, review: parseReview, plan: parsePlan };
async function recoverGeminiModel(settings, key, failedModel) {
let models = [];
try {
models = await listGeminiModels(key);
} catch (_) {
return null;
}
const pick = models.find((m) => m !== failedModel);
if (!pick) return null;
const { settings: saved = {} } = await chrome.storage.local.get("settings");
saved.models = { ...(saved.models || {}), gemini: pick };
await chrome.storage.local.set({ settings: saved });
return pick;
}
const SPEED_LEVELS = {
fast: { hints: "low", tests: "low", plan: "low", approach: "low", review: "low", deep: "medium" },
balanced: { hints: "low", tests: "low", plan: "low", approach: "medium", review: "medium", deep: "medium" },
thorough: { hints: "medium", tests: "high", plan: "medium", approach: "high", review: "high", deep: "high" },
};
const TIMEOUT_MS = { hints: 45000, tests: 60000, plan: 45000, review: 90000, approach: 90000, deep: 150000, test: 20000 };
const MAX_ATTEMPTS = 3;
const BREAKER_MS = 2 * 60 * 1000;
const tuning = () => ({
retryBase: globalThis.__LCHL_RETRY_BASE_MS || 1000,
timeoutScale: globalThis.__LCHL_TIMEOUT_MS || 0,
});
function backoffMs(attempt, retryAfter) {
if (retryAfter > 0) return Math.min(retryAfter, 15000);
const base = tuning().retryBase * 2 ** (attempt - 1);
return Math.min(8000, Math.round(base * (0.5 + Math.random())));
}
function classify(err) {
if (err.code === "CANCELLED") return "fatal";
if (err.code === "TIMEOUT") return "next";
if (err.code === "NETWORK" || err.code === "OVERLOADED" || err.status === 408) return "retry";
if (err.status === 429) return err.retryAfter > 0 && err.retryAfter <= 15000 ? "retry" : "next";
return "fatal";
}
const sleepFor = (ms, signal) =>
new Promise((resolve, reject) => {
const t = setTimeout(resolve, ms);
signal?.addEventListener("abort", () => {
clearTimeout(t);
reject(new HintError("Cancelled.", "CANCELLED"));
});
});
const breaker = new Map();
const routeKey = (r) => `${r.provider}:${r.model}`;
const breakerOpen = (r) => (breaker.get(routeKey(r)) || 0) > Date.now();
let noLevelModels = null;
async function modelsWithoutLevel() {
if (!noLevelModels) {
const { modelCaps } = await chrome.storage.local.get("modelCaps");
noLevelModels = new Set(modelCaps?.noLevel || []);
}
return noLevelModels;
}
const LEVEL_PARAM = { gemini: /thinking/i, anthropic: /effort|output_config/i, openai: /reasoning/i };
async function callWithLevel(route, system, userPrompt, maxTokens, opts) {
const noLevel = await modelsWithoutLevel();
const id = routeKey(route);
const level = noLevel.has(id) ? null : opts.level;
try {
return await CALLERS[route.provider](route.key, route.model, system, userPrompt, maxTokens, { ...opts, level });
} catch (err) {
if (level && err.status === 400 && LEVEL_PARAM[route.provider].test(err.message)) {
noLevel.add(id);
chrome.storage.local.set({ modelCaps: { noLevel: [...noLevel] } }).catch(() => {});
return CALLERS[route.provider](route.key, route.model, system, userPrompt, maxTokens, { ...opts, level: null });
}
throw err;
}
}
async function meteredCall(route, ctx, system, userPrompt, maxTokens, opts = {}) {
const started = Date.now();
const us = await getUsageSettings();
const ctl = new AbortController();
const onCancel = () => ctl.abort("cancelled");
if (opts.signal?.aborted) onCancel();
opts.signal?.addEventListener("abort", onCancel);
const timer = setTimeout(() => ctl.abort("timeout"), tuning().timeoutScale || TIMEOUT_MS[ctx.kind] || 60000);
const base = { at: started, day: usageDay(started), kind: ctx.kind, provider: route.provider, model: route.model, title: ctx.title || "", site: ctx.site || "" };
try {
const r = await callWithLevel(route, system, userPrompt, maxTokens, { level: opts.level, signal: ctl.signal });
const { input, output } = r.usage || { input: 0, output: 0 };
recordUsage({ ...base, ok: true, input, output, ms: Date.now() - started, ...costOf(route.provider, route.model, input, output, us, started) });
return r.text;
} catch (err) {
recordUsage({ ...base, ok: false, input: 0, output: 0, ms: Date.now() - started, cost: 0, listCost: 0, free: false, error: err.message || String(err) });
throw err;
} finally {
clearTimeout(timer);
opts.signal?.removeEventListener("abort", onCancel);
}
}
const PROVIDER_NAMES = { gemini: "Gemini", anthropic: "Claude", openai: "OpenAI" };
async function cachedGeminiModels(key) {
const { geminiModels } = await chrome.storage.local.get("geminiModels");
if (geminiModels?.list?.length && Date.now() - geminiModels.at < 12 * 3600000) return geminiModels.list;
const list = await listGeminiModels(key).catch(() => []);
if (list.length) chrome.storage.local.set({ geminiModels: { at: Date.now(), list } }).catch(() => {});
return list;
}
async function autoBackupModel(provider, key, primary) {
if (provider === "gemini") {
const list = await cachedGeminiModels(key);
return list.find((m) => m !== primary && /flash/.test(m)) || list.find((m) => m !== primary) || null;
}
if (provider === "anthropic") return primary === "claude-haiku-5-5" ? "claude-sonnet-5-5" : "claude-haiku-5-5";
return null;
}
async function buildRoutes(settings, kind, primaryModel) {
const provider = settings.provider;
const key = (settings.apiKeys[provider] || "").trim();
const routes = [{ provider, key, model: primaryModel, primary: true }];
const chosen = (settings.backupModels[provider] || "").trim();
const backup = chosen || (await autoBackupModel(provider, key, primaryModel));
if (backup && backup !== primaryModel) routes.push({ provider, key, model: backup });
const bp = settings.backupProvider;
const bpKey = (settings.apiKeys[bp] || "").trim();
if (bp && bp !== provider && CALLERS[bp] && bpKey) {
routes.push({ provider: bp, key: bpKey, model: (settings.models[bp] || DEFAULT_MODELS[bp]).trim() });
}
return routes;
}
const routeLabel = (r) => `${PROVIDER_NAMES[r.provider]} (${r.model})`;
async function generate(kind, problem, extra, report = () => {}, signal) {
if (!PROMPTS[kind]) throw new HintError(`Unknown request "${kind}".`, "API_ERROR");
const settings = await getSettings();
const provider = settings.provider;
const key = (settings.apiKeys[provider] || "").trim();
let model = (settings.models[provider] || DEFAULT_MODELS[provider]).trim();
const deep = (settings.deepModels[provider] || "").trim();
const useDeep = DEEP_KINDS.has(kind) && deep;
if (useDeep) model = deep;
if (!key) throw new HintError("Add an API key in settings to use the assistant.", "NO_KEY");
if (!CALLERS[provider]) throw new HintError(`Unknown provider "${provider}".`, "API_ERROR");
await checkUsageLimits();
const userPrompt = buildUserPrompt(kind, problem, extra);
const ctx = { kind, title: problem.title, site: problem.platform };
const platform = PLATFORMS.has(problem.platform) ? problem.platform : "LeetCode";
const systemPrompt = PROMPTS[kind].split("LeetCode").join(platform);
const level = (SPEED_LEVELS[settings.speed] || SPEED_LEVELS.balanced)[kind] || null;
const routes = await buildRoutes(settings, kind, model);
const ordered = [...routes.filter((r) => !breakerOpen(r)), ...routes.filter(breakerOpen)];
if (ordered[0] !== routes[0]) report({ type: "skip", from: routeLabel(routes[0]), to: routeLabel(ordered[0]) });
let lastErr = null;
let tries = 0;
for (let ri = 0; ri < ordered.length; ri++) {
const route = ordered[ri];
let formatRetried = false;
let recovered = false;
for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
tries++;
let text;
try {
text = await meteredCall(route, ctx, systemPrompt, userPrompt, MAX_TOKENS[kind], { level, signal });
} catch (err) {
if (err.code === "BAD_MODEL" && route.primary && route.provider === "gemini" && !useDeep && !recovered) {
const next = await recoverGeminiModel(settings, route.key, route.model);
if (next) {
route.model = next;
recovered = true;
attempt--;
continue;
}
}
const action = classify(err);
if (action === "fatal") throw err;
lastErr = err;
if (action === "retry" && attempt < MAX_ATTEMPTS) {
const waitMs = backoffMs(attempt, err.retryAfter);
report({ type: "retry", provider: PROVIDER_NAMES[route.provider], model: route.model, status: err.status || err.code, attempt: attempt + 1, max: MAX_ATTEMPTS, waitMs });
await sleepFor(waitMs, signal);
continue;
}
breaker.set(routeKey(route), Date.now() + BREAKER_MS);
break;
}
breaker.delete(routeKey(route));
const result = PARSERS[kind](extractJson(text));
if (result) return result;
lastErr = new HintError("The AI reply wasn't in the expected format. Try again.", "BAD_FORMAT");
if (formatRetried) break;
formatRetried = true;
attempt--;
}
const next = ordered[ri + 1];
if (next) report({ type: "fallback", from: routeLabel(route), to: routeLabel(next), reason: lastErr?.code === "TIMEOUT" ? "took too long" : lastErr?.status ? `returned ${lastErr.status}` : "failed" });
}
if (lastErr && ["OVERLOADED", "TIMEOUT", "NETWORK", "RATE_LIMIT"].includes(lastErr.code)) {
const name = PROVIDER_NAMES[provider];
const what = lastErr.code === "TIMEOUT" ? "isn't answering in time" : lastErr.code === "NETWORK" ? "can't be reached" : "is overloaded right now";
const backups = ordered.length > 1 ? ` and ${ordered.length - 1} backup${ordered.length > 2 ? "s" : ""}` : "";
const tip = settings.backupProvider ? "" : " You can add a backup provider in Settings.";
const err = new HintError(`${name} ${what} (tried ${tries} time${tries === 1 ? "" : "s"}${backups}). Try again in a minute.${tip}`, "OVERLOADED");
err.status = lastErr.status;
throw err;
}
throw lastErr || new HintError("The AI reply wasn't in the expected format. Try again.", "BAD_FORMAT");
}
async function testConnection({ provider, key, model }) {
if (!CALLERS[provider]) throw new HintError(`Unknown provider "${provider}".`, "API_ERROR");
if (!key) throw new HintError("Paste an API key first.", "NO_KEY");
const m = model || DEFAULT_MODELS[provider];
const started = Date.now();
const text = await meteredCall({ provider, key, model: m }, { kind: "test", title: "Settings: test connection" }, 'Reply with only this JSON: {"ok": true}', "ping", 200, { level: "low" });
if (!extractJson(text)) throw new HintError(`Connected, but ${m} replied in an unexpected format.`, "BAD_FORMAT");
return { model: m, ms: Date.now() - started };
}
const jobs = new Map();
function startJob(msg) {
const shareable = ["hints", "tests", "approach", "deep"].includes(msg.kind);
const id = shareable ? JSON.stringify([msg.kind, msg.problem?.platform, msg.problem?.slug, msg.extra?.approach?.name || ""]) : `${Math.random()}`;
if (jobs.has(id)) return jobs.get(id);
const job = { id, ports: new Set(), controller: new AbortController(), last: null };
job.report = (p) => {
job.last = p;
for (const port of job.ports) safePost(port, { type: "progress", event: p });
};
job.promise = generate(msg.kind, msg.problem, msg.extra, job.report, job.controller.signal).finally(() => jobs.delete(id));
jobs.set(id, job);
return job;
}
function safePost(port, m) {
try {
port.postMessage(m);
} catch (_) {
}
}
chrome.runtime.onConnect.addListener((port) => {
if (port.name !== "generate") return;
port.onMessage.addListener(async (msg) => {
if (msg?.type !== "GENERATE") return;
const job = startJob(msg);
job.ports.add(port);
if (job.last) safePost(port, { type: "progress", event: job.last });
port.onDisconnect.addListener(() => {
job.ports.delete(port);
if (!job.ports.size) job.controller.abort("cancelled");
});
try {
safePost(port, { type: "done", ok: true, result: await job.promise });
} catch (err) {
safePost(port, { type: "done", ok: false, error: err.message || String(err), code: err.code || "API_ERROR" });
}
});
});
const reply = (sendResponse) => [
(result) => sendResponse({ ok: true, result }),
(err) =>
sendResponse({
ok: false,
error: err.message || String(err),
code: err.code || (err instanceof TypeError ? "NETWORK" : "API_ERROR"),
...(err.retryAfter > 0 ? { retryAfter: err.retryAfter } : {}),
}),
];
if (typeof importScripts === "function") importScripts("notes-markdown.js");
const GITHUB_API = "https://api.github.com";
const SYNC_SECTIONS = ["hints", "tests", "customTests", "approach", "review", "reviewFor", "mySolutions"];
const SITE_FOLDERS = { leetcode: "leetcode", gfg: "gfg" };
const NOTES_FORMAT = 2;
class SyncError extends Error {
constructor(message, code) {
super(message);
this.code = code;
}
}
const PLACEHOLDER_OWNERS = new Set(["owner", "your-username", "username"]);
function parseRepo(value) {
let v = String(value || "").trim();
let parts;
const gh = v.match(/^(?:https?:\/\/)?(?:www\.)?github\.com\/(.*)$/i) || v.match(/^git@github\.com:(.*)$/i);
if (gh) parts = gh[1].split(/[/?#]/).filter(Boolean).slice(0, 2);
else parts = v.replace(/\/+$/, "").split("/");
parts = parts.map((x) => x.replace(/\.git$/i, ""));
const ok = (x) => /^[A-Za-z0-9._-]+$/.test(x || "");
if (parts.length === 2 && /^[A-Za-z0-9-]+$/.test(parts[0]) && ok(parts[1])) {
return { owner: PLACEHOLDER_OWNERS.has(parts[0].toLowerCase()) ? null : parts[0], repo: parts[1] };
}
return parts.length === 1 && ok(parts[0]) ? { owner: null, repo: parts[0] } : null;
}
const tokenLogins = new Map();
async function fillOwner(g) {
if (!g.repo || g.repo.owner || !g.token) return g;
if (!tokenLogins.has(g.token)) {
const me = await github(g, "GET", "/user");
tokenLogins.set(g.token, me.login);
}
g.repo = { ...g.repo, owner: tokenLogins.get(g.token) };
g.repoText = `${g.repo.owner}/${g.repo.repo}`;
return g;
}
function cleanFolder(folder) {
return String(folder ?? "dsa-notes")
.split("/")
.map((p) => p.trim())
.filter((p) => p && p !== "." && p !== "..")
.join("/");
}
async function getGithubSettings(override) {
const { settings } = await chrome.storage.local.get("settings");
const g = { ...(settings?.github || {}), ...(override || {}) };
const out = {
enabled: !!g.enabled,
token: String(g.token || "").trim(),
repo: parseRepo(g.repo),
repoText: String(g.repo || "").trim(),
branch: String(g.branch || "").trim(),
folder: cleanFolder(g.folder),
includeSolutions: g.includeSolutions !== false,
};
if (out.repo?.owner) out.repoText = `${out.repo.owner}/${out.repo.repo}`;
return out;
}
const CREDIT_NAME = "Rishit Aggarwal";
const CREDIT_COMMIT = `Saved with AlgoSphere by ${CREDIT_NAME} (https://github.com/rishitaggarwal1)`;
const CREDIT_FOOTER =
`---\n\n<sub>Notes made with **AlgoSphere**, designed and built by **${CREDIT_NAME}** · ` +
`[LinkedIn](https://www.linkedin.com/in/rishit-aggarwal/) · [GitHub](https://github.com/rishitaggarwal1) · [Medium](https://medium.com/@rishitaggarwal1)</sub>\n`;
const withCredit = (md) => (String(md).includes(CREDIT_NAME) ? String(md) : `${String(md).replace(/\s*$/, "")}\n\n${CREDIT_FOOTER}`);
const creditCommit = (message) => `${message}\n\n${CREDIT_COMMIT}`;
async function logSync(entry) {
try {
const { syncLog = [] } = await chrome.storage.local.get("syncLog");
syncLog.unshift({ at: Date.now(), ...entry });
await chrome.storage.local.set({ syncLog: syncLog.slice(0, 8) });
} catch (_) {
}
}
function toBase64(text) {
const bytes = new TextEncoder().encode(text);
let bin = "";
for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
return btoa(bin);
}
function fromBase64(b64) {
const bin = atob(String(b64).replace(/\s/g, ""));
return new TextDecoder().decode(Uint8Array.from(bin, (c) => c.charCodeAt(0)));
}
const GITHUB_TRIES = 3;
const GITHUB_TIMEOUT_MS = 20000;
const tokenExpiry = new Map();
async function github(g, method, path, body) {
for (let attempt = 1; ; attempt++) {
try {
return await githubOnce(g, method, path, body);
} catch (err) {
if (!err.transient || attempt >= GITHUB_TRIES) throw err;
const base = (globalThis.__LCHL_GH_RETRY_MS || 1000) * 2 ** (attempt - 1);
const wait = err.retryAfter != null ? err.retryAfter : base / 2 + (Math.random() * base) / 2;
if (wait > 20000) throw err;
await new Promise((r) => setTimeout(r, wait));
}
}
}
async function githubOnce(g, method, path, body) {
const ctrl = new AbortController();
const timer = setTimeout(() => ctrl.abort(), globalThis.__LCHL_GH_TIMEOUT_MS || GITHUB_TIMEOUT_MS);
let res;
let data = null;
try {
res = await fetch(`${GITHUB_API}${path}`, {
method,
cache: "no-store",
signal: ctrl.signal,
headers: {
accept: "application/vnd.github+json",
authorization: `Bearer ${g.token}`,
"x-github-api-version": "2022-11-28",
...(body ? { "content-type": "application/json" } : {}),
},
body: body ? JSON.stringify(body) : undefined,
});
try {
data = await res.json();
} catch (err) {
if (ctrl.signal.aborted) throw err;
}
} catch (_) {
const slow = ctrl.signal.aborted;
throw Object.assign(
new SyncError(slow ? "GitHub took too long to answer." : "Couldn't reach GitHub. Check your connection.", slow ? "TIMEOUT" : "NETWORK"),
{ transient: true }
);
} finally {
clearTimeout(timer);
}
const header = (name) => (res.headers && res.headers.get ? res.headers.get(name) : null);
const expires = header("github-authentication-token-expiration");
if (expires) tokenExpiry.set(g.token, expires);
if (res.ok) return data;
const detail = data?.message || res.statusText || "unknown error";
const err = new SyncError(`GitHub: ${detail}`, "GITHUB");
err.status = res.status;
const retryAfter = Number(header("retry-after")) || 0;
const remaining = header("x-ratelimit-remaining");
const reset = Number(header("x-ratelimit-reset")) * 1000 || 0;
const limited = (res.status === 403 || res.status === 429) && (/rate limit/i.test(detail) || retryAfter > 0 || remaining === "0");
if (res.status === 401) {
err.message = "GitHub rejected the token: it has expired or was revoked. Create a new one and paste it in Settings.";
err.code = "BAD_TOKEN";
} else if (limited) {
err.code = "RATE_LIMIT";
err.transient = true;
if (retryAfter > 0) err.retryAfter = retryAfter * 1000;
else if (remaining === "0" && reset > Date.now()) err.retryAfter = reset - Date.now();
else err.retryAfter = 60000;
err.message =
err.retryAfter > 5 * 60000
? `GitHub's hourly limit for this token is used up. Saving works again at ${new Date(Date.now() + err.retryAfter).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}.`
: "GitHub asked to slow down for a moment. Saving will try again shortly.";
} else if (res.status === 403) {
err.message = `The token can't write to ${g.repoText}. Give it "Contents: Read and write" access to that repository.`;
err.code = "NO_ACCESS";
} else if (res.status >= 500 || res.status === 408) {
err.code = "GITHUB_DOWN";
err.transient = true;
err.message = `GitHub is having trouble right now (error ${res.status}). Saving will try again shortly.`;
}
throw err;
}
const repoPath = (g) => `/repos/${g.repo.owner}/${g.repo.repo}`;
const joinPath = (...parts) => parts.filter(Boolean).join("/");
const encodePath = (path) => path.split("/").map(encodeURIComponent).join("/");
function problemDir(g, site, slug) {
const safeSlug = String(slug).replace(/[^A-Za-z0-9._-]/g, "-");
return joinPath(g.folder, SITE_FOLDERS[site] || "other", safeSlug);
}
const notesPath = (g, site, slug) => `${problemDir(g, site, slug)}/notes.json`;
const legacyPath = (g, site, slug) => `${problemDir(g, site, slug)}.json`;
const indexReadmePath = (g) => joinPath(g.folder, g.folder ? "README.md" : "PROBLEMS.md");
const indexDataPath = (g) => joinPath(g.folder, ".notes-index.json");
function requireReady(g) {
if (!g.enabled) return false;
if (!g.token || !g.repo) throw new SyncError("GitHub sync is on, but the repository or token is missing in settings.", "NOT_SET_UP");
return true;
}
async function readText(g, path, ref) {
try {
const file = await github(g, "GET", `${repoPath(g)}/contents/${encodePath(path)}${ref ? `?ref=${encodeURIComponent(ref)}` : ""}`);
if (!file || Array.isArray(file) || typeof file.content !== "string") return null;
if (!file.content && file.size > 0 && file.sha) {
const blob = await github(g, "GET", `${repoPath(g)}/git/blobs/${file.sha}`);
return fromBase64(blob?.content || "");
}
return fromBase64(file.content);
} catch (err) {
if (err.status === 404) return null;
throw err;
}
}
async function readProblemFile(g, site, slug) {
for (const [path, legacy] of [
[notesPath(g, site, slug), false],
[legacyPath(g, site, slug), true],
]) {
const text = await readText(g, path, g.branch);
if (text == null) continue;
try {
return { data: JSON.parse(text), legacy, path };
} catch (_) {
}
}
return null;
}
const defaultBranches = new Map();
async function repoInfo(g) {
try {
return await github(g, "GET", repoPath(g));
} catch (err) {
if (err.status === 404) throw new SyncError(`Repository ${g.repoText} not found, or the token can't see it.`, "NO_REPO");
throw err;
}
}
async function targetBranch(g) {
if (g.branch) return g.branch;
const key = `${g.repo.owner}/${g.repo.repo}`;
if (!defaultBranches.has(key)) defaultBranches.set(key, (await repoInfo(g)).default_branch || "main");
return defaultBranches.get(key);
}
async function branchHead(g, branch) {
try {
const ref = await github(g, "GET", `${repoPath(g)}/git/ref/heads/${encodePath(branch)}`);
const commit = await github(g, "GET", `${repoPath(g)}/git/commits/${ref.object.sha}`);
return { commitSha: ref.object.sha, treeSha: commit.tree.sha };
} catch (err) {
if (err.status === 409 || (err.status === 404 && (await repoInfo(g)).size === 0)) {
await github(g, "PUT", `${repoPath(g)}/contents/${encodePath(indexReadmePath(g))}`, {
message: creditCommit("Start DSA notes"),
content: toBase64(withCredit(buildIndexReadme({}, "DSA Notes"))),
...(g.branch ? { branch: g.branch } : {}),
});
return branchHead(g, branch);
}
if (err.status === 404) {
throw new SyncError(`Branch "${branch}" doesn't exist in ${g.repoText}. Create it, or leave Branch empty to use the default branch.`, "NO_BRANCH");
}
throw err;
}
}
async function syncLoad(site, slug) {
const g = await getGithubSettings();
if (!requireReady(g)) return { disabled: true };
try {
await fillOwner(g);
const file = await readProblemFile(g, site, slug);
const tokenExpires = tokenExpiry.get(g.token) || null;
const where = { repo: g.repoText, branch: await targetBranch(g), dir: problemDir(g, site, slug) };
if (file) return { found: true, data: file.data, path: file.path, tokenExpires, ...where };
await repoInfo(g);
return { found: false, tokenExpires: tokenExpiry.get(g.token) || null, ...where };
} catch (err) {
await logSync({ ok: false, action: "load", target: `${site}/${slug}`, repo: g.repoText, error: err.message });
throw err;
}
}
let writeQueue = Promise.resolve();
function syncSave(site, slug, record, label, mode) {
const next = writeQueue
.catch(() => {})
.then(() => writeProblem(site, slug, record, label, mode))
.then(
async (res) => {
if (res && !res.disabled && !res.unchanged) await logSync({ ok: true, action: "save", target: res.path, repo: res.repo, label });
return res;
},
async (err) => {
await logSync({ ok: false, action: "save", target: `${site}/${slug}`, error: err.message });
throw err;
}
);
writeQueue = next;
return next;
}
function sameContent(a, b) {
return SYNC_SECTIONS.every((k) => JSON.stringify(a?.[k] ?? null) === JSON.stringify(b?.[k] ?? null));
}
function orderKeys(o) {
const first = ["format", "site", "slug", "title", "url", "updatedAt", "problem"];
const out = {};
for (const k of first) if (k in o) out[k] = o[k];
for (const k of Object.keys(o)) if (!(k in out)) out[k] = o[k];
return out;
}
function mergeApproach(incoming, existing) {
const shape = (a) => JSON.stringify((a?.approaches || []).map((x) => [x.level, x.name, x.idea, x.time, x.space]));
if (!existing || shape(incoming) !== shape(existing)) return incoming;
return {
...incoming,
approaches: incoming.approaches.map((x, i) => (x.deep || !existing.approaches[i]?.deep ? x : { ...x, deep: existing.approaches[i].deep })),
};
}
function mergeSolutions(incoming, existing) {
const all = [...(incoming || []), ...(existing || [])];
const seen = new Set();
return all
.filter((s) => s && !seen.has(s.code) && seen.add(s.code))
.sort((a, b) => String(b.acceptedAt).localeCompare(String(a.acceptedAt)))
.slice(0, 5);
}
async function writeProblem(site, slug, record, label, mode) {
const g = await getGithubSettings();
if (!requireReady(g)) return { disabled: true };
await fillOwner(g);
const dir = problemDir(g, site, slug);
const branch = await targetBranch(g);
for (let attempt = 0; attempt < 3; attempt++) {
const existing = await readProblemFile(g, site, slug);
const merged = { ...(existing?.data || {}) };
for (const k of SYNC_SECTIONS) {
if (k === "mySolutions" && !g.includeSolutions) continue;
if (record[k] == null) continue;
if (mode === "fill" && merged[k] != null) continue;
if (k === "approach") merged[k] = mergeApproach(record[k], merged[k]);
else if (k === "mySolutions") merged[k] = mergeSolutions(record[k], merged[k]);
else merged[k] = record[k];
}
if (record.problem?.description) merged.problem = record.problem;
else if (record.problem?.difficulty) merged.problem = { ...(merged.problem || {}), difficulty: record.problem.difficulty };
Object.assign(merged, {
format: NOTES_FORMAT,
site,
slug,
title: record.title || merged.title || slug,
url: problemUrl(site, slug),
updatedAt: new Date().toISOString(),
});
if (existing && !existing.legacy && sameContent(existing.data, merged) && !record.force) {
return { ok: true, path: dir, unchanged: true, repo: g.repoText, branch, mine: existing.data.mySolutions?.[0] ? mySolutionName(existing.data.mySolutions[0]) : "" };
}
const notes = orderKeys(merged);
const indexText = await readText(g, indexDataPath(g), branch);
let index = {};
try {
index = indexText ? JSON.parse(indexText) : {};
} catch (_) {
index = {};
}
index[`${site}/${slug}`] = noteIndexEntry(notes, `${SITE_FOLDERS[site] || "other"}/${dir.split("/").pop()}`);
const files = [
{ path: `${dir}/README.md`, content: withCredit(buildProblemReadme(notes)) },
{ path: `${dir}/notes.json`, content: JSON.stringify(notes, null, 2) + "\n" },
{ path: indexReadmePath(g), content: withCredit(buildIndexReadme(index, "DSA Notes")) },
{ path: indexDataPath(g), content: JSON.stringify(index, null, 2) + "\n" },
];
const cpp = buildSolutionCpp(notes);
if (cpp) files.push({ path: `${dir}/${dir.split("/").pop()}.cpp`, content: cpp });
const mine = buildMySolutionFile(notes);
if (mine) files.push({ path: `${dir}/${mine.name}`, content: mine.content });
const head = await branchHead(g, branch);
const tree = files.map((f) => ({ path: f.path, mode: "100644", type: "blob", content: f.content }));
if (existing?.legacy) tree.push({ path: existing.path, mode: "100644", type: "blob", sha: null });
const newTree = await github(g, "POST", `${repoPath(g)}/git/trees`, { base_tree: head.treeSha, tree });
const commit = await github(g, "POST", `${repoPath(g)}/git/commits`, {
message: creditCommit(`${existing ? "Update" : "Add"} ${notes.title || slug}${label ? ` (${label})` : ""}`),
tree: newTree.sha,
parents: [head.commitSha],
});
try {
await github(g, "PATCH", `${repoPath(g)}/git/refs/heads/${encodePath(branch)}`, { sha: commit.sha });
return { ok: true, path: dir, repo: g.repoText, branch, mine: mine ? mine.name : "" };
} catch (err) {
if (err.status === 422 && attempt < 2) continue;
throw err;
}
}
throw new SyncError("GitHub kept reporting a conflict. Try again in a moment.", "CONFLICT");
}
async function syncTest(override) {
const g = await getGithubSettings(override);
if (!g.repo) throw new SyncError('Enter the repository, for example "your-username/dsa-notes".', "NOT_SET_UP");
if (!g.token) throw new SyncError("Paste a GitHub token first.", "NOT_SET_UP");
await fillOwner(g);
const repo = await repoInfo(g);
if (repo.permissions && !repo.permissions.push) {
throw new SyncError(`The token can read ${repo.full_name} but can't write to it. Give it "Contents: Read and write".`, "NO_ACCESS");
}
const branch = g.branch || repo.default_branch;
if (g.branch) {
try {
await github(g, "GET", `${repoPath(g)}/branches/${encodeURIComponent(g.branch)}`);
} catch (err) {
if (err.status === 404) {
throw new SyncError(`Branch "${g.branch}" doesn't exist in ${repo.full_name}. Create it, or leave Branch empty to use the default branch.`, "NO_BRANCH");
}
throw err;
}
}
return { repo: repo.full_name, private: repo.private, branch, folder: g.folder, tokenExpires: tokenExpiry.get(g.token) || null };
}
async function syncUploadAll() {
const g = await getGithubSettings();
if (!g.enabled) throw new SyncError("Turn on GitHub sync and save the settings first.", "NOT_SET_UP");
requireReady(g);
await fillOwner(g);
const all = await chrome.storage.local.get(null);
const keys = Object.keys(all).filter((k) => k.startsWith("hints:"));
let uploaded = 0;
for (const k of keys) {
const [site, slug] = k.startsWith("hints:gfg:") ? ["gfg", k.slice(10)] : ["leetcode", k.slice(6)];
const rec = all[k] || {};
if (!SYNC_SECTIONS.some((s) => rec[s] != null)) continue;
const res = await syncSave(site, slug, rec, "upload", "fill");
if (!res.unchanged) uploaded++;
}
return { uploaded, total: keys.length };
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
if (msg?.type === "GENERATE") {
generate(msg.kind, msg.problem, msg.extra).then(...reply(sendResponse));
return true;
}
if (msg?.type === "TEST_CONNECTION") {
testConnection(msg).then(...reply(sendResponse));
return true;
}
if (msg?.type === "LIST_GEMINI_MODELS") {
listGeminiModels(msg.key).then(...reply(sendResponse));
return true;
}
if (msg?.type === "SYNC_LOAD") {
syncLoad(msg.site, msg.slug).then(...reply(sendResponse));
return true;
}
if (msg?.type === "SYNC_SAVE") {
syncSave(msg.site, msg.slug, msg.record || {}, msg.label).then(...reply(sendResponse));
return true;
}
if (msg?.type === "SYNC_TEST") {
syncTest(msg.github).then(...reply(sendResponse));
return true;
}
if (msg?.type === "SYNC_UPLOAD_ALL") {
syncUploadAll().then(...reply(sendResponse));
return true;
}
if (msg?.type === "USAGE_PRICE") {
sendResponse({ ok: true, result: listPrice(msg.model, 0) });
return false;
}
if (msg?.type === "OPEN_OPTIONS") {
chrome.runtime.openOptionsPage();
}
return false;
});
chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());
chrome.commands?.onCommand.addListener(async (command) => {
const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
if (tab?.id != null) chrome.tabs.sendMessage(tab.id, { type: "COMMAND", command }).catch(() => {});
});
if (typeof module !== "undefined") {
module.exports = { parseHints, parseTests, parseApproach, parseDeep, parseReview, extractJson, numberLines, listGeminiModels, parseRepo, toBase64, fromBase64, listPrice, costOf, classify, backoffMs };
}
