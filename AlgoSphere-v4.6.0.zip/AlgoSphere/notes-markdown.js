// AlgoSphere v4.6.0. Copyright 2026 Rishit Aggarwal (https://github.com/rishitaggarwal1). Apache-2.0: see LICENSE and NOTICE.
const NOTE_SITE_NAMES = { leetcode: "LeetCode", gfg: "GeeksforGeeks" };
const ALGOSPHERE_AUTHOR = {
name: "Rishit Aggarwal",
linkedin: "https://www.linkedin.com/in/rishit-aggarwal/",
github: "https://github.com/rishitaggarwal1",
medium: "https://medium.com/@rishitaggarwal1",
};
const creditMarkdown = () =>
`---\n\n<sub>Notes made with **AlgoSphere**, designed and built by **${ALGOSPHERE_AUTHOR.name}** · ` +
`[LinkedIn](${ALGOSPHERE_AUTHOR.linkedin}) · [GitHub](${ALGOSPHERE_AUTHOR.github}) · [Medium](${ALGOSPHERE_AUTHOR.medium})</sub>`;
const NOTE_HINT_LABELS = [
"Restate",
"Observation",
"Constraints",
"Pattern",
"Key insight",
"What to track",
"Approach",
"Edge cases & complexity",
];
function problemUrl(site, slug, url) {
if (url) return url;
return site === "gfg" ? `https://www.geeksforgeeks.org/problems/${slug}/1` : `https://leetcode.com/problems/${slug}/`;
}
const mdLine = (s) => String(s ?? "").trim();
function mdCell(s) {
const t = String(s ?? "")
.replace(/\|/g, "\\|")
.replace(/\r?\n/g, "<br>")
.trim();
return t || " ";
}
function mdTable(headers, rows) {
return [
`| ${headers.map(mdCell).join(" | ")} |`,
`| ${headers.map(() => "---").join(" | ")} |`,
...rows.map((r) => `| ${r.map(mdCell).join(" | ")} |`),
].join("\n");
}
function fence(code, lang = "") {
const ticks = /```/.test(code) ? "````" : "```";
return `${ticks}${lang}\n${String(code).replace(/\s+$/, "")}\n${ticks}`;
}
const inlineCode = (s) => {
const t = String(s ?? "");
return t.includes("`") ? `\`\` ${t} \`\`` : `\`${t}\``;
};
const mdAnchor = (s) =>
String(s)
.toLowerCase()
.replace(/[^\p{L}\p{N} _-]/gu, "")
.trim()
.replace(/ /g, "-");
const details = (summary, body) => `<details>\n<summary>${summary}</summary>\n\n${body}\n\n</details>`;
function numberedPseudocode(lines) {
const width = String(lines.length).length;
return lines.map((l, i) => `${String(i + 1).padStart(width, " ")} │ ${l}`).join("\n");
}
function costSection(title, b, fallbackTotal) {
const out = [`**${title}: ${inlineCode(b?.total || fallbackTotal)}**`];
if (b?.parts?.length) {
out.push(mdTable(["Part", "Cost", "Why"], b.parts.map((p) => [p.part, p.cost, p.why])));
}
const notes = [];
if (b?.sum) notes.push(`**Adding it up:** ${b.sum}`);
if (b?.cases) notes.push(`**Best vs worst case:** ${b.cases}`);
if (b?.feel) notes.push(`**At the maximum input:** ${b.feel}`);
if (b?.note) notes.push(`**Not counted:** ${b.note}`);
if (notes.length) out.push(notes.map((n) => `- ${n}`).join("\n"));
return out.join("\n\n");
}
function stateParts(step) {
const parts = [];
for (const [k, v] of Object.entries(step.vars || {})) parts.push([`v:${k}`, inlineCode(`${k} = ${v}`)]);
for (const [name, a] of Object.entries(step.arrays || {})) {
const ptrs = Object.entries(a.pointers || {})
.map(([label, p]) => `${label}→${Array.isArray(p) ? `[${p.join(",")}]` : p}`)
.join(", ");
const is2D = (a.values || []).some(Array.isArray);
const body = is2D
? `${a.values.length}×${(a.values[0] || []).length} table: ${a.values.map((r) => `[${[].concat(r).join(", ")}]`).join(" ")}`
: `[${(a.values || []).join(", ")}]`;
parts.push([`a:${name}`, `${inlineCode(`${name} = ${body}`)}${ptrs ? ` (${ptrs})` : ""}`]);
}
for (const [name, st] of Object.entries(step.structures || {})) {
const items = st.items || [];
let shown;
if (st.type === "map" || st.type === "set") shown = `{${items.join(", ")}}`;
else if (st.type === "stack") shown = items.length ? `[${items.join(", ")}] ← top` : "[]";
else if (st.type === "queue") shown = items.length ? `front → [${items.join(", ")}]` : "[]";
else shown = `[${items.join(", ")}]`;
parts.push([`s:${name}`, inlineCode(`${name} = ${shown}`)]);
}
for (const [name, t] of Object.entries(step.trees || {})) {
const values = t.values || [];
const at = (p) => (p === -1 || values[p] == null ? "null" : values[p]);
const ptrs = Object.entries(t.pointers || {}).map(([label, p]) => `${label}→${at(p)}`);
const hl = (t.highlight || []).map(at);
const extra = [...ptrs, ...(hl.length ? [`at ${hl.join(", ")}`] : [])].join(", ");
parts.push([`t:${name}`, `${inlineCode(`${name} = tree [${values.map((v) => v ?? "null").join(", ")}]`)}${extra ? ` (${extra})` : ""}`]);
}
for (const [name, l] of Object.entries(step.lists || {})) {
parts.push([`l:${name}`, `${inlineCode(`${name}: ${listChains(l)}`)}${listPointers(l)}`]);
}
for (const [name, g] of Object.entries(step.graphs || {})) {
const bits = [];
const ptrs = Object.entries(g.pointers || {}).map(([label, v]) => `${label}→${v}`);
if (ptrs.length) bits.push(ptrs.join(", "));
if ((g.visited || []).length) bits.push(`visited {${g.visited.join(", ")}}`);
if ((g.activeEdges || []).length) bits.push(`edge ${g.activeEdges.map(([a, b]) => `${a}${g.directed ? "→" : "–"}${b}`).join(", ")}`);
parts.push([`g:${name}`, inlineCode(`${name}: ${bits.join("; ") || `${(g.nodes || []).length} nodes`}`)]);
}
return parts;
}
function listChains(l) {
const values = l.values || [];
const next = l.next || values.map((_, i) => (i + 1 < values.length ? i + 1 : -1));
const pointedAt = new Set(next.filter((j) => j >= 0));
const done = new Set();
const chains = [];
const walk = (start) => {
const out = [];
let i = start;
while (i >= 0 && !done.has(i)) {
done.add(i);
out.push(values[i]);
i = next[i];
}
chains.push(out.join(" → ") + (i >= 0 ? ` → ↺ ${values[i]}` : " → null"));
};
values.forEach((_, i) => !pointedAt.has(i) && walk(i));
values.forEach((_, i) => !done.has(i) && walk(i));
return chains.join(" | ");
}
function listPointers(l) {
const ptrs = Object.entries(l.pointers || {}).map(([label, p]) => `${label}→${p === -1 ? "null" : (l.values || [])[p]}`);
return ptrs.length ? ` (${ptrs.join(", ")})` : "";
}
function stateCell(step, prev) {
const now = stateParts(step);
if (!prev) return now.map(([, text]) => text).join("\n");
const before = new Map(stateParts(prev));
const changed = now.filter(([key, text]) => before.get(key) !== text).map(([, text]) => text);
return changed.length ? changed.join("\n") : "(no change)";
}
function dryRunSection(dr) {
if (!dr || !dr.steps?.length) return "";
const rows = dr.steps.map((s, i) => [String(i + 1), s.line ? String(s.line) : "", s.explain, stateCell(s, dr.steps[i - 1])]);
return [
`**Dry run** on ${inlineCode(dr.input || "the first example")}`,
mdTable(["Step", "Line", "What happens", "State (step 1) / what changed"], rows),
dr.result ? `**Result:** ${dr.result}` : "",
]
.filter(Boolean)
.join("\n\n");
}
const fullProgram = (d) => [d.prelude, d.solution, d.main].filter(Boolean).join("\n\n");
function approachHeading(a, i) {
return `${i + 1}. ${a.level}: ${a.name || a.level}`;
}
function approachSection(a, i) {
const d = a.deep;
const isOptimal = /optimal/i.test(a.level);
const out = [`### ${approachHeading(a, i)}`];
if (a.aha) out.push(`> **${i === 0 ? "Where you start" : "How you get here"}:** ${a.aha}`);
if (a.idea) out.push(`**Idea.** ${a.idea}`);
if (a.steps?.length) out.push(`**Steps**\n\n${a.steps.map((s, k) => `${k + 1}. ${s}`).join("\n")}`);
if (d?.pseudocode?.length) out.push(`**Pseudocode**\n\n${fence(numberedPseudocode(d.pseudocode), "text")}`);
if (d?.time && d?.space) {
out.push(costSection("Time complexity", d.time, a.time));
out.push(costSection("Space complexity", d.space, a.space));
} else {
out.push(`**Complexity:** time ${inlineCode(a.time)}, space ${inlineCode(a.space)}.${a.complexity ? ` ${a.complexity}` : ""}`);
}
if (d?.dryRun) out.push(dryRunSection(d.dryRun));
if (d?.solution) {
out.push(`**C++ solution**\n\n${fence(d.solution, "cpp")}`);
if (d.main) out.push(details("Full program with <code>main()</code> (compile and run locally)", fence(fullProgram(d), "cpp")));
}
if (a.tradeoff) out.push(`**${isOptimal ? "Why this is the best" : "Why move on"}:** ${a.tradeoff}`);
return out.join("\n\n");
}
function bestApproach(approach) {
const list = approach?.approaches || [];
for (let i = list.length - 1; i >= 0; i--) if (list[i].deep?.solution) return list[i];
return null;
}
const LANG_FILES = {
"C++": ["cpp", "cpp", "//"],
C: ["c", "c", "//"],
Java: ["java", "java", "//"],
Python: ["py", "python", "#"],
Python3: ["py", "python", "#"],
JavaScript: ["js", "javascript", "//"],
TypeScript: ["ts", "typescript", "//"],
"C#": ["cs", "csharp", "//"],
Go: ["go", "go", "//"],
Rust: ["rs", "rust", "//"],
Kotlin: ["kt", "kotlin", "//"],
Swift: ["swift", "swift", "//"],
Ruby: ["rb", "ruby", "#"],
Scala: ["scala", "scala", "//"],
PHP: ["php", "php", "//"],
Dart: ["dart", "dart", "//"],
};
const langFile = (lang) => LANG_FILES[lang] || ["txt", "", "//"];
const mySolutionName = (s) => `my-solution.${langFile(s.lang)[0]}`;
function solutionStats(s) {
const pct = (p) => (p != null && p !== "" ? ` (beats ${Math.round(Number(p) * 10) / 10}%)` : "");
return {
runtime: s.runtime ? `${s.runtime}${pct(s.runtimePercentile)}` : "",
memory: s.memory ? `${s.memory}${pct(s.memoryPercentile)}` : "",
date: s.acceptedAt ? new Date(s.acceptedAt).toISOString().slice(0, 10) : "",
};
}
function mySolutionSection(n) {
const list = n.mySolutions || [];
if (!list.length) return "";
const latest = list[0];
const st = solutionStats(latest);
const out = ["## My solution"];
out.push(
mdTable(
["Language", "Runtime", "Memory", "Tests passed", "Attempts", "Hints used", "Accepted on"],
[[latest.lang || "", st.runtime, st.memory, latest.passed || "", latest.attempts ? String(latest.attempts) : "", latest.hintsUsed != null ? `${latest.hintsUsed} of 8` : "", st.date]]
)
);
const approaches = n.approach?.approaches || [];
const optimal = approaches[approaches.length - 1];
if (optimal) {
out.push(`For comparison, the optimal approach (${optimal.name || optimal.level}) runs in ${inlineCode(optimal.time)} time and ${inlineCode(optimal.space)} space.`);
}
out.push(fence(latest.code || "", langFile(latest.lang)[1]));
if (list.length > 1) {
const older = list
.slice(1)
.map((s) => {
const o = solutionStats(s);
return `**${s.lang || "Code"}${o.date ? ` · ${o.date}` : ""}${o.runtime ? ` · ${o.runtime}` : ""}**\n\n${fence(s.code || "", langFile(s.lang)[1])}`;
})
.join("\n\n");
out.push(details(`Earlier accepted versions (${list.length - 1})`, older));
}
return out.join("\n\n");
}
function buildMySolutionFile(n) {
const s = (n.mySolutions || [])[0];
if (!s || !s.code) return null;
const [, , c] = langFile(s.lang);
const st = solutionStats(s);
const site = NOTE_SITE_NAMES[n.site] || n.site;
const header = [
`${c} ${n.title || n.slug} (${site}${n.problem?.difficulty ? `, ${n.problem.difficulty}` : ""})`,
`${c} ${problemUrl(n.site, n.slug, n.url)}`,
`${c} My accepted solution${st.date ? ` · ${st.date}` : ""}${st.runtime ? ` · runtime ${st.runtime}` : ""}${st.memory ? ` · memory ${st.memory}` : ""}`,
];
return { name: mySolutionName(s), content: `${header.join("\n")}\n\n${String(s.code).replace(/\s+$/, "")}\n` };
}
function buildProblemReadme(n) {
const site = NOTE_SITE_NAMES[n.site] || n.site;
const url = problemUrl(n.site, n.slug, n.url);
const a = n.approach;
const difficulty = n.problem?.difficulty;
const out = [];
out.push(`# ${n.title || n.slug}`);
const meta = [`**${site}**`, difficulty ? `**${difficulty}**` : "", `[Open the problem](${url})`].filter(Boolean);
if (a?.pattern) meta.push(`Pattern: **${a.pattern}**`);
const mine = (n.mySolutions || [])[0];
if (mine) {
const st = solutionStats(mine);
meta.push(`✅ Solved in ${mine.lang || "code"}${st.runtime ? ` · ${st.runtime}` : ""}`);
}
out.push(meta.join(" · "));
if (a?.oneLiner) out.push(`> ${a.oneLiner}`);
const toc = [];
if (n.problem?.description) toc.push("Problem");
if (n.hints?.length) toc.push("Hints");
if (a) toc.push("Intuition", "Approaches");
if (n.mySolutions?.length) toc.push("My solution");
if (n.tests || n.customTests?.length) toc.push("Test cases");
if (a?.mistakes?.length || a?.edgeCases?.length) toc.push("Mistakes and edge cases");
if (a?.related?.length) toc.push("Practice next");
if (a?.takeaways?.length) toc.push("Takeaways");
if (toc.length > 2) out.push(`**Contents:** ${toc.map((t) => `[${t}](#${mdAnchor(t)})`).join(" · ")}`);
if (n.problem?.description) {
out.push("## Problem");
out.push(details("Problem statement", fence(n.problem.description, "text")));
}
if (n.hints?.length) {
out.push("## Hints");
out.push("Try the problem first. When you're stuck, open one hint at a time; each one gives away a little more.");
out.push(n.hints.map((h, i) => details(`Hint ${i + 1} · ${NOTE_HINT_LABELS[i] || ""}`, mdLine(h))).join("\n\n"));
}
if (a) {
out.push("## Intuition");
if (a.signals?.length) {
out.push("### Clues in the problem");
out.push(
mdTable(
["Clue", "What it suggests"],
a.signals.map((s) => {
const [clue, ...rest] = s.split(/\s*(?:→|->)\s*/);
return [clue, rest.join(" → ")];
})
)
);
}
if (a.constraints) out.push(`### What the constraints tell you\n\n${a.constraints}`);
if (a.thinking?.length) {
out.push("### Think it through");
out.push("Answer each question yourself before opening it.");
out.push(a.thinking.map((t, i) => `**Q${i + 1}. ${mdLine(t.q)}**\n\n${details("Answer", mdLine(t.a))}`).join("\n\n"));
} else if (a.intuition?.length) {
out.push(`### How to think about it\n\n${a.intuition.join("\n\n")}`);
}
out.push("## Approaches");
out.push(
mdTable(
["#", "Approach", "Time", "Space"],
a.approaches.map((x, i) => [String(i + 1), `[${x.level}: ${x.name || x.level}](#${mdAnchor(approachHeading(x, i))})`, inlineCode(x.time), inlineCode(x.space)])
)
);
a.approaches.forEach((x, i) => out.push(approachSection(x, i)));
}
const mineSection = mySolutionSection(n);
if (mineSection) out.push(mineSection);
if (n.tests || n.customTests?.length) {
out.push("## Test cases");
const caseRow = (c) => [c.args.map((x) => (x.name ? `${x.name} = ${x.value}` : x.value)).join("\n"), c.output];
if (n.customTests?.length) {
out.push("**My cases**");
out.push(mdTable(["Input", "Expected", "What it checks"], n.customTests.map((c) => [caseRow(c)[0], c.output || "(from the judge)", c.note || ""])));
}
if (n.tests?.normal?.length) {
out.push("**Normal cases**");
out.push(mdTable(["Input", "Expected", "What it checks"], n.tests.normal.map((c) => [...caseRow(c), c.note])));
}
if (n.tests?.edge?.length) {
out.push("**Edge cases**");
out.push(
mdTable(
["Case", "Input", "Expected", "Why it matters"],
n.tests.edge.map((c) => {
const m = String(c.note || "").match(/^([^:]{2,40}):\s*([\s\S]*)$/);
const why = m ? m[2] : c.note || "";
return [m ? m[1] : "", ...caseRow(c), why.charAt(0).toUpperCase() + why.slice(1)];
})
)
);
}
}
if (a?.mistakes?.length || a?.edgeCases?.length) {
out.push("## Mistakes and edge cases");
if (a.mistakes?.length) out.push(`**Common mistakes**\n\n${a.mistakes.map((m) => `- ${m}`).join("\n")}`);
if (a.edgeCases?.length) out.push(`**Edge cases to check**\n\n${a.edgeCases.map((m) => `- ${m}`).join("\n")}`);
}
if (a?.related?.length) {
out.push("## Practice next");
out.push(a.related.map((r) => `- [${r.title}](https://leetcode.com/problems/${r.slug}/)${r.why ? ` · ${r.why}` : ""}`).join("\n"));
}
if (a?.takeaways?.length) {
out.push("## Takeaways");
out.push(a.takeaways.map((t) => `- ${t}`).join("\n"));
}
out.push(creditMarkdown());
return out.join("\n\n") + "\n";
}
function buildSolutionCpp(n) {
const best = bestApproach(n.approach);
if (!best) return null;
const d = best.deep;
const site = NOTE_SITE_NAMES[n.site] || n.site;
const safe = (s) => String(s ?? "").replace(/\*\//g, "* /");
const wrap = (text, width = 74) => {
const words = safe(text).replace(/`/g, "").split(/\s+/).filter(Boolean);
const lines = [];
let line = "";
for (const w of words) {
if ((line + " " + w).trim().length > width) {
lines.push(line);
line = w;
} else line = (line + " " + w).trim();
}
if (line) lines.push(line);
return lines;
};
const header = [
"/*",
` * Problem   : ${safe(n.title || n.slug)}${n.problem?.difficulty ? ` (${site}, ${safe(n.problem.difficulty)})` : ` (${site})`}`,
` * Link      : ${problemUrl(n.site, n.slug, n.url)}`,
n.approach?.pattern ? ` * Pattern   : ${safe(n.approach.pattern)}` : null,
` * Approach  : ${safe(best.level)}: ${safe(best.name || best.level)}`,
` * Complexity: Time ${safe(d.time?.total || best.time)}, Space ${safe(d.space?.total || best.space)}`,
" *",
...wrap(best.idea).map((l) => ` * ${l}`),
" *",
` * Notes made with AlgoSphere by ${ALGOSPHERE_AUTHOR.name} (${ALGOSPHERE_AUTHOR.github})`,
" */",
].filter((l) => l !== null);
return `${header.join("\n")}\n\n${fullProgram(d)}\n`;
}
function noteIndexEntry(n, dir) {
const best = bestApproach(n.approach);
const approaches = n.approach?.approaches || [];
const last = approaches[approaches.length - 1];
return {
title: n.title || n.slug,
site: n.site,
slug: n.slug,
difficulty: n.problem?.difficulty || "",
pattern: n.approach?.pattern || "",
time: last?.time || "",
space: last?.space || "",
dir,
solution: best ? `${dir}/${dir.split("/").pop()}.cpp` : "",
mine: n.mySolutions?.[0] ? { lang: n.mySolutions[0].lang, path: `${dir}/${mySolutionName(n.mySolutions[0])}` } : null,
updatedAt: n.updatedAt,
};
}
function buildIndexReadme(entries, title) {
const list = Object.values(entries).sort((x, y) => x.title.localeCompare(y.title));
const count = (d) => list.filter((e) => e.difficulty.toLowerCase() === d).length;
const byLevel = ["easy", "medium", "hard"]
.map((d) => [d, count(d)])
.filter(([, c]) => c)
.map(([d, c]) => `${d[0].toUpperCase() + d.slice(1)} ${c}`);
const patterns = new Set(list.map((e) => e.pattern).filter(Boolean));
const solved = list.filter((e) => e.mine).length;
const out = [
`# ${title}`,
"Problem-by-problem notes. Each folder walks through one problem: progressive hints, the intuition behind it, every approach from brute force to optimal with a complexity breakdown and a step-by-step dry run, a commented C++ solution, and test cases.",
[`**${list.length} problem${list.length === 1 ? "" : "s"}**`, solved ? `${solved} solved` : "", ...byLevel, patterns.size ? `${patterns.size} pattern${patterns.size === 1 ? "" : "s"}` : ""].filter(Boolean).join(" · "),
"**How to use these notes:** try the problem first, then open the hints one at a time. Read the intuition and the approaches only after you've made an attempt.",
mdTable(
["#", "Problem", "Platform", "Difficulty", "Pattern", "Optimal", "Solution", "Solved"],
list.map((e, i) => [
String(i + 1),
`[${e.title}](${e.dir}/)`,
NOTE_SITE_NAMES[e.site] || e.site,
e.difficulty,
e.pattern,
e.time ? `${inlineCode(e.time)} time, ${inlineCode(e.space)} space` : "",
e.solution ? `[C++](${e.solution})` : "",
e.mine ? `✅ [${e.mine.lang || "mine"}](${e.mine.path})` : "",
])
),
creditMarkdown(),
];
return out.join("\n\n") + "\n";
}
if (typeof module !== "undefined") {
module.exports = { buildProblemReadme, buildSolutionCpp, buildMySolutionFile, buildIndexReadme, noteIndexEntry, mdAnchor };
}
